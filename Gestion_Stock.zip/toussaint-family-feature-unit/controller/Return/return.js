(function($){
	add_return();
	view_sales_r();
	check_returned_sale();
	search();
})(jQuery)
function search(){
	 $("#myInput").on("keyup", function() {
     var value = $(this).val().toLowerCase();
$("#t_body_sales tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	});
});
}

function check_returned_sale(){
	$(document).on('click','.return_link',function(e){
		e.preventDefault();
		toastr.info('Cette vente est deja retournée !!');
	});
}
function tr_sale_factory_r(data, index){
	let tr = '<tr id = "'+data.sale_id+'">';
	tr += '<td class="sale_code">'+data.sale_code+'</td>';
	tr += '<td class="first_name">'+data.first_name+'</td>';
	tr += '<td class="item_count_s">'+data.item_count+'</td>';
	tr += '<td class="sale_amount">'+Number.parseFloat(data.sale_amount).toFixed(2)+'</td>';
	tr += '<td class="cash">'+data.cash+'</td>';
	tr += '<td class="due">'+data.due+'</td>';
	tr += '<td class="sale_date">'+data.sale_date+'</td>';
	

	tr += '<td style="text-align: center;"><a href="sale_detail.php?id='+data.sale_id+'">';
	tr += '<i class="fas fa-eye  view-icon" data-toggle="tooltip"';
	//tr += 'data-sale_code="'+data.sale_code+'"';
	tr += 'data-sale_id="'+data.sale_id+'"';
	tr += 'data-sale_code="'+data.sale_code+'"';
	tr += 'data-item_count="'+data.item_count+'"';
	tr += 'data-sale_amount="'+Number.parseFloat(data.sale_amount).toFixed(2)+'"';
	tr += 'data-cash="'+data.cash+'"';
	tr += 'data-due="'+data.due+'"';
	tr += 'data-sale_date="'+data.sale_date+'"';
	tr += 'data-first_name="'+data.first_name+'"';
	tr += 'title="Edit"></i></a>&nbsp|&nbsp';
	if(Number(data.item_count > 0)){
		tr += '<a href="return-prod.php?id='+data.sale_id+'"><i class="fas fa-undo-alt return-icon"><i/>retour</a>';
	}else{
		tr += '<a class ="return_link" href="#"><i class="fas fa-undo-alt return-icon"><i/>retour</a>';
	}
	tr += '</td></tr>'
	//tr += '<a href="#delete-modal" class="delete modal-link fas fa-trash-alt"" data-id="'+data.product_base_id+'" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"';
	//tr += '</td><td><a href="return.php?id='+data.sale_id+'">retour produit</a></td></tr>';

	return tr;
}

function view_sales_r(){
	$.ajax({
		data: {type:'4',isReturned:1},
		url : "../controller/Sale/SaleController.php",
		method: 'post',
		success: function(response)
		{
			//console.log(response)
			response = $.parseJSON(response);
			if(response.length>0){
				//console.log(response);
				response.forEach(function(data,index){
					let tr = tr_factory_sale(data,index,true);
					$('#t_body_sale_return').append(tr);
					//console.log(data);
				})
				dataTable("#tableReturn")
				
			}else{
				//initTable();
			}
		}
	});
}

function line_prod_fac(prodId,qty,price,qte,total){
	return{
		product_id:prodId,
		quantity:qty,
		price:price,
		total:total,
		qte:qte
	};
}

function add_return(){
	$(document).on('click','#valider_return',function(e) {
		//let checkout  = $('#tbody_checkout').text();
		var response = confirm("Voulez-vous Valider Cette retour ?");
		if(response == true){

		e.preventDefault();
		var total = Number($('.total').val());
		var cash = Number($('.cash').val());
		//var reduction = Number($(".reduction").val());
		//var count = $('.reduction').val().length > 7;
		//console.log($('.reduction').val().length > 7);
		/*if(reduction < 0){
			window.alert("Vous ne pouvez pas entrer un nombre negatif pour la reudction");
		}else if($('.reduction').val().length > 5){
			window.alert("Vous ne pouvez pas entrer un nombre contenant plus que 5 chiffres pour la reudction");
		}
		else if(total == 0){
			window.alert("Veuillez Ajouter Un Produit !");
			location.reload();
		}else if (cash == 0){
			window.alert("Veuillez Entrer Le montant Recu ! !");
		}
		else if(cash < total){
			window.alert("Le Montant Recu est insuffisant !");
		}else{*/
			var d = new Date();
			var time_sa = d.getHours()+':'+d.getMinutes()+':'+d.getSeconds();
			var sale = {
			subtotal:$('.subtotal').val(),
			total:$('.total').val(),
			change:$('.change').val(),
			cash:$('.cash').val(),
			item_count:$('.item_count').val(),
			sale_time: time_sa,
			reduction:$('.reduction').val()
			};
			var prod_line = [];

			$("#tbody_checkout tr").each(function(){
				let id = $(this).attr('id');
				let qty = $('#'+id+' .qte').val();
				let price = $('#'+id+' .price_s').val();
				let total = $('#'+id+' .tot').val();
				let qte = $('#'+id+' .stock_qty').val();
				prod_line.push(line_prod_fac(id,qty,price,qte,total));
    		 });
			console.log(prod_line);

			//$('#addEmployeeModal').modal('hide');
			//console.log($("#sale_id").val())
			$.ajax({
				data: {sale:sale,line:prod_line,type:1,sale_id:$("#sale_id").val()},
				type: "post",
				url: "../controller/Sale/SaleController.php",
				success: function(dataResult){
						//var dataResult = JSON.parse();
						console.log(dataResult);
						//if(dataResult == 'success'){
							if(dataResult >= "0"){
							//$('#addEmployeeModal').modal('hide');
							window.alert('Operation réussie !');
	                        location.reload();
	                        //out_of_stock_soon_s();
	                        //out_of_stock_s();
	                        //location.reload();
						}
						else {
						   console.log(dataResult);
						}
				}
			});
		//}
	}else{
		location.reload();
	}
		
	});
}