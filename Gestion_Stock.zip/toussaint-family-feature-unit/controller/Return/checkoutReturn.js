/* change function name*/
(function($){
	$("#add-prod-mobile").on("click",function(e){
		var searchInput = $("#prod_search");
		if(searchInput.val() != ""){
			var search = searchInput.val().split("-")
			var id = search[0];
			searchInput.val("");
			var tr = $("#tbody_sale_prod tr#"+id);
			var name = tr.attr('data-prodName');
			var price = tr.attr('data-priceM');	
			var stock_quantity = tr.attr('data-qtyM');
			var product_line_quantity = Number($("#tbody_sale_prod tr#"+id+" .return_qty").text());
			addProdCallBackR(id,name,price,product_line_quantity, stock_quantity)
			resetFormModal("form_search")
		}
	})
addProdr();
calc_changer();
remove_itemr();


$(document).on('click','.plus', function(e){
		e.preventDefault();
		var id = $(this).attr('data-product_base_id');
		plusQtyr(id);
	});

$(document).on('click','.moins', function(e){
		e.preventDefault();
		var id = $(this).attr('data-product_base_id');
		moinsQtyr(id);
	});

$(document).on('input','.reduction',function(e){
	//e.preventDefault();
	let reduc = Number($('.reduction').val());
	let tot = Number($('.subtotal').val());
	//console.log(tot);
	//if($('.reduction').val().length > 10){
	//	window.alert("Vous ne pouvez pas entrer un nombre superieur a 10 chiffres pour la reudction");
	//}
	if(!isNaN(tot)){
		if($('.reduction').val().length <= 7){
			if(reduc < 0){
				window.alert("Vous ne pouvez pas entrer un nombre negatif pour la reudction");
			}
			else if(reduc > tot){
				window.alert("Vous ne pouvez pas rentrer un nombre superieur a la somme total");
				$('.total').val(tot);
			}else{
				$('.total').val(Number.parseFloat(tot-reduc).toFixed(2));
				//calc_change();
			}
		}else{
			window.alert("Vous ne pouvez pas entrer un nombre contenant plus que 7 chiffres pour la reduction");
		}
	}
});


$(document).on('input','.qte',function(e){
	e.preventDefault();
	let id = $(this).attr('data-id');
	let qty = Number($(this).val());
	/*if(qty>=0){
		window.alert("Vous devez entrer un chiffre negatif pour le retour");
		$(this).val(0);
		cal_tot(id,-1);
		calc_tot();
	}*/
	if(qty > 0){
		qty = qty * -1;
	}

	var stock_qty = Number($('#'+id+' .s_qty').val());
	console.log(stock_qty);
	if(Number.isNaN(qty)){
		//console.log('qty');
		$(this).val(-1);
		cal_totr(id,-1);
		calc_totr();
	}/*else if(qty<0){
		window.alert("La quantite ne peut pas etre negative !");

		$(this).val(0);
		//console.log(qty);
		cal_tot(id,0);
		calc_tot();
	}*/else if(qty*-1>stock_qty){
		window.alert("En rupture de stock .");
		$(this).val(-1);
		cal_totr(id,-1);
		calc_totr();
	}
	else{
		cal_totr(id,qty);
		calc_totr();
	}
});

})(jQuery)

function calc_cash_reduction_return(){

	var reduc_tot = Number($('#reduction_prod').val()) * Number(item_countr());
	var cash_reduction = Number($('.cash').val()) - (reduc_tot);
	$('.cash').val(Number.parseFloat(cash_reduction).toFixed(2))
	$('.reduction').val(reduc_tot);
	
	return reduc_tot;
}

function item_countr(){
	var count = 0;
	$("#tbody_checkout tr").each(function(){
		let id = $(this).attr('id');
		let qty = Number($('#'+id+' .qte').val());
		count += qty;
     });
	return count;
}

function subtotalr(){
	var subtotal = 0;
	$("#tbody_checkout tr").each(function(){
		let tr = $(this).attr('id');
		let tot = Number($('#'+tr+' .tot').val());
		subtotal += tot;
     });
	return subtotal;
}


function calc_totr(){
	let itemCount = item_countr();
	let subTotal = subtotalr() < 0 ? subtotalr() : subtotalr()*-1;

	$('.item_count').val(itemCount);
	$('.total').val(Number.parseFloat(subTotal).toFixed(2));

	$('.subtotal').val(subTotal);
	$('.cash').val(subTotal);
}

function calc_changer(){
	$('.cash').on('input', function(){
		let cash = Number($(this).val());
		if (isNaN(cash)) {
			window.alert("Le motant doit etre un nombre positif !");
			$(".cash").val(0);
		}else{
		let total = Number($('.total').val());
		$('.change').val(Number.parseFloat(cash-total).toFixed(2));
	}
	});
	$('.reduction').on('input', function(){
		let cash = Number($('.cash').val());
		if (isNaN(cash)) {
			window.alert("Le motant doit etre un nombre positif !");
			$(".cash").val(0);
		}else{
		let total = Number($('.total').val());
		$('.change').val(Number.parseFloat(cash-total).toFixed(2));
	}
	});
}

function remove_itemr(){
	$(document).on('click', '.del',function(e){
		e.preventDefault();
		let id = $(this).attr('data-id');
		$('#'+id).remove();
		  calc_totr();
		  calc_cash_reduction_return()
			});
}

function prodexistr(id){
var test = false;
 $('#checkout tr').each(function(){
 	let idTr= $(this).attr('id');
 	if(idTr == id){
 		test =  true;
 	}
 });
 return test;
}

function plusQtyr(id){
	var qte = Number($('#'+id+' .qte').val())*-1;
	var stock_qty = Number($('#'+id+' .s_qty').val());
	qte += 1;

	if(qte>stock_qty){
		toastr.error("Vous ne pouvez pas retourner plus de produit ")
	}else{
			$('#'+id+' .qte').val(qte*-1);
			cal_totr(id,qte);
			calc_totr();
			calc_cash_reduction_return();
		}
}

function moinsQtyr(id){
	var qte = Number($('#'+id+' .qte').val())*-1;
	qte -=1;
			if(qte<0){
				$('#'+id+' .qte').val(0);
				cal_totr(id,0);
			}else{
				$('#'+id+' .qte').val(qte*-1);
				cal_totr(id,qte);
			}
			calc_totr();
			calc_cash_reduction_return()
}

function cal_totr(id, qty){

	let price = Number($('#'+id+' .price_s').val());
	$('#'+id+' .tot').val(price*qty*-1);
}

function tr_Check_factoryr(id,name,price,s_qty, stock_quantity){
let tr = '<tr id = "'+id+'" class="checkout-item">';
tr += '<input type="hidden" class="stock_qty" name="'+id+'stock_qty" value="'+stock_quantity+'"/>';
tr += '<input type="hidden" class="s_qty" name="'+id+'qty" value="'+s_qty+'"/>';
tr += '<input type="hidden" class="price_s" name="'+id+'price" value="'+price+'"/>';
tr += '<input type="hidden" class="id_prod" name="id_prod" value="'+id+'"/>';
//tr += '<td><a href="#" class="del" data-id="'+id+'">X</a></td>';
tr += '<td class="td-name w-50 mw-50"><a href="#" class="del p-1 pb-1" data-id="'+id+'"><i class="fa fa-times text-danger"></i></a> '+name+'</td>';
//tr += '<td >'+Number.parseFloat(price).toFixed(2)+'</td>';
tr += '<td >'+price+'</td>';
tr += '<td class="quantity d-flex  mx-0"><a href="#" data-product_base_id="'+id+'"class="moins d-flex align-self-center w-25 mw-25"><i class="fas fa-minus text-center ml-0 p-0"></i></a>';
tr += '<input class="qte form-control text-center d-flex align-self-center" type="number" name="'+id+'qte" data-id="'+id+'" value="-1" readonly="true"/>';
tr += '<a href= "#" data-product_base_id="'+id+'" class="plus d-flex align-self-center w-25 mw-25"><i class="fas fa-plus text-center ml-0 p-0"></i></a></td>';
tr += '<td ><input type="text" class="tot form-control text-center p-0" name="tot_price_prod" value="'+Number(price)*-1+'" readonly="true"/></td></tr>';

return tr;
}

function addProdCallBackR(id,name,price,product_line_quantity, stock_quantity){
	if(product_line_quantity<=0){
		window.alert('Vous ne pouvez pas retourner plus de produit ');
	}else{
		if(prodexistr(id)){
		plusQtyr(id);
		}else{
			//stock_quantity = Number(stock_quantity) * -1;
			//console.log(stock_quantity)
			let tr = tr_Check_factoryr(id,name,price,product_line_quantity, stock_quantity);
			$('#tbody_checkout').append(tr);
			calc_totr();
			calc_cash_reduction_return();
		}
	}
}

function addProdr(){
	$(document).on('click','.prod-addr', function(e){
		e.preventDefault();
		var id = $(this).attr('data-product_id');
		var name = $(this).attr('data-name');
		var price = $(this).attr('data-sale_price');
		var product_line_quantity = $(this).attr('data-quantity');
		var stock_quantity = $(this).attr('data-product_quantity');
		//console.log(product_line_quantity)
		addProdCallBackR(id,name,price,product_line_quantity, stock_quantity)
	});
}
