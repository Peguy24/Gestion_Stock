// Executer un appel AJAX GET
// Prend  en parametres l'URL cible et la fonction callback appele en cas de succes
function ajaxGet(url, callback){
    //Creation d'une requete HTTP
    var req = new XMLHttpRequest();

    //Requete HTTP GET synchrone vers le fichier langages.txt publie localement
    req.open("GET", url , false);

    // Gestion de l'evenement indiquant la fin de la requete
    req.addEventListener("load", function(){
        if(req.status >= 200 && req.status < 400 ){
            //Appelle la fonction callback en lui passant la reponse de la requete
            callback(req.responseText);
        }else{
            //Affiche des informations sur l'echec du traitement de la requete
            console.error(req.status + " " + req.statusText + " " + url) 
        }    
    });

    req.addEventListener("error", function () {
        // La requête n'a pas réussi à atteindre le serveur
        console.error("Erreur réseau");
    });
    //Envoi de la requete
    req.send(null);
}

// Execute un appel AJAX POST
// Prend en parametre l'URL cible, la donne a envoye et la fonction callback appelee en cas de succes
// Le parametre isJson ppermet d'identifier si l'envoie concerne des donnees JSON

function ajaxPost(url, data, callback, isJson){
    // var req = new XMLHttpRequest();
    // req.open("POST", url);
    // req.addEventListener("load", function(){
    //     if(req.status >= 200 && req.status < 400){
    //         callback(req.responseText);
    //     }else{
    //         console.error(req.status + " " + req.statusText + " " + url);
    //     }
    // });
    // req.addEventListener("error", function(){
    //     console.error("Erreur Reseau avec l'Url " + url);
    // });
    // if(isJson){
    //     //Definit le contenue de la requete comme etant du JSON
    //     req.setRequestHeader("Content-Type", "application/json");
    //     // Transforme la donne du format JSON en format textte avant l'envoi
    //     data = JSON.stringify(data);
    // }
    // req.send(data);
    $.ajax({
        data:data,
        url:url,
        method:'post',
        success: callback,
        error:function(response){
            console.log(response)
        }
    });
}