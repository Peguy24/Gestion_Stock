<?php
require_once("../model/Connection/Connection.class.php");
require_once("../model/Stock/Product.class.php");
require_once("../model/Stock/ProductManager.class.php");
require_once("../model/Unit/UnitManager.class.php");
$con = BddConnection::getConnection()->connect();
global $con;
//$type = $_POST['type'];

function getProduct($id){
    $con = BddConnection::getConnection()->connect();
    $man = new ProductManager($con);
    return $man->getUnique($id);
}

function getUnit($id){
    $con = BddConnection::getConnection()->connect();
    $man = new UnitManager($con);
    return $man->get($id);
}

