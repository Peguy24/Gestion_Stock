<?php
session_start();
require_once("../../model/Connection/Connection.class.php");
require_once("../../model/Stock/Product.class.php");
require_once("../../model/Stock/ProductManager.class.php");

  $con = BddConnection::getConnection()->connect();
   global $con;
   $type = $_POST['type'];
  
  //add
  if($type == 1){
    
    $product_name = htmlspecialchars($_POST['product_name']);
  //	$price = (float)htmlspecialchars($_POST['price']);
    $quantity = (int)htmlspecialchars($_POST['quantity']);
    $comment = htmlspecialchars($_POST['comment']);
  	$created_at = htmlspecialchars($_POST['date']);
    //$response[] = "";
    //$response = $price;
    if(!is_int($quantity) || empty($quantity) || $quantity <= 0)
      {
        $response ='<0';
      }else if($product_name != "" &&  $created_at != ""){
          $manager = new ProductManager($con);
          if($manager->exists($product_name)){
            $response =  'exists';
          }else{
            //$response = "ok";
            try{
              $pro = new Product( 
                [
                    'user_id' => $_SESSION['tf_user_id'], 
                    'product_name' => $product_name, 
                    //'price' => $price, 
                    'comment' => $comment,
                    'quantity' => $quantity,
                    'created_at'=>$created_at
                ]
              );
              $responseManager = $manager->add($pro);
            $response = $responseManager;
            }catch(Exception $e){
              $response = $e->getMessage();
            }
          
            
          }
    }else{
      $response = "empty";
    }
    echo json_encode($response);
  }

//update
  if($type == 2){
    $product_id = (int)htmlspecialchars($_POST['product_id']);
    $product_name = htmlspecialchars($_POST['product_name']);
  //	$price = (float)htmlspecialchars($_POST['price']);
    $quantity = (int)htmlspecialchars($_POST['quantity']);
    $comment = htmlspecialchars($_POST['comment']);
    $manager = new ProductManager($con);
    $response = "";
    $qte = $manager->getUnique($product_id);
    //$response[] = "";
    //$response = $price;
    if(count($qte) == 0){
      $response = "0Prod";
      //|| (!is_float($price) || empty($price) || $price <= 0)
    }else if( (!is_int($quantity) || $quantity < 0))
      {
        $response ='<0';
      }else if($product_name != ""){
         
          if($manager->exists_update($product_name,$product_id)){
            $response =  'exists';
          }else{
           // $response = (int)$qte[0]['quantity'] + $quantity; 
            try{
              $qte = (int)$qte[0]['quantity'] + $quantity; 

              $pro = new Product( 
                [
                    'user_id' => $_SESSION['tf_user_id'], 
                    'product_id' => $product_id,
                    'product_name' => $product_name, 
                    'comment' => $comment,
                    'quantity' => $qte                   
                ]
              );
              $responseManager = $manager->update($pro);
              $response = $responseManager;
              // $response = $pro->product_id()."-".$pro->product_name()."-".$pro->quantity()."-".$pro->price()."-".$pro->comment();
            }catch(Exception $e){
              $response = $e->getMessage();
            }         
            
          }
    }else{
      $response = "empty";
    }
    echo json_encode($response);
  }

  //get
  if($type == 3){
  	$manager = new ProductManager($con);
  	$id = (int)$_POST['id'];
  	$response = $manager->getUnique($id);
  	echo json_encode($response);
  }

//Get all product
  if($type == 4){  	
  	$manager = new ProductManager($con);
  	$response = $manager->getList();
  	echo json_encode($response);
  }

//delete 
  if($type == 5){
    $response = "";
  	$manager = new ProductManager($con);
  	$id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
  	if($_SESSION['tf_status'] == 'administrateur'){
        if(isset($_POST['quantity']) && $_POST['quantity'] !=""){
          $deleteQuantity = $_POST['quantity'];
          $quantityStock = 0;
          $prod = $manager->getUnique($id);
          $quantityStock = count($prod) > 0 ? (int)$prod[0]['quantity'] : 0;

          if($deleteQuantity == "ALL" && count($prod)>0){
            $response = $manager->delete($id);

          }else if($quantityStock !=0 && count($prod) > 0){ 
                    
            if(is_int((int)$deleteQuantity) && $deleteQuantity <= $quantityStock){
              $quantityStock -=$deleteQuantity; 
              $response = $manager->delete_quantity($id,$quantityStock);
            }else{
              $response = "empty1";
            }

          }else if($quantityStock == 0){
            $response = "out";            
          }else{
            $response = "noProdOrFailed";
          }
          
        }else{
          //$response = $manager->delete($id);
          $response = "empty";
        }
    }else{
      $response = "not_privilege";
    }
  	echo json_encode($response);
  }

 

  if($type == 8){



    $to = "dorcealbertmary@gmail.com";
   // $to = "louischeedwichjunior@gmail.com";
    $subject = $_POST['subject'];
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
    <style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th {
        text-align: left;
        padding: 0px;
    }
    td{
     text-align: left;
        padding: 15px;
    }
    tr:nth-child(even){background-color: #808080}
    tr:nth-child(odd){background-color: #808080}

    th {
        background-color: #4CAF50;
        color: white;
    }

    </style>
    </head>
    <body>
    <table>
        <thead >
            <th >Code Produit</th>
            <th >Nom Produit</th>
            <th >Modèle</th>
            <th >Catégorie</th>
            <th >Quantité</th>
        </thead>
        <tbody>';

    $message .= $_POST["message"].'</tbody>
    </table>

    </body>
    </html>
    ';
   //echo $message;
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    
    $headers .= 'From: jehovah.jireh.junck.parts@gmail.com' . "\r\n";
    $headers .= 'Cc: ' . "\r\n";

    mail($to,$subject,$message,$headers);
    echo "success";
  }

  if($type == 9){
   $manager = new ProductManager($con);
    $response = $manager->out_of_stock_soon();

    $header = array("CODE PRODUIT", "NOM PRODUIT" ,"MODELE", "CATEGORIE","QUANTITE");
    $file = fopen("../../../../../../"."prod_out_soon.csv","w");

    fputcsv($file, $header);
    foreach ($response as $line) {
      fputcsv($file, $line);
    }
    fclose($file);
    echo "success";
  }

  if($type == 10){
    $manager = new ProductManager($con);
    $response = $manager->out_of_stock();
    $namefile = "prod_out".rand(10000, 99999);
    $header = array("CODE PRODUIT", "NOM PRODUIT" ,"MODELE", "CATEGORIE","QUANTITE");
    $file = fopen("../../../../../../".$namefile.".csv","w");

    fputcsv($file, $header);
    foreach ($response as $line) {
      fputcsv($file, $line);
    }
    fclose($file);

    /*copy("C:/Users/Albert/Downloads/Sales_2020_10_13.xls","../../res/backup/target.xls");
    unlink("C:/Users/Albert/Downloads/Sales_2020_10_13.xls");*/

    echo "success";
  }

?>