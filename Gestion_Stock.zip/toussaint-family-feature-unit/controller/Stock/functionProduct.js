function tr_factory_prod(data, index, action){
	let tr = '<tr id = "'+data.product_id+'" data-prodName="'+data.product_name+'" data-priceM="'+Number.parseFloat(data.price).toFixed(0)+'" data-qtyM="'+data.quantity+'">';
	let i = index+1; 
	tr += '<td>'+i+'</td>';
	tr += '<td>'+data.product_name+'</td>';
	// tr += '<td>'+Number.parseFloat(data.price).toFixed(0)+'</td>';
	tr += '<td>'+data.quantity+'</td>'; 
	if(action)
		tr += '<td id="qtyRest-'+data.product_id+'">'+data.quantity+'</td>';
	if(action != "accounting"){
		if(!action){
			tr += '<td><a href="unit.php?id='+data.product_id+'" class="edit"';
		}else{
			tr += '<td><button class="prod-add btn btn-success"';
		}
			// tr += '<i class="material-icons update fas fa-edit" data-toggle="tooltip"';
			tr += 'data-product_id="'+data.product_id+'"';
			// tr += 'data-product_code="'+data.product_code+'"';
			tr += 'data-name="'+data.product_name+'"';
			// tr += 'data-category="'+data.product_category+'"';
			// tr += 'data-model="'+data.product_model+'"';
			tr += 'data-price="'+Number.parseFloat(data.price).toFixed(0)+'"';
			tr += 'data-comment="'+data.comment+'"';
			tr += 'data-created_at="'+data.created_at+'"';
			tr += 'data-updated_at="'+data.updated_at+'"';
			tr += 'data-quantity="'+data.quantity+'"';
			// tr += 'data-price_percent="'+data.sale_price_percent+'"';
			// tr += 'data-sale_price="'+Number.parseFloat(data.sale_price).toFixed(0)+'"';
		if(!action){
			tr += '><i class="update fa fa-edit" data-toggle="tooltip"';
			tr += 'title="Edit"></i></a>';
			tr += '&nbsp&nbsp&nbsp&nbsp<a href="#DeleteModal" class="delete" data-toggle="modal" data-prod_id="'+data.product_id+'" data-qty="'+data.quantity+'" data-toggle="modal"><i class="fa fa-trash text-danger" data-toggle="tooltip"';
			tr += 'title="Delete"></i></a></td>';
		}else{
			tr += '><i class="fas fa-plus text-center"></i></button></td>';
		}
	}else{
		tr += "</tr>";
	}
	return tr;
}

function delete_option(){
	$("#num").on("change",function(){
		$("#del_qty").removeAttr("readonly");
		$("#del_qty").attr("type","number");
		$("#del_qty").val("1");
	})
	$("#all").on("change",function(){
		
		toastr.warning("ATTENTION SI VOUS SUPPRIMEZ LE STOCK CE PRODUIT SERA RETIRER DU SYSTEME DEFINITIVEMENT!!")
		$("#del_qty").attr("readonly",true);
		$("#del_qty").attr("type","text");
		//$("#del_qty").remove("type","text");
		$("#del_qty").val("ALL");
		
	})
}