(function($){
	insert_record();
	view_record();
    // //get_record();
	
    update_record();
	//infunctionProduct.js
	delete_option();
    delete_record();
	// placeholder_add();
	// placeholder_update();
	// search();
	// //send_alert();
})(jQuery)





function insert_record(){
	$('#add-prod').on('click',function(e) {
		var data = $("#prod-form").serialize();
		console.log(data);
		$.ajax({
			data:data,
			type: "post",
			url: "../controller/Stock/ProductController.php",
			beforeSend:function(){
				setLoader()
			},
			success: function(dataResult){
				removeLoader()
				console.log(dataResult);
				dataResult = $.parseJSON(dataResult);
				if(dataResult != "failed" && dataResult != "exists" && dataResult != "empty" && dataResult !="<0"){
					toastr.success("PRODUIT AJOUTE AVEC SUCCES")
					setTimeout(() => {
						location.reload();
					}, 2000);
					
				}else if(dataResult== "empty"){
					toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
				}else if(dataResult =="<0"){
					toastr.error("LE PRIX ET LA QUANTITE DOIVENT ETRE DES NOMBRES POSITIF NON NULS !")
				}else if(dataResult == "exists"){
					toastr.warning("NOM PRODUIT DEJA UTILISE !")					
				}else{
					toastr.error("ERREUR DU SYSTEME !!")
				}
					
			},
			error:function(dataResult){
				console.log("ERROR : " + dataResult);
			}
		});
		// }
	});
	}

function view_record(){
	$.ajax({
		data: {type:'4'},
		url : "../controller/Stock/ProductController.php",
		method: 'post',
		success: function(response)
		{
			response = $.parseJSON(response);
			//console.log(response.length);
			if(response.length>0){
				response.forEach(function(data,index){
					let tr = tr_factory_prod(data,index,false);
					$('#t_body_prod').append(tr);
					// console.log(data);
				})
				dataTable("#myTable");
			}
		}
	});
}

function get_record(){
	$.ajax({
		data: {id:'2',type:'3'},
		url : "http://localhost/stock_management/app/controller/stock/ProductController.php",
		method: 'post',
		success: function(response)
		{
			response = $.parseJSON(response);
			console.log(response);
		}
	});
}

/* function that put data in the edit_modal*/
function update_record(){
	$(document).on('click','.edit',function(e) {
		//reset data from form modal
		resetFormModal("update-prod-form");
		

		var id = $(this).attr("data-product_id");
		// var product_code = $(this).attr("data-product_code");
		var name = $(this).attr("data-name");
		// var category = $(this).attr("data-category");
		// var model = $(this).attr("data-model");
		var price = $(this).attr("data-price");
		var comment = $(this).attr("data-comment");
		var quantity = $(this).attr("data-quantity");
		// var price_percent = $(this).attr("data-price_percent");
		// var sale_price = $(this).attr("data-sale_price");
		var creation_date = $(this).attr("data-created_at");
		var updated_at = $(this).attr("data-updated_at");
		$('#prod_id').val(id);
		$('#product-namem').val(name);
		// $('#product_namep').val(name);
		// $('#product_categoryp').val(category);
		// $('#product_modelp').val(model);
		$('#commentm').val(comment);
		$('#quantitym').val(quantity);
		$('#quantityNew').val(0);
		$('#pricem').val(price);
		// $('#sale_price_percentp').val(price_percent);
		// $('#sale_pricep').val(sale_price);
		$('#datem').val(creation_date);
		$('#updated_at').val(updated_at);
	});
	
	$('#update-prod').on('click',function(e){
			
			var data = $("#update-prod-form").serialize();
			console.log(data);
	
			$.ajax({
				data:data,
				type:"post",
				url:"../controller/Stock/ProductController.php",
				beforeSend:function(){
					setLoader()
				},
				success: function(dataResult){
					removeLoader()
					console.log(dataResult);
					dataResult = $.parseJSON(dataResult);
					if(dataResult != "failed" && dataResult != "existe" && dataResult != "empty" && dataResult !="<0"){
						toastr.success("PRODUIT MODIFIE AVEC SUCCES")
						setTimeout(() => {
							location.reload();
						}, 1000);
						
					}else if(dataResult== "empty"){
						toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
					}else if(dataResult =="<0"){
						toastr.error("LE PRIX ET LA QUANTITE DOIVENT ETRE DES NOMBRES POSITIF NON NULS !")
					}else if(dataResult == "existe"){
						toastr.warning("NOM PRODUIT DEJA UTILISE !")					
					}else{
						toastr.error("ERREUR DU SYSTEME !!")
					}
				}
			});
		// }
		});
}

	function delete_record(){
		var id = "";
		$(document).on("click", ".delete", function() {
			resetFormModal("sup-form");
			 id=$(this).attr("data-prod_id");
			let stock_quantity = $(this).attr("data-qty");
			 $("#del_qty").attr("max",stock_quantity);
			 $("#qty_stock").val(stock_quantity);
			//let qty=$(this).attr("data-quantity");
			// //console.log(qty);
			// $('#id_d').val(id);
			// $('#qty_d').val(qty);
			// //console.log($("#qty_d").val());
		});
		var del_option = "1";
		
		$(".option").on("change",function(){
			del_option = $("#del_qty").val() ;
		});
	$('#delete-prod').on('click',function(e){
		//e.preventDefault();
		//let res = confirm("Cette action est definitive !!");
		//if(res == true){
			e.preventDefault();
			del_option = $("#del_qty").val() ;

			$.ajax({
			data: {product_id:id,quantity:del_option,type:5},
			url : "../controller/Stock/ProductController.php",
			method: 'post',
			beforeSend:function(){
				setLoader()
			},
			success: function(dataResult)
			{
				removeLoader()
				var dataResult = $.parseJSON(dataResult);
				console.log(dataResult)
				if(dataResult == 'success'){							
					toastr.success("ACTION REALISEE AVEC SUCCES")
					setLoader()
					setTimeout(() => {
						location.reload();
					}, 1000);

				}else if(dataResult == "empty"){
					toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
					//console.log(delete_data);
				}else if(dataResult == "empty1"){
					toastr.error("VEUILLER ENTRER UN NOMBRE SUPERIEUR A LA QUANTITE EN STOCKE")
					//console.log(delete_data);
				}else if(dataResult == "not_privilege"){
					toastr.warning("VOUS N'AVEZ PAS LA PERMISSION POUR REASLISER CETTE ACTION !");
				}else if(dataResult == "out"){
					toastr.error("La quantite du produit est a Zero!!")
				}
				else{
					toastr.error("ERREUR DU SYSTEME !!")
				}
			}
			});
		
	  //}
	});
}
