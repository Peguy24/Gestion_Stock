<?php
	session_start();
     $name = $_SESSION['name'];
     //echo $name;
	/*$columnHeader = $_SESSION['col'] ;
    $setData = $_SESSION['data'] ;
   
   
	header("Content-type: application/octet-stream");  
    header("Content-Disposition: attachment; filename=".$name.".xls");  
    header("Pragma: no-cache");  
    header("Expires: 0");

    echo ucwords($columnHeader) . "\n" . $setData . "\n"; */
    //copy("C:/Users/Albert/Downloads/".$name.".xls","../".$name.".xls");
    //unlink("C:/Users/Albert/Downloads/".$name.".xls");
            // Recipient 
      $to = 'dorcealbertmary@gmail.com'; 
         
        // Sender 
        $from = 'jehovah.jireh.junck.parts@gmail.com'; 
        $fromName = 'jehovah.jireh.junck.parts'; 
         
        // Email subject 
        $subject = 'PHP Email with Attachment by Albert-Mary';  
         
        // Attachment file 
        $file = "C:/Users/Albert/Downloads/".$name.".xls";
        // $file = "Sales_2020_10_13.xls"; 
         
        // Email body content 
        $htmlContent = ' 
            <h3>PHP Email with Attachment by Albert-Mary</h3> 
            <p>This email is sent from the App script with attachment.</p> 
        '; 
         
        // Header for sender info 
        $headers = "From: $fromName"." <".$from.">"; 
         
        // Boundary  
        $semi_rand = md5(time());  
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
         
        // Headers for attachment  
        $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
         
        // Multipart boundary  
        $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
        "Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
         
        // Preparing attachment 
        if(!empty($file) > 0){ 
            if(is_file($file)){ 
                $message .= "--{$mime_boundary}\n"; 
                $fp =    @fopen($file,"rb"); 
                $data =  @fread($fp,filesize($file)); 
                
                @fclose($fp); 
                $data = chunk_split(base64_encode($data)); 
                $message .= "Content-Type: application/octet-stream; name=\"".basename($file)."\"\n" .  
                "Content-Description: ".basename($file)."\n" . 
                "Content-Disposition: attachment;\n" . " filename=\"".basename($file)."\"; size=".filesize($file).";\n" .  
                "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n"; 
                echo basename($file).' => '.filesize($file);
            } 
        } 
        $message .= "--{$mime_boundary}--"; 
        $returnpath = "-f" . $from; 
         echo $returnpath;
        // Send email 
        $mail = @mail($to, $subject, $message, $headers, $returnpath);  
         
        // Email sending status 
        if($mail){
            unlink("C:/Users/Albert/Downloads/".$name.".xls");
            header("Location:http://localhost/stock_management/app/view/");
            }
        //echo $mail?"success":"<h1>Email sending failed.</h1>";
    //unlink("C:/Users/Albert/Downloads/".$name.".xls");
   // header('Location: ');
?>