/* change function name*/
(function($){
//	console.log("test "+ allUnits)
addProd();
addProdMobile();
calc_change();
remove_item();

$(document).on('click','.plus', function(e){
		e.preventDefault();
		var id = $(this).attr('data-product_base_id');
		plusQty(id);
	});

$(document).on('click','.moins', function(e){
		e.preventDefault();
		var id = $(this).attr('data-product_base_id');
		moinsQty(id);
	});

$(document).on('input','.reduction',function(e){
	//e.preventDefault();
	let reduc = Number($('.reduction').val());
	let tot = Number($('.subtotal').val());
	let cash = Number($('.cash').val());
	//console.log(tot);
	//if($('.reduction').val().length > 10){
	//	window.alert("Vous ne pouvez pas entrer un nombre superieur a 10 chiffres pour la reudction");
	//}
	if(!isNaN(tot)){
		if($('.reduction').val().length <= 7){
			if(reduc < 0){
				window.alert("Vous ne pouvez pas entrer un nombre negatif pour la reudction");
			}
			else if(reduc > tot){
				window.alert("Vous ne pouvez pas rentrer un nombre superieur a la somme total");	
				$('.total').val(tot);
			}else{
				//$('.total').val(Number.parseFloat(tot-reduc).toFixed(2));
				$('.total').val(tot-reduc);
				let newtot = tot-reduc;
				$('.change').val(cash-newtot);
				//calc_change();
			}
		}else{
			window.alert("Vous ne pouvez pas entrer un nombre contenant plus que 5 chiffres pour la reudction");
		}
	}
});


$(document).on('input','.qte',function(e){
	e.preventDefault();
	let id = $(this).attr('data-id');
	let qty = Number($(this).val());

	//get UnitQty
	var unitQty = Number($('#'+id+' .unit_qty').val());
	
	/*Varibles who keeps the sum of quantity who in checkout from others product 
	quantity in order to keep a real quantity each user input a new value*/
	var qtySumRest = 0;
	
	//Get the stock quantity in table prod	
	let newId = id.split("-")[0];
	var stock_qty = Number($('#'+id+' .s_qty').val());
	

	//Calc the sum 
	var testTr = 0;
	$("#tbody_checkout tr").each(function(){
		var currentId = $(this).attr('id');
		if(currentId.split("-")[0] === id.split("-")[0]){
			testTr++;
			if(currentId !== id){
				let currentQty = Number($('#'+currentId+' .qte').val());
				//get UnitQty
				var currentUnitQty = Number($('#'+currentId+' .unit_qty').val());
				//console.log("input test : " + unitQty);
				qtySumRest += currentQty*currentUnitQty;
			}
		}
	});

	if(testTr > 1){
		qtySumRest = stock_qty - qtySumRest;
	}else{
		qtySumRest = stock_qty;
	}
	
	//console.log("sum : "+qtySumRest);
	$('#qtyRest-'+newId).text(qtySumRest);
	
	//var stock_qty = Number($('#'+id+' .s_qty').val());
	var restQty = Number($('#qtyRest-'+newId).text())
	if(Number.isNaN(qty)){
		//console.log('qty');
		cal_tot(id,0);
		$(this).val(0);
		$('#qtyRest-'+newId).text(qtySumRest);
		
	}else if(qty<=0){
		window.alert("La quantite ne peut pas etre negative u egal a zero!");

		$(this).val(0);
		//console.log(qty);
		cal_tot(id,0);
		calc_tot();
		$('#qtyRest-'+newId).text(qtySumRest);
	}else if(qty*unitQty > restQty){
		window.alert("En rupture de stock .");
		$(this).val(1);
		cal_tot(id,1);
		calc_tot();
		$('#qtyRest-'+newId).text(restQty - 1);
		//calc_prod_quantity(id);
	}
	else{
		cal_tot(id,qty*unitQty);
		calc_tot();
		$('#qtyRest-'+newId).text(restQty - unitQty);
		//calc_prod_quantity(id);
	}
});

})(jQuery)

function addProdMobile(){
	$("#add-prod-mobile").on("click",function(e){
		var searchInput = $("#prod_search");
		if(searchInput.val() != ""){
			var search = searchInput.val().split("-")
			var id = search[0];
			searchInput.val("");
			var tr = $("#t_body_prod_sale tr#"+id);
			var name = tr.attr('data-prodName');
			var price = tr.attr('data-priceM');	
			var stock_quantity = tr.attr('data-qtyM');
			console.log(stock_quantity)
			if(stock_quantity <= 0){
				window.alert("En rupture de stock")
			}else{
				chooseUnitSale(id,name,price,stock_quantity);
			}
			resetFormModal("form_search")
		}
	})
}

function calc_prod_quantity(id,isDeleted,isPlus){
	
	var old_qty = Number($('#'+id+' .s_qty').val());

	//Get qty rest in table list prod
	let newId = id.split("-")[0];
	var qtyRest = Number($('#qtyRest-'+newId).text());
	//alert(qtyRest)
	var qty = Number($('#'+id+' .qte').val());
	
	//get UnitQty
	var unitQty = Number($('#'+id+' .unit_qty').val());

	// if(isPlus){
	// 	qty = unitQty;
	// }else{
		
	// }
	//qty = qty * unitQty;
	qty = unitQty;
	var new_qty = 0;
	if(isDeleted){
		 new_qty = qtyRest + qty;
	}else{
		new_qty = qtyRest - qty;
	}
	//put the new quantity in prod table 
	$('.'+id).text(new_qty)


	$('#qtyRest-'+newId).text(new_qty)
	//console.log(old_qty + '-' + qty + '-'+new_qty); 
}

function calc_reduction(){

}
function item_count(){
	var count = 0;
	$("#tbody_checkout tr").each(function(){
		let id = $(this).attr('id');
		let qty = Number($('#'+id+' .qte').val());
		count += qty;
     });
	return count;
}

function subtotal(){
	var subtotal = 0;
	$("#tbody_checkout tr").each(function(){
		let tr = $(this).attr('id');
		let tot = Number($('#'+tr+' .tot').val());
		subtotal += tot;
     });
	return subtotal;
}


function calc_tot(){
	let itemCount = item_count();
	let subTotal = subtotal();

	$('.item_count').val(itemCount);
	//$('.total').val(Number.parseFloat(subTotal).toFixed(2));
	$('.total').val(subTotal);
	//$('.subtotal').val(Number.parseFloat(subTotal).toFixed(2));
	$('.subtotal').val(subTotal);
	//$('.cash').val(subTotal);
}

function calc_change(){
	$('.cash').on('input', function(){
		let cash = Number($(this).val());
		if (isNaN(cash)) {
			window.alert("Le motant doit etre un nombre positif !");
			$(".cash").val(0);
		}else{
		let total = Number($('.total').val());
		//$('.change').val(Number.parseFloat(cash-total).toFixed(2));
		$('.change').val(cash-total);
	}
	});
	
	/*$('.reduction').on('input', function(){
		let cash = Number($('.cash').val());
		if (isNaN(cash)) {
			window.alert("Le motant doit etre un nombre positif !");
			$(".cash").val(0);
		}else{
		let total = Number($('.total').val());
		//$('.change').val(Number.parseFloat(cash-total).toFixed(2));
		$('.change').val(cash-total);
	}
	});*/
}

function remove_item(){
	$(document).on('click', '.del',function(e){
		e.preventDefault();
		let id = $(this).attr('data-id');

		let qty = $('#'+id+' .s_qty').val();
		if(Number(qty)>0){
			$('.'+id).text(qty);

			calc_prod_quantity(id,true)
		  $('#'+id).remove();
  
			calc_tot();
		}
		
			});
}

function prodexist(id){
var test = false;
 $('#checkout tr').each(function(){
 	let idTr= $(this).attr('id');
 	if(idTr == id){
 		test =  true;
 	}
 });
 return test;
}

function plusQty(id){
	var qte = Number($('#'+id+' .qte').val());
	//get UnitQty
	var unitQty = Number($('#'+id+' .unit_qty').val());

	//var stock_qty = Number($('#'+id+' .s_qty').val());
	//Get the quantity rest in table prod
	let newId = id.split("-")[0];
	var stock_qty = Number($('#qtyRest-'+newId).text());
	qte += 1;

	if(unitQty > stock_qty){
		window.alert("En rupture de stock .")
	}else{
			$('#'+id+' .qte').val(qte);
			cal_tot(id,qte);
			calc_tot();
			calc_prod_quantity(id);
		}
}

function moinsQty(id){
	var qte = Number($('#'+id+' .qte').val());
	//get UnitQty
	var unitQty = Number($('#'+id+' .unit_qty').val());
	qte -=1;
			if(qte * unitQty <= 0){
				// $('#'+id+' .qte').val(0);
				// cal_tot(id,0);
				$('#'+id+' .qte').val(1);
				cal_tot(id,1);
			}else{
				$('#'+id+' .qte').val(qte);
				cal_tot(id,qte);
				calc_prod_quantity(id,true);
			}
			calc_tot();
			
}

function cal_tot(id, qty){

	let price = Number($('#'+id+' .price_s').val());
	$('#'+id+' .tot').val(price*qty);
}

function tr_Check_factory(id,name,price,s_qty,unit_qty,unit_id){
	
let tr = '<tr id = "'+id+'" class="checkout-item">';
tr += '<input type="hidden" class="s_qty" name="'+id+'qty" value="'+s_qty+'"/>';
//Unit inormations
tr += '<input type="hidden" class="unit_qty" name="'+id+'unit_qty" value="'+unit_qty+'"/>';

tr += '<input type="hidden" class="price_s" name="'+id+'price" value="'+price+'"/>';
tr += '<input type="hidden" class="id_prod" name="id_prod" value="'+id+'"/>';
//tr += '<td><a href="#" class="del" data-id="'+id+'">X</a></td>';
tr += '<td class="td-name w-50 mw-50"><a href="#" class="del p-1 pb-1" data-id="'+id+'"><i class="fa fa-times text-danger"></i></a> <span class="prod_name">'+name+'</span></td>';
tr += '<td>'+price+'</td>';
tr += '<td class="quantity d-flex  mx-0"><a href="#" data-product_base_id="'+id+'"class="moins d-flex align-self-center w-25 mw-25"><i class="fas fa-minus text-center ml-0 p-0"></i></a>';
tr += '<input class="qte form-control text-center d-flex align-self-center w-100" type="text" min="1"  name="'+id+'qte" data-id="'+id+'" value="1" readonly/>';
tr += '<a href= "#" data-product_base_id="'+id+'"  class="plus d-flex align-self-center w-25 mw-25"><i class="fas fa-plus text-center ml-0 p-0"></i></a></td>';
tr += '<td ><input type="text" class="tot form-control text-center m-0 p-0" name="tot_price_prod" value="'+price+'" readonly="true"/></td></tr>';

return tr;
}


function addProdCallBack(id,name,price,stock_quantity,unit_qty, unit_id){
	//console.log("addProdCallBack"+stock_quantity +"-"+unit_qty)
	//console.log("addProdCallBack"+ $("#teststock").val())
	id += '-' + unit_id;
	//if(stock_quantity<=0 ){
		//window.alert('En rupture de stock 1).');
	//}else if(unit_qty < stock_quantity){
		//$("#teststock").val(0)
		
		//window.alert('En rupture de stock 2).');
		console.log("ok")
	//}else{
		if(prodexist(id)){
		plusQty(id);
		}else{
			let tr = tr_Check_factory(id,name,price,stock_quantity,unit_qty, unit_id);
			$('#tbody_checkout').append(tr);
			calc_tot();
		}
		calc_prod_quantity(id);
//	}
	
}

function putUnitSale(unitSale){
	console.log(unitSale.length)
	//Clean datalist before open modal
	$('#unitSale').html("");
	
	unitSale.forEach(function(data,index){
		//console.log(data.unitName +"-"+data.unitPrice+"-"+data.unitQty);
		var option = '<option value="'+data.unitName
		//option += "-"+data.unitQty;
		//option += "-"+data.unitPrice;
		option += '"/>';
		$('#unitSale').append(option);
	})
}

function chooseUnitSale(id,name,price,stock_quantity,rest_quantity){	
	
	//Call this method in order to get unit of a product who is in saleFunctions file
	var unitSale = getUnitSale(id);
	
	if(unitSale.length > 0){

			putUnitSale(unitSale);
			var unitSelected = [];
			$('#unitSaleSearch').off();
			$('#unitSaleSearch').on('input', function(e){
				
				unitSelected = unitSale.filter(function(unit){ 
					return e.target.value === unit.unitName
				})

				//Put more informations in modal
				let unitPriceInput = $("#unitPrice");
				let unitQtyInput = $("#unitQty");
				if(unitSelected.length > 0){
					if(unitSelected[0].unitQty > rest_quantity){
						//show error
						toastr.error("LA QUANTITE DE L'UNITE SELECTIONNER DOIT ETRE INFERIEURE A LA QUANTITE RESTANTE!")
					}
						unitPriceInput.val(unitSelected[0].unitPrice);
						unitQtyInput.val(unitSelected[0].unitQty);
					
				}else{
					unitPriceInput.val(0);
					unitQtyInput.val(0);
				}
				
			})

			
			$("#UnitSaleModal").modal();

			//When modal hide
			$("#UnitSaleModal").on('hidden.bs.modal', function(){
				//stock_quantity2 = 0;
				//console.log("chooseUnitSale modal close - "+stock_quantity)
				resetFormModal("unit-sale-form");
			});

			$("#addUnit-sale").off();
			$("#addUnit-sale").on('click', function(){
				if(unitSelected.length < 0){
					//console.log("chooseUnitSale click - "+stock_quantity)
					
					toastr.error("VEUILLER SELECTIONNER UNE UNITE POUR CE PRODUIT!")
					console.log("ERROR")
				}else if(unitSelected[0].unitQty > rest_quantity){
					toastr.error("LA QUANTITE DE L'UNITE SELECTIONNER DOIT ETRE INFERIEURE A LA QUANTITE RESTANTE!")
				}else{
					addProdCallBack(id,unitSelected[0].unitName,unitSelected[0].unitPrice,stock_quantity,unitSelected[0].unitQty,unitSelected[0].unitId);
					$("#UnitSaleModal").modal("hide");
				}
				
			})
		}else{
			$("#UnitSaleModal").modal("hide");
			toastr.error("VEUILLER AJOUTER AU MOINS UNE UNITE POUR CE PRODUIT!")
		}		
}

function addProd(){
	$(document).on('click','.prod-add', function(e){
		e.preventDefault();
	
		var id = $(this).attr('data-product_id');
		var name = $(this).attr('data-name');
		var price = $(this).attr('data-price');
		//stock_quantity2 = $(this).attr('data-quantity');
		var stock_quantity = $(this).attr('data-quantity');
		var rest_quantity = Number($('#qtyRest-'+id.split("-")[0]).text());
		if(rest_quantity == 0){
			//show error
			toastr.error("EN RUPTURE DE STOCKE !")
		}else{
			
		chooseUnitSale(id,name,price,stock_quantity,rest_quantity)
		}
		//console.log("ADDProd"+stock_quantity2)
		
		
	});
}
