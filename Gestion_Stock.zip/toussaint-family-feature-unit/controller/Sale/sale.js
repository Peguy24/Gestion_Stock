(function($){
	$(window).on("load", function(){

	var url = "";
	insert_sale();
	//$('#valider').attr('disabled');
	view_sales();
	view_prod();
	// cancel_sale();
	// percent_price_calc();
	// search();
	// exportExecel();
	// export_excel_daily_sale();
	//test();
	// solde_amount();
	/*let ch = solde_amount();
	setInterval(ch,2000);*/
	print();
	//test();
    get_record();
   // update_record();
    delete_record();
   //setInterval(function(){hello();},3000);
   $("#connexion").click(function(){
		 //window.alert("ok");
		 //closeModalConnection();
	 })

	 $("#cancel-sale").on("click",function(){
		resetFormModal("checkout")
		$("#tbody_checkout").empty()
	 })

	 $("#close_sale,#cancel_sale_modal").click(function(){
	 	$('.reduc_button').show();
					
		$('#reduc_input').hide();
		$("#username").val("");
		$("#pass").val("");
		 closeModalSale();
	 })
	 second_login();
	})
})(jQuery)
//Login for a adm or sup in order to make a discount

function view_sales(){
	$.ajax({
		data: {type:'4',isReturned:0},
		url : "../controller/Sale/SaleController.php",
		method: 'post',
		success: function(response)
		{
			//console.log(response);
			response = $.parseJSON(response);
			//console.log(response.length);
			if(response.length>0){
				response.forEach(function(data,index){
					//console.log(data);
					let tr = tr_factory_sale(data,index);
					$('#t_body_sale').append(tr);
					
				})
				dataTable("#tableSale")				
			}
		}
	});
}
function second_login(){
	$("#connexion").click(function(){
		 //window.alert("ok");
		 //closeModalConnection();
		 var username = $("#username").val();
		 var pass = $("#pass").val();
		 if(username != "" && pass != ""){
		 	setLoader();
		 	$.ajax({
			data: {username:username,pass:pass,type:1},
			type: "post",
			url: "http://localhost/stock_management/app/controller/account/AccountController.php",
			success: function(dataResult){
					//console.log(dataResult);
			     if(dataResult != false){
						dataResult = $.parseJSON(dataResult);
						if(dataResult.account_state == 'active'){
							if(dataResult.status == 'administrateur' || dataResult.status == 'superviseur'){
								$('.action-container').hide();
								//$('#reduc_button_tr').hide();						
								$('#reduc_input').show();
						closeModalConnection();	
						hideLoader();	
							}else{
								window.alert("Vous n'avez pas l'autorisation");
								hideLoader();
							}
						}else{
							window.alert('COMPTE INACTIVE !');
							hideLoader();
						}
						
					}
					else {
					   window.alert('INCORECT LOGIN !');
					   hideLoader();
					}
				}
			});
		 
		}else{
		 	window.alert("Veuillez remplir tous les champs !!");
		 	hideLoader();
		 }
		 
	 })
}
function export_excel_daily_sale(){
	$("#export-daily-sale").click(function(){
	 	var sales = [];
   		 $("#t_body_daily_sales tr").each(function(){
   		 	let tr_id = $(this).attr('id');
   		 	let sale_code = $('#'+tr_id+' .sale_code').text();
   		 	let item_count = $('#'+tr_id+' .item_count_s').text();
   		 	let sale_amount = $('#'+tr_id+' .sale_amount').text();
   		 	let cash = $('#'+tr_id+' .cash').text();
   		 	let due = $('#'+tr_id+' .due').text();
   		 	let sale_date = $('#'+tr_id+' .sale_date').text();
   		 	let first_name = $('#'+tr_id+' .first_name').text();
   		 	sales.push(sale_factory(sale_code,first_name,item_count,sale_amount,cash,due,sale_date));

   		 	//console.log(sale_factory(sale_code,item_count,sale_amount,sale_date));

     	 	//window.alert(sale_code +'=>'+item_count+'=>'+sale_amount+'=>'+sale_date);
   		 });

   		// console.log(sales);
   		if(sales.length > 0){
   			setLoader();
   			var date = new Date();
			var month = date.getMonth()+1;
			var year = date.getFullYear();
			var  day = date.getDate();
			var fromatDate = year+"-"+month+"-"+day;
   		$.ajax({
			data: {date:fromatDate,type:15},
			type: "post",
			url: "http://localhost/stock_management/app/controller/sale/SaleController.php",
			success: function(dataResult){
					//var dataResult = JSON.parse();
					console.log(dataResult);
					if(dataResult == 'success'){
						//$('#addEmployeeModal').modal('hide');

						window.alert('Operation réussie Emplacement "C:" !');

						hideLoader();
                        //location.reload();
                       // window.location.href = 'http://localhost/stock_management/app/controller/sale/excel.php';
					}
					else {
					   window.alert(dataResult);
					   hideLoader();
					}
			}
		});
   	}else{
   		window.alert("Il n'y a pas encore de vente realisee aujourd'hui");
   	}
  });
}


function out_of_stock_soon_s(reload){
	$.ajax({
		data: {type:'7'},
		url : "http://localhost/stock_management/app/controller/stock/ProductController.php",
		method: 'post',
		success: function(response)
		{
			response = $.parseJSON(response);
			//window.alert('soon');
			if(response.length > 0){
				//window.alert('soon');
				send_message(response,'Produit Bientot En Rupture De Stocke ',reload);
			}else{
				if(reload){
					location.reload()
				}
			}
		}
	});
}

function tr_prod(data, index){
	let tr = '<tr>';
	tr += '<td>'+data.product_code+'</td>';
	tr += '<td>'+data.product_name+'</td>';
	tr += '<td>'+data.product_model+'</td>';
	tr += '<td>'+data.product_category+'</td>';
	tr += '<td>'+data.product_quantity+'</td></tr>';

	return tr;
}


function out_of_stock_s(reload){
	$.ajax({
		data: {type:'6'},
		url : "http://localhost/stock_management/app/controller/stock/ProductController.php",
		method: 'post',
		success: function(response)
		{
			response = $.parseJSON(response);
			console.log(response.length);
			//$('#stock_rupture').text(response.length);
			if(response.length > 0){
				//window.alert('out of stock');
				send_message(response,"Produit En Rupture De Stocke",reload);
			}else{
				if(reload){
					location.reload()
				}
			}
		}
	});
}

/*function initTable(){
		$(document).ready(function(){
	   		$("#myTable").dataTable();
	 	});
}*/


function cancel_sale(){
	$(document).on('click','#annuler', function(e){
		e.preventDefault();
		let test = confirm("Voulez-vous vraiment supprimer cette vente!");
		  if(test){
		  	location.reload();
		  }
	})
}

function tr_prod_factory(data, index){
	let tr = '<tr id = "'+data.product_id+'">';
	tr += '<td>'+data.product_code+'</td>';
	tr += '<td>'+data.product_name+'</td>';
	tr += '<td>'+data.product_model+'</td>';
	tr += '<td>'+data.product_category+'</td>';
	tr += '<td>'+data.sale_price+'</td>';
	tr += '<td class="'+data.product_id+'">'+data.product_quantity+'</td>';
	//tr += '<td>'+Number.parseFloat(data.sale_price).toFixed(2)+'</td>';
	//tr += '<td style="text-align:center" class="">'+data.product_quantity+'</td>';
	tr += '<td><button  class="prod-add"';
	tr += 'data-product_base_id="'+data.product_id+'"';
	tr += 'data-name="'+data.product_name+'"';
	tr += 'data-comment="'+data.product_comment+'"';
	tr += 'data-quantity="'+data.product_quantity+'"';
	tr += 'data-price_percent="'+data.sale_price_percent+'"';
	tr += 'data-sale_price="'+data.sale_price+'"';
	tr += '><i class="fas fa-plus"></i></button></td>';

	return tr;
}

function view_prod(){
	//$(window).on("load", function(){
		$.ajax({
			data: {type:'4'},
			url : "../controller/Stock/ProductController.php",
			method: 'post',
			success: function(response)
			{
				response = $.parseJSON(response);
				//console.log(response.length);
				if(response.length>0){
					response.forEach(function(data,index){
						let tr = tr_factory_prod(data,index,true);
						$('#t_body_prod_sale').append(tr);
						//
						var option = '<option value="'+data.product_id
						option += "-"+data.product_name;
						option += '"/>';
						$('#productsM').append(option);
					})
					dataTable("#tableProdSale",true);
					dataTable("#customers",true)
				}
			}
		});
//	})
}

function line_prod_fac(prodId,prodName,qty,price,qte,total,unitQty){
	return{
		product_id:prodId,
		unit_name:prodName,
		quantity:qty,
		price:price,
		total:total,
		qte:qte,
		unit_quantity:unitQty
	};
}

function delete_sale_error(){
	$.ajax({
				data: {type:18},
				type: "post",
				url: "http://localhost/stock_management/app/controller/sale/SaleController.php",
				success: function(dataResult){
						console.log(dataResult)
				}
			});
}

function getSaleLine(Auth,data){
	var content = "";
	content += "<center><h3>TOUSSAINT FAMILY</h3></center>";
								content += "<center><h5>"+ data.sale_date + " " + data.sale_time+"</h5></center>";
								content +="<center><h5>#facture : "+data.sale_code +"</h5></center>";
								content += "<center><h5>caisse : "+data.first_name +"</h5></center>";
								if(Auth != ""){
									content += "<center><h5>Authorization : "+Auth.Autho_name +"</h5></center>";
								}
			
								content += '<table class="table" style="width:100%;text-align:left;">';
								content += "<thead><tr><th class='description'>PRODUIT</th><th class='quantity'>Q.</th><th class='price'>PRIX UNITAIRE</th><th class='price'>TOTAL</th></tr></thead><tbody>";

	$.ajax({
		data: {saleId:data.sale_id,type:28},
		type: "post",
		url: "../controller/Sale/SaleController.php",
		success: function(dataResult){
			console.log("Sale_line 1: "+dataResult)
			response = $.parseJSON(dataResult);
			if(response.length>0){
				response.forEach(function(prod_line,index){
					//console.log(data.sale_code)
					content += "<tr><td class='description'>" +prod_line.product_name + "</td><td class='quantity'>" + Number.parseFloat( prod_line.quantity).toFixed(2) + "</td><td class='price'>" + prod_line.price +"</td><td>" + prod_line.total + "</td>";
					//console.log("SaleLigne " + data.product_id);
				})
				content += "</tbody><div class='foot'><tr><td colspan='2'></td><td>Sous-total</td><td>"+ Number.parseFloat(data.sale_amount).toFixed(2) +"</td></tr>";
								// content += "<tr><td colspan='2'></td><td>Reduction</td><td>"+ data.discount +"</tr>";
								if(data.amount_discount == '0.00'){
									content += "<tr><td colspan='2'></td><td>Total</td><td>"+ data.sale_amount +"</tr>";
								}else{
									content += "<tr><td colspan='2'></td><td>Total</td><td>"+ data.amount_discount +"</tr>";
								}
								content += "<tr><td colspan='2'></td><td>Cash</td><td>"+ data.cash +"</tr>";
								content += "<tr><td colspan='2'></td><td>Change</td><td>"+ data.due +"</tr>";
								content += "<tr><td colspan='2'></td><td>Item count</td><td>"+ data.item_count +"</tr>";
								content += "</div></table>";
								sessionStorage.setItem("printContent", content);
								$("#add-sale").hide()
								$("#print-sale").show()
								$("#user-form").html(content);
							
			}
		}
		});
}

function getUserAuth(saleInf){
	//var content = "";
	$.ajax({
		data: {saleId:saleInf.sale_id,type:29},
		type: "post",
		url: "../controller/Sale/SaleController.php",
		success: function(dataResul){
			console.log("User 1: "+dataResul);
			respons = $.parseJSON(dataResul);
			if(respons.length>0){
				respons.forEach(function(dat,index){
					getSaleLine(dat, saleInf);
					
					console.log("UserAuth: " + dat.sale_id);
				})
			}else{
				getSaleLine("", saleInf);
			}
		}
		});
}


function getFullInfoSale($saleCode){
	//var content = "";
	$.ajax({
		data: {saleCode:$saleCode,type:27},
		type: "post",
		url: "../controller/Sale/SaleController.php",
		success: function(dataResult){
			//console.log("Sale 1 : "+dataResult)
			response = $.parseJSON(dataResult);
			if(response.length>0){
				response.forEach(function(data,index){
					console.log("Sale :"+data.sale_id);
					//getUserAuth(data);
					getSaleLine("", data);				
				});
			}
		}
		});
}




function insert_sale(){	

	$('#add-sale').on('click',function(e) {
		//let checkout  = $('#tbody_checkout').text();

		// var response = confirm("Voulez-vous Valider Cette Vente ?");
		// if(response == true){

		e.preventDefault();
		// $('#reduc_button_tr').hide();
		var total = Number($('.totalm').val());
		var cash = Number($('.cashm').val());
		// console.log(cash)
		// var reduction = Number($(".reductionm").val());
		//var count = $('.reduction').val().length > 7;
		// console.log($('.reduction').val().length > 7);
		// if(reduction < 0){
		// 	window.alert("Vous ne pouvez pas entrer un nombre negatif pour la reduction");
		// }else 
		// if(reduction > total){
		// 	window.alert("Vous ne pouvez pas rentrer un nombre superieur a la somme total pour la reduction !");
		// }
		// else
		 if(total == 0){
			toastr.info("Veuillez Ajouter Un Produit !");
			setTimeout(() => {
			 location.reload();
			}, 2000);
		}else if (cash == 0){
			toastr.error("Veuillez Entrer Le montant Recu ! !");
		}
		else if(cash < total){
			toastr.error("Le Montant Recu est insuffisant !");
		}else{
			//setLoader();
			var d = new Date();
			var time_sa = d.getHours()+':'+d.getMinutes()+':'+d.getSeconds();
			var sale = {
			subtotal:$('.subtotalm').val(),
			total:$('.totalm').val(),
			change:$('.changem').val(),
			cash:$('.cashm').val(),
			item_count:$('.item_countm').val(),
			sale_time: time_sa,
			reduction:''
			// reduction:$('.reductionm').val()
			};
			var prod_line = [];

			$("#tbody_checkout tr").each(function(){
				let id = $(this).attr('id');
				//console.log(id)
				let name = $('#'+id+' .prod_name').html();
				//console.log(name);
				let qty = Number($('#'+id+' .qte').val());
				//get UnitQty
				var unitQty = Number($('#'+id+' .unit_qty').val());
				
			//	console.log("UNIT : "+qty)
				let price = $('#'+id+' .price_s').val();
				let total = $('#'+id+' .tot').val();
				let qte = $('#'+id+' .s_qty').val();

				//Get id without unit name
				id = $(this).attr('id').split("-")[0];
				prod_line.push(line_prod_fac(id,name,qty,price,qte,total,unitQty));
    		 });
			//console.log(prod_line);

			$('#addEmployeeModal').modal('hide');
			$.ajax({
				data: {sale:sale,line:prod_line,type:1},
				type: "post",
				url: "../controller/Sale/SaleController.php",
				beforeSend:function()
				{
					setLoader();
				},
				success: function(dataResult){
						//var dataResult = JSON.parse();
						console.log(dataResult);
						var data = dataResult;
						var dataResult = parseInt(dataResult);
						console.log(dataResult);
						
						if(dataResult >= 0){
							//$('#addEmployeeModal').modal('hide');
							//window.alert('Operation réussie !');
							// out_of_stock_soon_s(false);
	                        // out_of_stock_s(false);
							/*var print_resp = window.confirm("Imprimer !!");
							if(print_resp == true){*/
								//$("#divToPrintContent").show();
								$('.cashmp').val(0)
								toastr.success("Vente realisée avec success !")
								
								//$("#AddModal").modal("hide");

								// setTimeout(() => {
								// 	location.reload();
								//    }, 2000);
								//alert(sale)
							// 	// console.log('test2: '+data);
							getFullInfoSale(dataResult);
							removeLoader()
							$('#AddModal').on('hide.bs.modal', function (e) {
								location.reload()
							  })							
							//$("#AddModal").modal("show");
						
							// 	// closeModalSale();
								
							// $("#print-modal").show();
							// hideLoader();
	                        //location.reload();
	                        
	                        //location.reload();
							//$("#print-modal").show();
						}
						else {
						   console.log(dataResult);
						   delete_sale_error();
						   window.alert("Error System !");
						   location.reload();
						}
				}
			});
		}
	// }else{
	// 	location.reload();
	// }
		//Test if div printmodal is empty in order to show print modal

	});
	}


	function sale_factory(sale_code,first_name,item_count,sale_amount,cash,due,sale_date){
		return {
			sale_code:sale_code,
			first_name:first_name,
			item_count:item_count,
			sale_amount:sale_amount,
			cash:cash,
			due:due,
			sale_date:sale_date
		};
	}

	function exportExecel(){
	 $("#export").click(function(){
	 	var sales = [];
   		 $("#t_body_sales tr").each(function(){
   		 	let tr_id = $(this).attr('id');
   		 	let sale_code = $('#'+tr_id+' .sale_code').text();
   		 	let item_count = $('#'+tr_id+' .item_count_s').text();
   		 	let sale_amount = $('#'+tr_id+' .sale_amount').text();
   		 	let cash = $('#'+tr_id+' .cash').text();
   		 	let due = $('#'+tr_id+' .due').text();
   		 	let sale_date = $('#'+tr_id+' .sale_date').text();
   		 	let first_name = $('#'+tr_id+' .first_name').text();
   		 	sales.push(sale_factory(sale_code,first_name,item_count,sale_amount,cash,due,sale_date));
   		 	
   		 	//console.log(sale_factory(sale_code,item_count,sale_amount,sale_date));

     	 	//window.alert(sale_code +'=>'+item_count+'=>'+sale_amount+'=>'+sale_date);
   		 });

   		// console.log(sales);
        if(sales.length > 0){
        	setLoader();
   		$.ajax({
			data: {sale:sales,type:8},
			type: "post",
			url: "http://localhost/stock_management/app/controller/sale/SaleController.php",
			success: function(dataResult){
					//var dataResult = JSON.parse();
					console.log(dataResult);
					if(dataResult == 'success'){

						//$('#addEmployeeModal').modal('hide');
						hideLoader();
						window.alert('Operation réussie Emplacement du fichier "C:"!');
                        //location.reload();
                       // window.location.href = 'http://localhost/stock_management/app/controller/sale/excel.php';
					}
					else {
					   window.alert(dataResult);
					   hideLoader();
					}
			}
		});
   	}else{
   		window.alert("Il n'y a pas encore de vente realisee aujourd'hui");
   	}
  });
}



function get_record(){
	$(document).on('click','.update', function(e){
		var id = $(this).attr("data-id");
		var name = $(this).attr("data-name");
		var status = $(this).attr("data-status");
		var date = $(this).attr("data-date");
		var somme = $(this).attr("data-sale_amount");

		$('#id_s').val(id);
		$('#sale_code').val(id);
		$('#user').val(name);
		$('#status').val(status);
		$('#sale_amount').val(somme);
		$('#date').val(date);
	});
}

function delete_sale(id){
	//$('#Delete_Modal').modal('show');
	$("#delete-sale").on("click", function(e){
		$.ajax({
		data: {id:id,type:'5'},
		url : "../controller/Sale/SaleController.php",
		method: 'post',
		beforeSend:function(){
			//disable btn-add

			//
			setLoader()
		},
		success: function(dataResult)
		{
			removeLoader()
			//console.log(dataResult)
			dataResult = $.parseJSON(dataResult);
			if(dataResult == 'success'){
						$('#DeleteModal').modal('hide');
						//var id = $("#id_d").val();
						//alert(id)
					//$("#"+id).remove();
					toastr.success("ACTION REALISEE AVEC SUCCES")
					setTimeout(() => {
						location.reload();
					}, 2000);
			}else if(dataResult == "not_privilege"){
				alert("NOT Privilege")
			}else{
				alert(dataResult)
			}
		}
		});
	});
}

function delete_record(){
	$(document).on("click", ".delete", function() {
			var id=$(this).attr("data-id");
			//$('#id_d').val(id);
			delete_sale(id);
		});

	// $(document).on("click","#btn-log", function(){
	// 	var data = $('#log_form').serialize();

	// 	$.ajax({
	// 		data: data,
	// 		type: "post",
	// 		url: "http://localhost/stock_management/app/controller/account/AccountController.php",
	// 		success: function(dataResult){
	// 			//console.log(dataResult);
	// 				if(dataResult != false){
	// 					dataResult = $.parseJSON(dataResult);
	// 					if(dataResult.status == 'adm'){
	// 						$('#Log_Modal').modal('hide');
	// 						delete_sale();
	// 					}else{
	// 						alert("Vous n'avez pas l'autorisation pour effectuer cette operation!");
	// 					}

	// 					//alert('Data added successfully !');
    //                     //location.reload();
	// 				}
	// 				else {
	// 				   alert('INCORECT LOGIN !');
	// 				}
	// 		}
	// 	});
	// });
}

function print(){
	$("#print-sale").click(function(){
              
		window.location.href = 'print.html';
	  });
    //    $('#print').on('click', function(e){
    //    	e.preventDefault();
    //    	$('#print').hide();
    //    	$('#annuler').hide();
    //    	$('#valider').hide();
    //    	var divToPrint = document.getElementById('checkout');
    //    var popupWin = window.open('', '_blank', 'width=1200,height=300');
    //    popupWin.document.open();
    //    popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
    //     popupWin.document.close();
    //    });
}

function search(){
	 $("#myInput").on("keyup", function() {
     var value = $(this).val().toLowerCase();
$("#tbody_sale_prod tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	});
});
}

// function percent_price_calc(price, percent){
// 	if($('#sale_price_percent').val() == '' || price == ''){
// 		$('#sale_price').val('');
// 	}else{
// 		let percent_price = (percent * price)/100;
// 		let amount = percent_price +"+"+ price;
// 		return Math.round(eval(amount));
// 	}
// 	return 0;
// }

// $('#sale_price_percent').on('input',function(e) {
// 	let price = $('#price').val();
// 	let percent = $('#sale_price_percent').val();

// 		let percent_price = percent_price_calc(price,percent);
// 		$('#sale_price').val(percent_price);
// }
// );

// $('#price').on('input',function(e) {
// 	let price = $('#price').val();
// 	let percent = $('#sale_price_percent').val();


// 		let percent_price = percent_price_calc(price,percent);
// 		$('#sale_price').val(percent_price);

// }
// );

$(document).ready(function(){
$("#myInput").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#t_body tr").filter(function() {
	$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});
