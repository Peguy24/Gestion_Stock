<?php
// Import de la classe
session_start();
require_once("../../model/Connection/Connection.class.php");
require_once("../../model/Sale/Sale.class.php");
require_once("../../model/Sale/SaleManager.class.php");
require_once("../../model/Sale/SaleLine.class.php");
require_once("../../model/Sale/SaleLineManager.class.php");
require_once("../../model/Stock/ProductManager.class.php");

   $con = BddConnection::getConnection()->connect();
   global $con;

   function get($id){
    $con = BddConnection::getConnection()->connect();
    $manager = new SaleManager($con);

    $response = $manager->get($id);
   return $response;
   }

   function getSaleLine($id){
    $con = BddConnection::getConnection()->connect();
       $man = new SaleLineManager($con); 
    $res = $man->get($id);
    return $res;
   }

   function get_qty($id){
    $con = BddConnection::getConnection()->connect();
       $man = new SaleLineManager($con); 
    $res = $man->get_qty($id);
    return $res;
   }

   $type = 0;
//var_dump(get_qty(4));
   //$type = $_POST['type'];

  //add
  if($type == 1){

    //Add a sale
    $sale = $_POST['sale'];
  	// echo ($userid.' '.$amount);
    $code = date("Y"). date("m") . rand(10000, 99999);
    $sale = new Sale([
  				'user_id'=>$_SESSION['user_id'],
  				'sale_code'=>$code,
          'sale_amount'=>$sale['total'],
          'cash'=>$sale['cash'],
          'due'=>$sale['change'],
          'item_count'=>$sale['item_count']
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->add($sale);
   // echo json_encode($response);
  	if(count($response)>0){
     $sale_id = $response['sale_id'];
     $line = $_POST['line'];
     $response2;
     for($i=0;$i<count($line);$i++){
     // foreach ($line[$i] as $key => $value) {
        //if($key == 'total'){
          //echo $key.'=>'.$value;
       // }
        $saleLine = new SaleLine($line[$i]);
        $saleLine->setSale_id($sale_id);
        $qte = $line[$i]['qte'];
        //$saleLine->setProduct_id(16);
        //echo ($saleLine->product_id().'='.$saleLine->total().'='.$saleLine->quantity().'='.$saleLine->price());
        $manager2 = new SaleLineManager($con);        
        $res = $manager2->add($saleLine,$qte);
        $response2 =  $res;
        if($res != 'success'){
          $response2 = 'failed';
          return;
        }
     // }
     }
     echo ($response2);
    }else{
      echo "string";
    }
  }

  /*if($type == 7){
   $line = $_POST['line'];
   echo json_encode($line[0]['nom']);
  }*/

//update
  if($type == 2){
  	$sale = new Sale([
  		'sale_id'=>'1',
  		'user_id'=>'1',
  		'sale_date'=>'2020-08-28',
  		'sale_amount'=>'750'
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->update($sale);
  	echo $response;
  }

  //get
  if($type == 3){
  	$manager = new SaleManager($con);

  	$response = $manager->get(1);
  	var_dump($response);
  }

//Get all data
  if($type == 4){
  	$manager = new SaleManager($con);

  	$response = $manager->getList();
  	echo json_encode($response);
  }
//delete 
  if($type == 5){
  	$manager = new SaleManager($con);
    $id = $_POST['id'];
  	$response = $manager->delete($id);
  }

  if($type == 6){
   $manager = new SaleManager($con);
   
    $response = $manager->getSales();

    $columnHeader = '';
    $columnHeader = "Sale Code" . "\t" . "User Id" . "\t" . "Sale Amount" . "\t";  
    $setData = '';
    
    //echo json_encode($response);
    //var_dump($response);
    while ($data = $response->fetch(PDO::FETCH_ASSOC))
    {
      $rowData = '';
      foreach ($data as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
      } 
      $setData .= trim($rowData) . "\n";
    }
    $name = date("Y").'/'.date("m").'/'. date("d");
    //echo $name;
    header("Content-type: application/octet-stream");  
    header("Content-Disposition: attachment; filename=Sales_".$name.".xls");  
    header("Pragma: no-cache");  
    header("Expires: 0"); 

    echo ucwords($columnHeader) . "\n" . $setData . "\n";
    copy("C:/Users/Albert/Downloads/Sales_2020_10_13.xls","../../res/backup/target.xls");
    unlink("C:/Users/Albert/Downloads/Sales_2020_10_13.xls");

  }

  if($type == 7){
    copy("C:/Users/Albert/Downloads/Sales_2020_10_13.xls","../../res/backup/target.xls");
    unlink("C:/Users/Albert/Downloads/Sales_2020_10_13.xls");
  }
  
  if($type == 8){
    $sales = $_POST['sale'];
    $columnHeader = '';
    $columnHeader = "Sale Code" . "\t" . "Qte Articles" . "\t" . "Sale Amount" . "\t" . "Date" . "\t";  
    $setData = '';
    
    foreach ($sales as $val) {  
        $rowData = '';
       foreach ($val as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
       } 
       $setData .= trim($rowData) . "\n";
   } 
   $name = date("Y").'/'.date("m").'/'. date("d");
    //echo $name;
   $_SESSION['col'] = $columnHeader;
   $_SESSION['data'] = $setData;
   $_SESSION['name'] = 'sales_'.$name;
   echo 'success';
  }
  
  if($type == 9){
    $manager = new SaleManager($con);
    $date = date("Y").'-'.date("m").'-'.date("d");
    $res = $manager->solde_amount($date);
    echo($res['sum']);
  }

  if($type == 10){
     $manager = new SaleManager($con);
     $date = date("Y").'-'.date("m").'-'.date("d");
     $res = $manager->sale_count($date);
     echo $res['sum'];
    // print_r(localtime());
  }

  if($type == 11){
     $manager = new SaleManager($con);
     $date = date("Y").'-'.date("m").'-'.date("d");
     $res = $manager->sale_daily($date);
     echo json_encode($res);
     //echo $date;
  }

  if($type == 12){
     $manager = new SaleManager($con);
     $date1 = date("Y").'-'.date("m").'-'.'01';
     $date2 = date("Y").'-'.date("m").'-'.'31';
     $res = $manager->sale_monthly($date1,$date2);
     echo json_encode($res);
  }

  if($type == 13){
     $manager = new SaleManager($con);
     $date1 = date("Y").'-'.'01'.'-'.'01';
     $date2 = date("Y").'-'.'12'.'-'.'31';
     $res = $manager->sale_yearly($date1,$date2);
     echo json_encode($res);
  }

  if($type == 14){
    $man = new SaleLineManager($con); 
    $res = $man->get($_POST['id']);
    echo json_encode($res);
  }
?>