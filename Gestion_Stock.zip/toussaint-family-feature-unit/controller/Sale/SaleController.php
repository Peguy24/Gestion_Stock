<?php
// Import de la classe
session_start();
  require_once("../../model/Connection/Connection.class.php");
  require_once("../../model/Sale/Sale.class.php");
  require_once("../../model/Sale/SaleManager.class.php");
  require_once("../../model/Sale/SaleLine.class.php");
  require_once("../../model/Sale/SaleLineManager.class.php");
  require_once("../../model/Stock/ProductManager.class.php");
  // require_once("../../model/authorization_login/AuthoManager.php");

   $con = BddConnection::getConnection()->connect();
   global $con;

   $type;

   $type = $_POST['type'];

  //add
  if($type == 1){

    //Add a sale
    //
    $sale = $_POST['sale'];
   
    $user_id = $_SESSION['tf_user_id'];
    $code = date("Y"). date("m") . rand(10000, 99999);
    $discount = $sale['reduction'] == ''?0.0:$sale['reduction'];
    $amount_discount = $discount > 0 ? $sale['total'] : 0.0;
    $sale = new Sale([
  				'user_id'=>$user_id,
  				'sale_code'=>$code,
          'sale_amount'=>$sale['subtotal'],
          'cash'=>$sale['cash'],
          'due'=>$sale['change'],
          'item_count'=>$sale['item_count'],
          'sale_time'=>$sale['sale_time'],
          'discount'=>$discount,
          'amount_discount'=> $amount_discount
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->add($sale);
    //tell manager if is a return
    $returned = false;
   // echo json_encode($response);
  	if(count($response)>0){
     $sale_id = $response['sale_id'];
     
     
      $returned = false;
     if(isset($_POST['sale_id'])){
       //first argument is for the old sale second for new sale, returned sale
      $response = $manager->add_return($_POST['sale_id'], $sale_id);
      $returned = true;
     
     }//else{}
      $line = $_POST['line'];
      $response2;
     for($i=0;$i<count($line);$i++){
     // foreach ($line[$i] as $key => $value) {
        //if($key == 'total'){
          //echo $key.'=>'.$value;
       // }
        $saleLine = new SaleLine($line[$i]);
        $saleLine->setSale_id($sale_id);
        
        // //UnitSale
        // $unitQty = $line[i]["unitQty"] * $line[i]["quantity"];
        // $saleLine->setQuantity($unitQty);
        
        $qte = $line[$i]['qte'];
        //$saleLine->setProduct_id(16);
        //echo ($saleLine->product_id().'='.$saleLine->total().'='.$saleLine->quantity().'='.$saleLine->price());
        $manager2 = new SaleLineManager($con);        
        $res = $manager2->add($saleLine,$qte,$returned);
        $response2 =  $res;
        //echo ($response2);
        if($res != 'success'){
          $response2 = 'failed';
          return;
        }
     // }
     }
     if($response2 == "success"){
        if(isset($_SESSION['user_id_2']) && $_SESSION['user_id_2'] != ""){
          $man = new AuthoManager($con);
          $resp = $man->add($sale_id,$_SESSION['user_id_2']);
          $_SESSION['user_id_2'] = "";
        }
     }

     if($response2 == "success"){
       $sale_code = $code;
       $response2 = $sale_id;
     }
     echo ($response2); 
    }else{
      echo "string";
    }
  }
  

  if($type == 18){
    $manager = new SaleManager($con);
    $manager2 = new SaleLineManager($con);
    $id = $manager->last_sale_id();
    $manager2->delete($id['sale_id']);
    $manager->delete($id['sale_id']);   
    echo 'success';
  }
  /*if($type == 7){
   $line = $_POST['line'];
   echo json_encode($line[0]['nom']);
  }*/

//update
  if($type == 2){
  	$sale = new Sale([
  		'sale_id'=>'1',
  		'user_id'=>'1',
  		'sale_date'=>'2020-08-28',
  		'sale_amount'=>'750'
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->update($sale);
  	echo $response;
  }

  //get
  if($type == 3){
  	$manager = new SaleManager($con);

  	$response = $manager->get(1);
  	var_dump($response);
  }

  if($type == 27){
  	$manager = new SaleManager($con);
    $saleCode = $_POST['saleCode'];
  	$response = $manager->getBySaleCode($saleCode);
  	echo json_encode($response);
  }

  if($type == 28){
  	//$manager = new SaleManager($con);
    $man = new SaleLineManager($con); 
    $id = $_POST['saleId'];
    $res = $man->getFac($id);
    echo json_encode($res);
  }

  if($type == 29){
  	$man = new AuthoManager($con);
     
    $id = $_POST['saleId'];
    $res = $man->getUser($id);
    echo json_encode($res);
  }

//Get all data
  if($type == 4){
  	$manager = new SaleManager($con);
    $return = $_POST['isReturned'] == 1?true : false;
  	$response = $manager->getList($return);

  	echo json_encode($response);
  }
//delete 
  if($type == 5){
    $response = "";
    if($_SESSION['tf_status'] == 'administrateur' || $_SESSION['tf_status'] == 'superviseur'){
      $manager = new SaleManager($con);
      $id = $_POST['id'];
      $response = $manager->delete($id,$_SESSION['tf_user_id']);
    }else{
      $response = "not_privilege";
    }
  
    echo json_encode($response);
  }

  if($type == 6){
   $manager = new SaleManager($con);
   
    $response = $manager->getSales();

    $columnHeader = '';
    $columnHeader = "Sale Code" . "\t" . "User Id" . "\t" . "Sale Amount" . "\t";  
    $setData = '';
    
    //echo json_encode($response);
    //var_dump($response);
    while ($data = $response->fetch(PDO::FETCH_ASSOC))
    {
      $rowData = '';
      foreach ($data as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
      } 
      $setData .= trim($rowData) . "\n";
    }
    $name = date("Y").'/'.date("m").'/'. date("d");
    //echo $name;
    header("Content-type: application/octet-stream");  
    header("Content-Disposition: attachment; filename=Sales_".$name.".xls");  
    header("Pragma: no-cache");  
    header("Expires: 0"); 

    echo ucwords($columnHeader) . "\n" . $setData . "\n";
    copy("C:/Users/Albert/Downloads/Sales_2020_10_13.xls","../../res/backup/target.xls");
    unlink("C:/Users/Albert/Downloads/Sales_2020_10_13.xls");

  }

  if($type == 7){
    copy("C:/Users/Albert/Downloads/Sales_2020_10_13.xls","../../res/backup/target.xls");
    unlink("C:/Users/Albert/Downloads/Sales_2020_10_13.xls");
  }
  
  if($type == 8){
    //$sales = $_POST['sale'];
    //echo json_encode($sales);
    //$columnHeader = '';
    $columnHeader = array("Sale Code","Realise Par","Qte Articles","Total","Reduction","Montant Avec Reduction","Montant","Remise","Date");  
    /*$setData = '';
    
    foreach ($sales as $val) {  
        $rowData = '';
       foreach ($val as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
       } 
       $setData .= trim($rowData) . "\n";
   } 
   $name = date("Y").'_'.date("m").'_'. date("d");
    //echo $name;
   $_SESSION['col'] = $columnHeader;
   $_SESSION['data'] = $setData;
   $_SESSION['name'] = 'sales_'.$name;
   echo 'success';*/

   //Export Sale
   $manager = new SaleManager($con);
   $sales = $manager->getListExport();
   $sales2 = $manager->getList();

    //$header = array("CODE PRODUIT", "NOM PRODUIT" ,"MODELE", "CATEGORIE","QUANTITE");
    $name = 'sales_'.date("Y").'_'.date("m").'_'. date("d");
    $file = fopen("../../../../../../".$name.".csv","w");
    fputcsv($file, $columnHeader);

    foreach ($sales as $line) {
      fputcsv($file, $line);
    }
    fclose($file);

    //Export sale line
    $manager = new SaleLineManager($con);
    $sale_lines = $manager->getListExport();

    $columnHeader2 = array("Sale Code","Nom produit","Prix Unitaire","Quantité","Sous-total");

     $name2 = 'sales_line_'.date("Y").'_'.date("m").'_'. date("d");
     $file2 = fopen("../../../../../../".$name2.".csv","w"); 
     fputcsv($file2, $columnHeader2);  
          foreach ($sale_lines as $line2) {
            fputcsv($file2, $line2);
          }
      fclose($file2); 
 

    echo "success";
    //echo json_encode($columnHeader);
  }
  
  if($type == 9){
    $manager = new SaleManager($con);
    $date =  $_POST['date'];
    $res = $manager->solde_amount_daily($date);
    echo($res['sum_daily']);
  }

 /* if($type == 18){
    $manager = new SaleManager($con);
    $date =  $_POST['date'];
    $res = $manager->solde_amount_discount_daily($date);
    echo($res['sum_discount_daily']);
  }

  if($type == 19){
    $manager = new SaleManager($con);
   
    $res = $manager->solde_amount();
    echo($res['sum']);
  }

  if($type == 20){
    $manager = new SaleManager($con);
   
    $res = $manager->solde_amount_discount();
    echo($res['sum_discount']);
  }*/


  
  if($type == 14){
    $man = new SaleLineManager($con); 
    $res = $man->get($_POST['id']);
    echo json_encode($res);
  }

  if($type == 15){
     $columnHeader = array("Sale Code","Realise Par","Qte Articles","Total","Reduction","Montant Avec Reduction","Montant","Remise","Date"); 

     $date = $_POST['date'];
     $manager = new SaleManager($con);
   $sales = $manager->sale_daily2($date);
   $sales2 = $manager->getList();

    //$header = array("CODE PRODUIT", "NOM PRODUIT" ,"MODELE", "CATEGORIE","QUANTITE");
    $name = 'sales_daily_'.date("Y").'_'.date("m").'_'. date("d");
    $file = fopen("../../../../../../".$name.".csv","w");
    fputcsv($file, $columnHeader);

    foreach ($sales as $line) {
      fputcsv($file, $line);
    }
    fclose($file);

    //Export sale line
    $manager = new SaleLineManager($con);
    $sale_lines = $manager->getListDaily($date);

    $columnHeader2 = array("Sale Code","Nom produit","Prix Unitaire","Quantité","Sous-total");

     $name2 = 'sales_daily_line_'.date("Y").'_'.date("m").'_'. date("d");
     $file2 = fopen("../../../../../../".$name2.".csv","w"); 
     fputcsv($file2, $columnHeader2);  
          foreach ($sale_lines as $line2) {
            fputcsv($file2, $line2);
          }
      fclose($file2); 
 

    echo "success";
   /* $sales = $_POST['sale'];
    //echo json_encode($sales);
    $columnHeader = '';
    $columnHeader = "Sale Code" . "\t" . "Realise Par" . "\t" . "Qte Articles" . "\t" . "Total" ."\t" . "Montant" ."\t" . "Remise" . "\t" . "Date" . "\t";  
    $setData = '';
    
    foreach ($sales as $val) {  
        $rowData = '';
       foreach ($val as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
       } 
       $setData .= trim($rowData) . "\n";
   } 
   $name = date("Y").'_'.date("m").'_'. date("d");
    //echo $name;
   $_SESSION['col'] = $columnHeader;
   $_SESSION['data'] = $setData;
   $_SESSION['name'] = 'sales_daily_'.$name;
   echo 'success';*/

  }

  if($type == 16){
    $prods = $_POST['prod'];
    //echo json_encode($sales);
    $columnHeader = '';
    $columnHeader = "Code Produit" . "\t" . "Nom Produit" . "\t" . "Modele" . "\t" . "Categorie" ."\t" . "Quantite" ."\t";  
    $setData = '';
    
    foreach ($prods as $val) {  
        $rowData = '';
       foreach ($val as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
       } 
       $setData .= trim($rowData) . "\n";
   } 
   $name = date("Y").'_'.date("m").'_'. date("d");
    //echo $name;
   $_SESSION['col'] = $columnHeader;
   $_SESSION['data'] = $setData;
   $_SESSION['name'] = 'prod_rupture_'.$name;
   echo 'success';
  }

  if($type == 17){
    $prods = $_POST['prod'];
    //echo json_encode($sales);
    /*$columnHeader = '';
    $columnHeader = "Code Produit" . "\t" . "Nom Produit" . "\t" . "Modele" . "\t" . "Categorie" ."\t" . "Quantite" ."\t";  
    $setData = '';
    
    foreach ($prods as $val) {  
        $rowData = '';
       foreach ($val as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;
        //echo $value; 
       } 
       $setData .= trim($rowData) . "\n";
   } 
   $name = date("Y").'_'.date("m").'_'. date("d");
    //echo $name;
   $_SESSION['col'] = $columnHeader;
   $_SESSION['data'] = $setData;
   $_SESSION['name'] = 'prod_rupture_soon_'.$name;
   echo $_SESSION['data'];
   //echo 'success';*/
   
  }
?>