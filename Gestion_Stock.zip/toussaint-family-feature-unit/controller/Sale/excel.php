<?php
	session_start();
	$columnHeader = $_SESSION['col'] ;
    $setData = $_SESSION['data'] ;
    $name = $_SESSION['name'];
	header("Content-type: application/octet-stream");  
    header("Content-Disposition: attachment; filename=".$name.".xls");  
    header("Pragma: no-cache");  
    header("Expires: 0"); 

    echo ucwords($columnHeader) . "\n" . $setData . "\n";
   // header('Location:sendMailAttach.php');
?>