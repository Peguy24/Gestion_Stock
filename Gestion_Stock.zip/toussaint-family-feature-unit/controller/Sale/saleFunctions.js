function tr_factory_sale(data, index, isForSale){
	let tr = '<tr id = "'+data.sale_id+'">';
	let i = index+1; 
	tr += '<td>'+data.sale_code+'</td>';
	tr += '<td>'+data.first_name+'</td>';
	tr += '<td>'+data.item_count+'</td>';
	tr += '<td>'+data.sale_amount+'</td>';
	tr += '<td>'+data.cash+'</td>';
    tr += '<td>'+data.due+'</td>';
    tr += '<td>'+data.sale_date+'</td>';
	
	tr += '<td><a href="saleDetail.php?id='+data.sale_id+'" ';	
	if(Number(data.item_count > 0))
		tr += '><i class="fas fa-eye text-center"></i></a>&nbsp&nbsp&nbsp<a href="return.php?id='+data.sale_id+'" ><i class="fas fa-undo-alt text-center"></i>&nbsp</a>';
	else
	tr += '><i class="fas fa-eye text-center"></i></a>';

	var status = $("#statusM").text();

	if(status == "administrateur" || status == "superviseur"){
		tr += '&nbsp<a href="#DeleteModal" data-toggle="modal" class="delete text-danger" data-id="'+data.sale_id+'"><i class="fas fa-trash text-center"></i></a>';
	}
	tr += "</td>";
	return tr;
}

var allUnits = [];
//get all units
 function getUnits(){
	var unit = [];
	$.ajax({
		data: {type:4},
		url : "../controller/Unit/UnitController.php",
		method: 'post',
		success: function(dataResult)
		{
			//console.log(dataResult)
			var dataResult = $.parseJSON(dataResult);
		
			unit = dataResult
			dataResult.forEach(function(data,index){
				// let tr = tr_factory_prod(data,index,false);
				 $('#units_table').append('<tr data-unit_id="'+data.unit_id+
				 '" data-unit_name="'+data.unit_name+
				'"  data-unit_price="'+data.unit_price+
				'" data-unit_quantity="'+data.unit_quantity+'"  data-p_unit_id="'+data.product_id+'"></tr>');
				// console.log(data);
			})
		},error: function(data){
			console.log(data)
		}
		});
		return unit
}

//Get all units
getUnits()

//get all units for one product
function getUnitSale(idProd){
	var units = [];
$("#units_table tr").each(function(){	
	 var id_prod = $(this).attr('data-p_unit_id');
	 console.log(id_prod + " - " + idProd)
	 if(idProd == id_prod){
		 units.push({
				unitId:$(this).attr('data-unit_id'),
				unitName:$(this).attr('data-unit_name'),
				unitQty : $(this).attr('data-unit_quantity'),
				unitPrice: $(this).attr('data-unit_price')
			})
	 }
})
	return units
}
