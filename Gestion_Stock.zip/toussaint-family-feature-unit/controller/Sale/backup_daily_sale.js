(function($){
	backup();
})(jQuery)

function sale_factory(sale_code,item_count,sale_amount,sale_date){
		return {
			sale_code:sale_code,
			item_count:item_count,
			sale_amount:sale_amount,
			sale_date:sale_date
		};
	}
function send_sales(sales){
	$.ajax({
		data: {type:'8',sale:sales},
		url : "http://localhost/stock_management/app/controller/sale/SaleController.php",
		method: 'post',
		success: function(response)
		{
			console.log(response);
			if(response == 'success'){
						//$('#addEmployeeModal').modal('hide');
						//window.alert('Operation réussie !');
                        //location.reload();
                        window.location.href = 'http://localhost/stock_management/app/controller/sale/excel.php';
                        setTimeout(function(){
                        window.location.href = 'http://localhost/stock_management/app/controller/sale/sendMailAttach.php';
                        },5000);
					}
					else {
					   window.alert(response);
					}
		}
	});
}

function daily_sale(){
	$.ajax({
		data: {type:'11'},
		url : "http://localhost/stock_management/app/controller/sale/SaleController.php",
		method: 'post',
		success: function(response)
		{
			var sales = [];
			//console.log(response);
			response = $.parseJSON(response);

			if(response.length > 0){
				response.forEach(function(data,index){
					sales.push(sale_factory(data.sale_code,data.item_count,data.sale_amount,data.sale_date));
				});
			}
			send_sales(sales);
		}
	});
}

function backup(){
		
		// Set the date we're counting down to

var date =  new Date();
var hour = "10:58:00";

var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

var month = months[date.getMonth()];
var day = date.getDate();
var year = date.getFullYear();
var format = month +' '+ day + ', '+ year + ' '+ hour;
var d = new Date(format);

var countDownDate = d.getTime();

//var countDownDate = new Date("January 5, 2021 15:00:00").getTime();
/*var date = new Date();
var format = date.getFullYear() + '-'+ date.getMonth()+'-'+date.getDay()+'T'+ hour+'Z';
var countDownDate = format.getTime();*/

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  /*console.log(days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ");*/
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
  	daily_sale();
  }
}, 1000);
}
