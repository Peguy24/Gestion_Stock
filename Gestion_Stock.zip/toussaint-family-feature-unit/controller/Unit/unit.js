(function($){
	insert_unit();
	update_unit();
	delete_unit();
})(jQuery)

function insert_unit(){
	$('#add-unit').on('click',function(e) {

		$("#product_id_unit").val($("#prod_id").val());
		$("#product_qty_unit").val($("#quantitym").val());
		
		var data = $("#unit-form").serialize();

		console.log(data);
		$.ajax({
			data:data,
			type: "post",
			url: "../controller/Unit/UnitController.php",
			beforeSend:function(){
				//setLoader()
			},
			success: function(dataResult){
				removeLoader()
				console.log("response : "+dataResult);
				 dataResult = $.parseJSON(dataResult);
				if(dataResult != "failed" && dataResult != "exists" && dataResult != "empty" && dataResult !="<0" && dataResult !=">prod_qty"){
					toastr.success("UNITE AJOUTEE AVEC SUCCES")
					setTimeout(() => {
						location.reload();
					}, 2000);
					
				}else if(dataResult== "empty"){
					toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
				}else if(dataResult =="<0"){
					toastr.error("LE PRIX ET LA QUANTITE DOIVENT ETRE DES NOMBRES POSITIF NON NULS !")
				}else if(dataResult ==">prod_qty"){
					toastr.error("LA QUANTITE DE L'UNITE DOIT ETRE INFERIEURE A LA QUANTITE DU PRODUIT !")
				}else if(dataResult == "exists"){
					toastr.warning("NOM PRODUIT DEJA UTILISE !")					
				}else{
					toastr.error("ERREUR DU SYSTEME !!")
				}
					
			},
			error:function(dataResult){
				console.log(dataResult);
			}
		});
		// }
	});
	}

	/* function that put data in the edit_modal*/
function update_unit(){
	$(document).on('click','.edit-unit',function(e) {
		//reset data from form modal
		resetFormModal("update-unit-form");
		

		var id = $(this).attr("data-unit_id");
		// var product_code = $(this).attr("data-product_code");
		var name = $(this).attr("data-unit_name");
		// var category = $(this).attr("data-category");
		// var model = $(this).attr("data-model");
		var price = $(this).attr("data-unit_price");
		//var comment = $(this).attr("data-comment");
		var quantity = $(this).attr("data-unit_quantity");
		// var price_percent = $(this).attr("data-price_percent");
		// var sale_price = $(this).attr("data-sale_price");
		var creation_date = $(this).attr("data-unit_created_at");
		var updated_at = $(this).attr("data-unit_updated_at");

		$('#unit_id').val(id);
		$('#unit-namem').val(name);
		// $('#product_namep').val(name);
		// $('#product_categoryp').val(category);
		// $('#product_modelp').val(model);
		//$('#commentm').val(comment);
		$('#unit-quantitym').val(quantity);
		//$('#quantityNew').val(0);
		$('#unit-pricem').val(price);
		// $('#sale_price_percentp').val(price_percent);
		// $('#sale_pricep').val(sale_price);
		$('#unit-datem').val(creation_date);
		$('#unit-updated_atm').val(updated_at);
	});
	
	$('#edit-unit').on('click',function(e){
		e.preventDefault();
			var data = $("#update-unit-form").serialize();
			console.log(data);
	
			$.ajax({
				data:data,
				type:"post",
				url:"../controller/Unit/UnitController.php",
				beforeSend:function(){
					//setLoader()
				},
				success: function(dataResult){
					removeLoader()
					console.log(dataResult);
					dataResult = $.parseJSON(dataResult);
					if(dataResult != "failed" && dataResult != "exists" && dataResult != "empty" && dataResult !="<0" && dataResult !=">prod_qty"){
						toastr.success("UNITE MODIFIE AVEC SUCCES")
						setTimeout(() => {
							location.reload();
						}, 2000);
						
					}else if(dataResult== "empty"){
						toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
					}else if(dataResult =="<0"){
						toastr.error("LE PRIX ET LA QUANTITE DOIVENT ETRE DES NOMBRES POSITIF NON NULS !")
					}else if(dataResult ==">prod_qty"){
						toastr.error("LA QUANTITE DE L'UNITE DOIT ETRE INFERIEURE A LA QUANTITE DU PRODUIT !")
					}else if(dataResult == "exists"){
						toastr.warning("NOM UNITE DEJA UTILISE !")					
					}else{
						toastr.error("ERREUR DU SYSTEME !!")
					}
						
				}
			});
		// }
		});
}

function delete_unit(){
	//window.alert("OK")
	var id = "";
	$(document).on("click", ".delete-unit", function() {
		//resetFormModal("sup-unit-form");
		 id=$(this).attr("data-unit_id");
		 console.log(id)
	});
	
$('#delete-unit').on('click',function(e){
	e.preventDefault();
	console.log(id)
		$.ajax({
		data: {unit_id:id,type:3},
		url : "../controller/Unit/UnitController.php",
		method: 'post',
		beforeSend:function(){
			setLoader()
		},
		success: function(dataResult)
		{
			removeLoader()
			var dataResult = $.parseJSON(dataResult);
			console.log(dataResult)
			if(dataResult == 'success'){							
				toastr.success("ACTION REALISEE AVEC SUCCES")
					$("#"+id).remove();
					$("#DeleteModal").modal("hide")					

			}else{
				toastr.error("ERREUR DU SYSTEME !!")
			}
		},error: function(data){
			console.log(data)
		}
		});
	
  //}
});
}