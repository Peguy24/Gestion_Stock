<?php
session_start();
require_once("../../model/Connection/Connection.class.php");
require_once("../../model/Unit/Unit.class.php");
require_once("../../model/Unit/UnitManager.class.php");

  $con = BddConnection::getConnection()->connect();
   global $con;
   $type = $_POST['type'];
 //echo($type);

//  function checkInput(){

//  }
 //   add
   if($type == 1){
  
    $product_id = htmlspecialchars($_POST['product_id']);
  	$unit_price = (float)htmlspecialchars($_POST['unit_price']);
    $unit_quantity = (int)htmlspecialchars($_POST['unit_quantity']);
    $product_quantity = (int)htmlspecialchars($_POST['product_qty']);
    $unit_name = htmlspecialchars($_POST['unit_name']);
   // $response = "ok";
   // $response = $product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name." - ".$product_quantity;
  //  $response = $product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name;
  // //	$created_at = htmlspecialchars($_POST['date']);
  //   //$response[] = "";
  //   //$response = $price;
  if($unit_quantity <= 0 || $unit_price <= 0)
       {
        //  echo($product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name);
        //$response="ok";
        $response ='<0';
      }else if($unit_quantity>$product_quantity){
        $response = ">prod_qty";
      }else if($unit_name != ""){
        //$response = "ok";
  $manager = new UnitManager($con);
          if($manager->exists($unit_name)){
            $response =  'exists';
          }else{
  //     //       //$response = "ok";
            try{
              $unit = new Unit( 
                [
                    'product_id' => $product_id,
                    'unit_name' => $unit_name, 
                    'unit_price' => $unit_price,
                    'unit_quantity' => $unit_quantity
                ]
              );
              //$response = $unit->unit_name();
            //$response="ok";
              $responseManager = $manager->add($unit);
            $response = $responseManager;
            }catch(Exception $e){
              $response = $e->getMessage();
            }
          
            
          }
    }else{
      $response = "empty";
    }
     echo json_encode($response);
   }

    //   update
    if($type == 2){
  
      $unit_id = (int)htmlspecialchars($_POST['unit_id']);
      $unit_price = (float)htmlspecialchars($_POST['unit_price']);
      $unit_quantity = (int)htmlspecialchars($_POST['unit_quantity']);
      //$product_quantity = (int)htmlspecialchars($_POST['product_qty']);
      $unit_name = htmlspecialchars($_POST['unit_name']);
     // $response = $unit_id;
     // $response = "ok";
     // $response = $product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name." - ".$product_quantity;
    //  $response = $product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name;
    // //	$created_at = htmlspecialchars($_POST['date']);
    //   //$response[] = "";
    //   //$response = $price;
    if($unit_quantity <= 0 || $unit_price <= 0)
         {
          //  echo($product_id ." - " . $unit_price." - ". $unit_quantity." - ".$unit_name);
          //$response="ok";
          $response ='<0';
        }else if($unit_name != ""){
          //$response = "ok";
    $manager = new UnitManager($con);
         // $response = $manager->exists_update($unit_name, $unit_id);
         // $response = $unit_name ." - ". $unit_id;
            if($manager->exists_update($unit_name, $unit_id)){
              $response =  'exists';
            }else{
    //     //       //$response = "ok";
              try{
                $unit = new Unit( 
                  [
                      'unit_id' => $unit_id,
                      'unit_name' => $unit_name, 
                      'unit_price' => $unit_price,
                      'unit_quantity' => $unit_quantity
                  ]
                );
                //$response = $unit->unit_name();
              //$response="ok";
                $responseManager = $manager->update($unit);
              $response = $responseManager;
              }catch(Exception $e){
                $response = $e->getMessage();
              }
            
              
            }
      }else{
        $response = "empty";
      }
       echo json_encode($response);
     }
  
     if($type == 3){
					
			$manager = new UnitManager($con);
				$response = $manager->delete($_POST['unit_id']);
				echo json_encode($response);
        //echo json_encode($_POST['unit_id']);
			
		}

    if($type == 4){					
			$manager = new UnitManager($con);
				$response = $manager->getUnit();
				//echo json_encode($response);
      echo json_encode($response);
		}    
?>