<?php
	session_start();
    require_once("../../model/Connection/Connection.class.php");
    require_once("../../model/Sale/Sale.class.php");
    require_once("../../model/Sale/SaleManager.class.php");
    require_once("../../model/Sale/SaleLine.class.php");
    require_once("../../model/Sale/SaleLineManager.class.php");
    require_once("../../model/Stock/ProductManager.class.php");

  $con = BddConnection::getConnection()->connect();
   global $con;

   $type;

   $type = $_POST['type'];

   //Sale daily
   if($type == 1){
    $manager = new SaleManager($con);
    $date = $_POST['date'];
    $return = $_POST['isReturned'] == 1?true : false;
    $res = $manager->sale_daily($date,$return);
    echo json_encode($res);
    //echo $date;
 }
 
 //Sale monthly
 if($type == 2){
  $manager = new SaleManager($con);
  $date1 = date("Y").'-'.date("m").'-'.'01';
  $date2 = date("Y").'-'.date("m").'-'.'31';
  $return = $_POST['isReturned'] == 1?true : false;
  $res = $manager->sale_monthly($date1,$date2,$return);
  echo json_encode($res);
}

//Sale yearly
if($type == 3){
  $manager = new SaleManager($con);
  $date1 = date("Y").'-'.'01'.'-'.'01';
  $date2 = date("Y").'-'.'12'.'-'.'31';
  $return = $_POST['isReturned'] == 1?true : false;
  $res = $manager->sale_yearly($date1,$date2,$return);
  echo json_encode($res);
}
//Sale amount daily
   if($type == 4){
    $manager = new SaleManager($con);
    $date =  $_POST['date'];
    $return = $_POST['isReturned'] == 1?true : false;
    $res = $manager->solde_amount_daily($date, $return);
    echo($res['sum_daily']);
  }

  //Sale amount weekly
  if($type == 12){
    $manager = new SaleManager($con);
    $date = $_POST['date'];
    $return = $_POST['isReturned'] == 1?true : false;
    $res = $manager->sale_weekly($date,$return);
    echo json_encode($res);
  }
  //   if($type == 5){
  //   $manager = new SaleManager($con);
  //   $date =  $_POST['date'];
  //   $res = $manager->solde_amount_discount_daily($date);
  //   echo($res['sum_discount_daily']);
  // }

  // if($type == 6){
  //   $manager = new SaleManager($con);   
  //   $res = $manager->solde_amount();
  //   echo($res['sum']);
  // }

  // if($type == 7){
  //   $manager = new SaleManager($con);
   
  //   $res = $manager->solde_amount_discount();
  //   echo($res['sum_discount']);
  // }

  if($type == 8){
    $manager = new ProductManager($con);
    $response = $manager->out_of_stock_soon();
    echo json_encode($response);
    //var_dump($response);
  }
  
  if($type == 9){
    $manager = new ProductManager($con);
    $response = $manager->out_of_stock();
    echo json_encode($response);
    //var_dump($response);
  }

  if($type == 10){
    $monthNumber = (int)$_POST['month'];
    $date1 = "";
    if($monthNumber < 10)
      $date1 = date("Y").'-'.'0'.$_POST['month'].'-'.'01';
    else
      $date1 = date("Y").'-'.$_POST['month'].'-'.'01';
      
    $manager = new SaleManager($con);
    $res = $manager->sale_amount_monthly($date1,false);
    echo json_encode($res);
  }
  
  if($type == 11){
    $manager = new SaleManager($con);
    $date = $_POST['date'];
    $return = $_POST['isReturned'] == 1?true : false;
    $res = $manager->sale_count($date, $return);
    echo $res['sum'];
   // print_r(localtime());
 }
?>