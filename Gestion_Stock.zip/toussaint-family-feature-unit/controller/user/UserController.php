<?php 
session_start();
require_once("../../model/Connection/Connection.class.php");
require_once("../../model/User/User.class.php");
require_once("../../model/User/UserManager.class.php");

	$con = BddConnection::getConnection()->connect();
    global $con;
   	$type ;
	if(isset($_GET['type'])){
		$type = $_GET['type'];
	}else{
		$type = $_POST['type'];
	}

	//check if user already exist when you add a new user
	function check_user($username){
		$userMan = new UserManager();
		return $userMan->exist($username);
	}

	/*check if user already exist when you update a user except the username 
	of user who isconnected*/ 
	function check_user_Update($username, $id){
		$userMan = new UserManager();
		return $userMan->existUpdate($username,$id);
	}

	//LOGIN
	if($type == 1){
		$user = $_POST['user_name'];
		$pass = $_POST['password'];
		if($user == '' || $pass == ''){
			$response = "empty";
		}else{
			$manager = new UserManager();
			$response = $manager->login($user,$pass);
			if($response != "failed" && count($response) > 0 ){
				$_SESSION['tf_status'] = $response[0]['status'];
				$_SESSION['tf_user_id'] = $response[0]['user_id'];
				$_SESSION['tf_name'] = $response[0]['user_name'];
			}else if($response == "failed"){
				$response = "failed";
			}else{
				$response = "0";
			}
		}
		echo json_encode($response);
		
	}

		//LOGOUT
		if($type == 7){
			// session_unset();
			// session_destroy();
			unset($_SESSION['tf_status']);
			unset($_SESSION['tf_user_id']);
			unset($_SESSION['tf_name']);
			if(!isset($_SESSION['tf_name'])){
				//echo json_encode('failed');
				header('Location:../../index.php');
			}
		}
		//Add a user
		if($type == 2){
			try{
					
				$email = htmlspecialchars($_POST['email']) == '' ? 'inconnu' : htmlspecialchars($_POST['email']);
				$number = htmlspecialchars($_POST['phone']) == '' ? 'inconnu' : htmlspecialchars($_POST['phone']);
				$first_name = htmlspecialchars($_POST['first-name']);
				$user_name = htmlspecialchars($_POST['user-name']);
				$last_name = htmlspecialchars($_POST['last-name']);
				$status = htmlspecialchars($_POST['status']); 
				$password = htmlspecialchars($_POST['password']);
				$account_state = isset($_POST['account-state']) ? htmlspecialchars($_POST['account-state']) : "";
				$response = "";
				if($first_name != "" && $last_name != "" && $user_name != "" && $password != "" && $status != "" && $account_state != ""){
				//$response = $first_name;
						if(!check_user($user_name)){
						$user = new User([
							'created_by'=>$_SESSION['tf_user_id'],
							'first_name'=>$first_name,
							'last_name'=>$last_name,
							'phone_number'=>$number,
							'email'=>$email,
							'status'=>$status,
							'user_name'=>$user_name,
							'password'=>$password,
							'account_state'=>$account_state
						]);
						//echo json_encode($user->account_state());
						$UserManager = new UserManager();
						$response = $UserManager->add($user);
					}else{
						$response = "existe";
					}
				}else{
					$response = "empty";
				}
				echo json_encode($response);	
			}catch(Exception $e){
				echo json_encode("error");
			}
		}

			//List User
		if($type == 3){
			$UserManager = new UserManager();
			$response = $UserManager->allUser($_SESSION['tf_user_id']);
			echo json_encode($response);
		}
		//update User
		if($type == 4){
			$email = htmlspecialchars($_POST['email']) == '' ? 'inconnu' : htmlspecialchars($_POST['email']);
				$number = htmlspecialchars($_POST['phone']) == '' ? 'inconnu' : htmlspecialchars($_POST['phone']);
				$first_name = htmlspecialchars($_POST['first-name']);
				$user_name = htmlspecialchars($_POST['user-name']);
				$last_name = htmlspecialchars($_POST['last-name']);
				$status = htmlspecialchars($_POST['status']); 
				$password = htmlspecialchars($_POST['password']);
				$account_state = isset($_POST['account-state']) ? htmlspecialchars($_POST['account-state']) : "";
				$response = "";
				if($first_name != "" && $last_name != "" && $user_name != "" && $password != "" && $status != "" && $account_state != ""){

			    	if(!check_user_Update(htmlspecialchars($_POST['user-name']),htmlspecialchars($_POST['user-id']))){
					$user = new User([
					'user_id'=>htmlspecialchars($_POST['user-id']),
					'updated_by'=>$_SESSION['tf_user_id'],
					'first_name'=>htmlspecialchars($_POST['first-name']),
					'last_name'=>htmlspecialchars($_POST['last-name']),
					'phone_number'=>$number,
					'email'=>$email,
					'status'=>htmlspecialchars($_POST['status']),
					'user_name'=>htmlspecialchars($_POST['user-name']),
					'password'=>htmlspecialchars($_POST['password']),
					'account_state'=>htmlspecialchars($_POST['account-state'])
					]);
					$UserManager = new UserManager();
					$responseManager = $UserManager->updateUser($user);
					if($response != "failed"){
						if($_POST['user-id'] == $_SESSION['tf_user_id'])
							$response = "same_account";
						else
							$response = $responseManager;
					}else{
						$response = $responseManager;
					}
				}else{
					$response = "existe";
				}
			}else{
				$response = "empty";
			}
			echo json_encode($response);
		}

		//delete user
		if($type == 5){
			//echo json_encode($_POST['user_name']);
			if($_SESSION['tf_name'] == $_POST['user_name']){
				echo json_encode('same_user');
			}else if($_SESSION['tf_status'] != "administrateur"){
				echo json_encode("no-permission");
			}else{
				$UserManager = new UserManager();
				$response = $UserManager->deleteUser($_POST['id']);
				echo json_encode($response);
			}
			
		}

		//GET USER
		if($type == 6){
			if(isset($_SESSION['tf_user_id'])){
				$userMan = new UserManager();
				$user = $userMan->getUser($_SESSION['tf_user_id']);
				echo json_encode($user);
			}
		}

		//update Profile User
		if($type == 8){

			$email = htmlspecialchars($_POST['email']) == '' ? 'inconnu' : htmlspecialchars($_POST['email']);
			$number = htmlspecialchars($_POST['phone']) == '' ? 'inconnu' : htmlspecialchars($_POST['phone']);
			$first_name = htmlspecialchars($_POST['first-name']);
				$user_name = htmlspecialchars($_POST['user-name']);
				$last_name = htmlspecialchars($_POST['last-name']);
				
				$password = htmlspecialchars($_POST['password']);
				
				$response = "";
				if($first_name != "" && $last_name != "" && $user_name != "" && $password != ""){
							
					if(!check_user_Update(htmlspecialchars($_POST['user-name']),htmlspecialchars($_POST['id-profile']))){
						$user = new User([
							'user_id'=>htmlspecialchars($_POST['id-profile']),
							'first_name'=>htmlspecialchars($_POST['first-name']),
							'last_name'=>htmlspecialchars($_POST['last-name']),
							'phone_number'=>$number,
							'email'=>$email,
							'user_name'=>htmlspecialchars($_POST['user-name']),
							'password'=>htmlspecialchars($_POST['password'])
						]);
						$UserManager = new UserManager();
						$responseManager = $UserManager->updateProfile($user);			
						$response = $responseManager;			
					}else{
						$response = "existe";
					}
				}else{
					$response = "empty";
				}
				echo json_encode($response);
		}


?>