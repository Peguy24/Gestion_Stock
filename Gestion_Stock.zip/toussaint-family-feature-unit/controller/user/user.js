(function($){
	// $(document).load(function(){
	var url = "../controller/user/UserController.php";
	//$.getScript("../controller/user/userFunctions.js");
	login(url);
	//logout();
	add();
	allUser();
	update_user();
	//update_profil();
	delete_user();
	//get_user_profil();
	// });
})(jQuery)


function login(url){
	$(document).on('click','#login', function(e){
		//window.alert("ok");
		setLoader()
		e.preventDefault();
		var data = $('#login_form').serialize();
		//console.log(data);
		ajaxPost(url,data,userLogin);
			
		// if($('#username').val() == '' || $('#password').val() == ''){
		// 	console.log('Veuillez remplir tous les champs !');
		// }else{

		// $.ajax({
		// 	data:data,
		// 	url:url,
		// 	method:'post',
		// 	success: userLogin,
		// 	error:function(response){
		// 		console.log(response)
		// 	}
		// });
	//}
	});
}

function add(){
	
	var status = '';
	var account_state = '';
	$('.account-state').change(function(){
		account_state = $(this).val();
	})
	$('#status').change(function(){
			status = $(this).val();
		});
		var first_name = document.getElementById("first-name");
		var last_name = document.getElementById("last-name");
		var userName = document.getElementById("user-name");
		//var status = document.getElementById("status");
		var password = document.getElementById("password");
		// var state_account = document.getElementById("");
    
	$('#add-user').on('click', function(e){
		e.preventDefault();
		
		var data = $('#user-form').serialize();
		console.log(data)
		//Swal.fire({text:"Hello world!",position:'top-end'});
		$.ajax({
			data:data,
			url:"../controller/user/UserController.php",
			method:'post',
			beforeSend:function(){
				//disable btn-add

				//
				setLoader()
			},
			success: function(dataResult){
				//console.log(dataResult)
				removeLoader()
				dataResult = $.parseJSON(dataResult);
				
				if(dataResult != "failed" && dataResult != "existe" && dataResult != "empty" ){
					toastr.success("COMPTE UTILISATEUR AJOUTE AVEC SUCCES")
					setTimeout(() => {
						location.reload();
					}, 2000);
					
				}else if(dataResult== "empty"){
					toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
				}else if(dataResult == "existe"){
					toastr.warning("LE PSEUDO EST DEJA UTILISE !")					
				}else{
					toastr.error("ERREUR DU SYSTEME !!")
				}
			},
			error:function(response){
				console.log(response)
			}
		});
	  //}
	});
}

function allUser(){
	$.ajax({
			data:{type:3},
			url:"../controller/user/UserController.php",
			method:'post',
			success: function(dataResult){
				dataResult = $.parseJSON(dataResult);
				//console.log(dataResult);
				if(dataResult != "failed"){
						//console.log(dataResult.length)
						if(dataResult.length > 0){
							dataResult.forEach(function(data1,index){
								let tr = tr_user_factory(data1,index);
								$('#t_body').append(tr);
							});
							//Call datatable config
							dataTable("#myTable");
						}
					}
					else {
					   window.alert('Erreur!');
					}
			},error:function(response){
				console.log(response)
			}
		});
}

function update_user(){
	$(document).on('click','.edit',function(e) {
		//window.alert("OK");
		resetFormModal("update-form");
		var id = $(this).attr("data-user_id");
		var first_name = $(this).attr("data-first_name");
		var last_name = $(this).attr("data-last_name");
		var phone_number = $(this).attr("data-phone_number");
		var email = $(this).attr("data-email");
		var username = $(this).attr("data-username");
		var statusm = $(this).attr("data-status");
		var created_at = $(this).attr("data-created_at");

		var password = $(this).attr("data-password");
		
		var account_state = $(this).attr("data-account_state");
		console.log(password+"-"+account_state+"-"+password +"-"+ username+"-"+id +"-"+first_name+"-"+last_name+"-"+ phone_number+"-"+ email +"- status"+statusm);
		$('#user-id').val(id);
		$('#first-namem').val(first_name);
		$('#last-namem').val(last_name);
		$('#emailm').val(email);
		//$('#user-id').val(account_id);
		$('#user-namem').val(username);
		$('#phonem').val(phone_number);
		$('#passwordm').val(password)
		//console.log($('#user-namem'))
		//$('#statusm').val(statusm);
		$('#statusm option:selected').removeAttr('selected');
		$('.account-state').removeAttr('checked');
		$('#statusm option#'+statusm).attr('selected',true);
		//$('#statusm ').prop('selected',false);

		//$('#'+statusm).attr('selected',true);
		
		$('#'+account_state).attr('checked',true);
	});

	$('#update-user').on('click',function(e){
			var data = $("#update-form").serialize();
			//console.log(data);
			$.ajax({
				data:data,
				type:"post",
				url:"../controller/user/UserController.php",
				beforeSend:function(){
					setLoader()
				},
				success: function(dataResult){
					removeLoader()
					//console.log(dataResult);
					var dataResult = $.parseJSON(dataResult);
					console.log(dataResult);
					
					if(dataResult != 'failed'){
						 if(dataResult == 'same_account'){
							window.alert("Vous devez vous connectez a nouveau !");
							//location.href = "../controller/user/UserController.php?type=6";
						 }else if(dataResult == "existe"){
							toastr.warning("LE PSEUDO EST DEJA UTILISE !");
						 }else if(dataResult=="empty"){
							toastr.error("VEUILLER REMPLIR TOUS LES CHAMPS !")
						 }
						else{
							$('#ModifyModal').modal('hide');
							toastr.success("COMPTE UTILISATEUR MODIFIE AVEC SUCCES")
							location.reload();
						}
					}else{
						toastr.error(dataResult);
					}
				}
			});
		});
}

function delete_user(){
	var user_id=0, username=0;
	$(document).on("click", ".delete", function() {
			 user_id=$(this).attr("data-id");
			//td = $(this);
			//var account_id = $(this).attr("data-account_id");
			//$('#user-id_d').val(id);
			 username = $(this).attr("data-username");
			
		});
		//console.log(user_id+"-"+username)
	$('#delete-user').on('click',function(e){
		//console.log(username);
		$.ajax({
		data: {id:user_id,user_name:username,type:5},
		url : "../controller/user/UserController.php",
		method: 'post',
		beforeSend:function(){
			setLoader()
		},
		success: function(dataResult)
		{
			removeLoader()
			var dataResult = $.parseJSON(dataResult);
			console.log(dataResult);
			
			if(dataResult == 'success'){
						$('#DeleteModal').modal('hide');
						toastr.success("COMPTE UTILISATEUR SUPPRIME AVEC SUCCES")
						$("#"+user_id).remove();
					}else if(dataResult == "same_user"){
						window.alert('Vous ne pouvez pas supprimmer votre propre compte !');
					}else if(dataResult == "no-permission"){
						toastr.error("VOUS N'AVEZ PAS LA PERMISSION POUR REASLISER CETTE ACTION !");
					}
			else{
				toastr.error(dataResult);
			}
		}
		});
	});
}

