(function($){
	update_profil();
	get_user_profil();
})(jQuery)

function login(){
	$(document).on('click','#login', function(e){
		//window.alert("ok");
		e.preventDefault();
		var data = $('#login_form').serialize();
		//console.log(data);
		// if($('#username').val() == '' || $('#password').val() == ''){
		// 	console.log('Veuillez remplir tous les champs !');
		// }else{
		$.ajax({
			data:data,
			url:"../controller/user/UserController.php",
			method:'post',
			success: function(dataResult){
				
				dataResult = $.parseJSON(dataResult);
				//console.log(dataResult[0].user_name)
				 if(dataResult == "empty"){
					window.alert("Remplir tous les champs !");
				 }else if(dataResult.length > 0){
						var user = dataResult[0];
						if(user.account_state == 'active'){
							console.log(user)
							window.alert('Bonjour '+user.user_name);
							location.href = "dashboard.php";
						}else{
							window.alert('COMPTE INACTIVE !');
						}
						//alert('Data added successfully !');
                        //location.reload();
					}else {
					   window.alert(dataResult);
					}
			},
			error:function(response){
				console.log(response)
			}
		});
	//}
	});
}

function get_user_profil(){
	//$('#profile-link, #profile-item').on('click',function(e){
       // window.alert("OK");
			$.ajax({
			data:{type:6},
			url:"../controller/user/UserController.php",
			method:'post',
			success: function(dataResult){
				dataResult = $.parseJSON(dataResult);
				if(dataResult != "failed"){				
				//console.log(dataResult);
                    $("#id-profile").val(dataResult.user_id);
					$("#fullNameP").text(dataResult.first_name + ' ' + dataResult.last_name);
					$("#statusP").text(dataResult.status);
					$("#emailP").text(dataResult.email);
					$("#email-P").val(dataResult.email);
					$("#phoneP").text(dataResult.phone_number);
					$("#phone-P").val(dataResult.phone_number);
					//data for profil user in the menu
					$("#fullNameM").text(dataResult.first_name + ' ' + dataResult.last_name);
					$("#statusM").text(dataResult.status);
					// $("#emailM").text(dataResult.email);
					//$("#username").text(dataResult.username);
					$("#first-nameP").val(dataResult.first_name);
					$("#last-nameP").val(dataResult.last_name);
					$("#user-nameP").val(dataResult.user_name);					
					$("#passwordP").val(dataResult.password);
					//console.log(dataResult);
					
				}
				else{
                    window.alert("Erreur Systeme concernant le profil utilisateur !");
					location.href = "../controller/user/UserController.php?type=7";
                }
					
				}			    
		});
	//});
}

function update_profil(){

	$(document).on('click','#update-profile',function(e){
        
			var data = $("#profil-form").serialize();
			//console.log(data);
		// 	if($('#first_namem').val()  == "" || $('#last_namem').val() == "" || $('#usernamem').val() == "" || $('#password').val() == ""){
		// 	window.alert("Veuillez Remplir tout les champs !!");
		// }
		// else{
			//setLoader();
			$.ajax({
				data:data,
				type:"post",
				url:"../controller/user/UserController.php",
				success: function(dataResult){
					console.log(dataResult);
					var dataResult = $.parseJSON(dataResult);
					if(dataResult != 'failed'){
						// $('#editEmployeeModal').modal('hide');
						// alert('Data updated successfully !');
                        //location.reload();
                        if(dataResult == "existe"){
                            window.alert("Ce Pseudo existe deja");
                        }else if(dataResult == "empty"){
							window.alert("Remplir tous les champs !");
						}else                        
                        location.href = "../controller/user/UserController.php?type=7";
					}else{
						window.alert("Erreur Systeme");
					}
				}
			});
		//}
		});

}