function tr_user_factory(data, index){
	let tr = '<tr id = "'+data.user_id+'">';
	let i = index+1;
	tr += '<td>'+i+'</td>';
	tr += '<td>'+data.first_name+'</td>';
	tr += '<td>'+data.last_name+'</td>';
	tr += '<td>'+data.user_name+'</td>';
	tr += '<td>'+data.status+'</td>';

	tr += '<td><a href="#ModifyModal" class="edit" data-toggle="modal" ';	
	tr += 'data-user_id="'+data.user_id+'"';
	tr += 'data-first_name="'+data.first_name+'"';
	tr += 'data-last_name="'+data.last_name+'"';
	tr += 'data-phone_number="'+data.phone_number+'"';
	tr += 'data-password="'+data.password+'"';
	tr += 'data-email="'+data.email+'"';
	tr += 'data-username="'+data.user_name+'"';
	tr += 'data-status="'+data.status+'"';
	tr += 'data-account_state="'+data.account_state+'"';
	tr += 'data-created_at="'+data.created_at+'" ';
    tr += '><i class="update fa fa-edit" data-toggle="tooltip"';
	tr += 'title="Edit"></i></a>';
	tr += '&nbsp&nbsp&nbsp&nbsp<a href="#DeleteModal" class="delete" data-toggle="modal" data-username="'+data.user_name+'" data-id="'+data.user_id+'" data-toggle="modal"><i class="fa fa-trash text-danger"  data-toggle="tooltip"';
	tr += 'title="Delete"></i></a></td>';

	return tr;
}

//Callback function login
function userLogin(dataResult){
	console.log(dataResult)
				dataResult = $.parseJSON(dataResult);
				//console.log(dataResult[0].user_name)
				removeLoader()
				 if(dataResult == "empty"){
					toastr.error("VEUILLEZ REMPLIR TOUS LES CHAMPS !");
					//window.alert("VEUILLEZ REMPLIR TOUS LES CHAMPS !");
				 }else if(dataResult == "0"){
					toastr.error("PSEUDO OU MOT DE PASSE INCORRECT!");
				 }else if(dataResult == "failed"){
					toastr.error("ERREUR DU SYSTEME !!")
				 }else if(dataResult.length > 0){
						var user = dataResult[0];
						if(user.account_state == 'active'){
							var link = user.status == "caissier" ? "sale.php" : "dashboard.php";
							location.href = link;
						}else{
							toastr.info('VOTRE COMPTE EST INACTIVE !');
						}
						//alert('Data added successfully !');
                        //location.reload();
					}else {
					   window.alert(dataResult);
					}
}