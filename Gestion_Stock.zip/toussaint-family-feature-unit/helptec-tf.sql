-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 31, 2021 at 05:13 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `helptec-tf`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(65,2) DEFAULT NULL,
  `quantity` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `user_id`, `product_name`, `price`, `quantity`, `created_at`, `updated_at`, `is_deleted`, `comment`) VALUES
(1, 8, 'screenlo', '89.00', 0, '2021-08-07 03:39:00', '2021-08-17 21:30:28', 1, 'ok'),
(2, 8, 'screen dell', '87.00', 67, '2021-08-07 03:39:00', NULL, 1, 'Bon bagay'),
(3, 8, 'screen dell2', '87.00', 0, '2021-08-07 03:39:00', NULL, 1, 'Bon bagay'),
(4, 8, 'screen dell3', '87.00', 67, '2021-08-07 03:39:00', NULL, 1, 'Bon bagay'),
(5, 8, 'screen dell4', '87.00', 70, '2021-08-07 03:39:00', '2021-08-20 20:20:55', 1, 'Bon bagay'),
(6, 8, 'huille moteur mobile gallon', '87.00', 67, '2021-08-07 03:39:00', '2021-08-22 16:17:58', 1, 'Bon bagay'),
(7, 8, 'ok', '78.79', 90, '2021-08-21 16:54:00', NULL, 1, ''),
(8, 3, 'laptop', '500.00', 123, '2021-08-03 20:33:00', NULL, 1, ''),
(9, 3, 'huile toyota', '500.00', 23, '2021-08-08 16:31:00', NULL, 1, ''),
(10, 8, 'huile toyota', '79.00', 1, '2021-08-14 16:36:00', '2021-09-10 10:39:49', 1, ''),
(11, 8, 'lait', '500.00', 76, '2021-08-11 14:27:00', '2021-12-22 10:13:37', 0, ''),
(12, 19, 'ok', '87.00', 0, '2021-08-25 23:42:00', NULL, 1, ''),
(13, 19, 'huille moteur mobile gallon', '87.00', 2, '2021-08-25 23:43:00', '2021-12-30 22:44:53', 0, ''),
(14, 19, 'Asdfghjkl', '87.00', 3, '2021-08-25 23:49:00', '2021-08-31 03:05:49', 1, 'nom'),
(15, 19, 'test delete hkjAlbert1', '500.00', 404, '2021-09-05 16:58:00', '2021-12-21 10:16:38', 1, ''),
(16, 19, 'test delete2', '12365.00', 51, '2021-09-05 16:59:00', NULL, 1, ''),
(17, 19, 'albert-bn-bagay', NULL, 44, '2021-12-22 00:00:00', '2021-12-30 21:33:07', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `return_product`
--

CREATE TABLE `return_product` (
  `id_return_product` int(11) NOT NULL,
  `sale_returned_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `sale_id` bigint(20) NOT NULL,
  `sale_code` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_id_auth` bigint(20) NOT NULL DEFAULT 0,
  `sale_date` date NOT NULL,
  `sale_time` time NOT NULL,
  `sale_amount` decimal(65,2) NOT NULL,
  `amount_discount` decimal(65,2) NOT NULL DEFAULT 0.00,
  `cash` decimal(65,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(65,2) NOT NULL DEFAULT 0.00,
  `due` decimal(65,2) NOT NULL DEFAULT 0.00,
  `item_count` bigint(20) NOT NULL DEFAULT 0,
  `return_sale` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`sale_id`, `sale_code`, `user_id`, `user_id_auth`, `sale_date`, `sale_time`, `sale_amount`, `amount_discount`, `cash`, `discount`, `due`, `item_count`, `return_sale`, `is_deleted`, `updated_at`) VALUES
(98, 20211128372, 19, 0, '2021-11-23', '14:33:52', '210.00', '0.00', '300.00', '0.00', '90.00', 3, 0, 0, NULL),
(99, 20211262275, 19, 0, '2021-12-30', '22:57:55', '1000.00', '0.00', '1000.00', '0.00', '0.00', 5, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales_line`
--

CREATE TABLE `sales_line` (
  `sale_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `price` decimal(65,5) NOT NULL,
  `sale_price` int(11) NOT NULL DEFAULT 0,
  `discount_rate` decimal(65,5) NOT NULL DEFAULT 0.00000,
  `total` decimal(65,5) NOT NULL,
  `unit_name` varchar(255) NOT NULL,
  `unit_quantity` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_line`
--

INSERT INTO `sales_line` (`sale_id`, `product_id`, `quantity`, `price`, `sale_price`, `discount_rate`, `total`, `unit_name`, `unit_quantity`) VALUES
(98, 14, 1, '45.00000', 0, '0.00000', '45.00000', '1xlait', 1),
(98, 15, 1, '120.00000', 0, '0.00000', '120.00000', '3xlait', 3),
(98, 15, 1, '45.00000', 0, '0.00000', '45.00000', '1xlait', 1),
(99, 11, 3, '250.00000', 0, '0.00000', '750.00000', '1Xcaisse lait', 24),
(99, 11, 2, '125.00000', 0, '0.00000', '250.00000', '1/2Xcaisse lait', 12);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `unit_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `unit_name` varchar(255) NOT NULL,
  `unit_price` decimal(60,0) NOT NULL,
  `unit_quantity` bigint(20) NOT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit_id`, `product_id`, `unit_name`, `unit_price`, `unit_quantity`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 11, 'ja', '201', 201, 1, '2021-12-21 16:32:47', '2021-12-22 16:49:16'),
(2, 11, 'j', '1', 1, 1, '2021-12-21 21:25:51', NULL),
(3, 10, '1 caisse lait', '1000', 24, 0, '2021-12-22 10:08:11', NULL),
(4, 11, '1/2 caisse lait', '500', 12, 1, '2021-12-22 10:34:37', NULL),
(5, 10, '3xgallon', '150', 3, 0, '2021-12-22 19:55:50', '2021-12-22 19:56:22'),
(6, 17, 'j', '20', 20, 0, '2021-12-22 20:45:06', NULL),
(7, 13, '3xhuile moteur', '250', 3, 0, '2021-12-30 22:07:25', '2021-12-30 22:45:26'),
(8, 11, '1Xcaisse lait', '250', 24, 0, '2021-12-30 22:40:01', NULL),
(9, 11, '1/2Xcaisse lait', '125', 12, 0, '2021-12-30 22:41:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL DEFAULT 'inconnu',
  `email` varchar(255) NOT NULL DEFAULT 'inconnu',
  `status` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `account_state` varchar(255) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `phone_number`, `email`, `status`, `user_name`, `password`, `account_state`, `is_deleted`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(22, 'Albert-mary5', 'ABbnn', '325', 'inconnu', 'caissier', 'vr71', 'vr7', 'active', 1, '2021-08-31 02:56:54', NULL, 19, NULL),
(21, 'albert', 'dorce', '32545', 'albertbus@gmail.com', 'caissier', 'albert2', 'albert', 'active', 0, '2021-08-30 03:45:11', '2021-08-31 03:02:10', 19, 19),
(20, 'Albert-mary5', 'Dorce', '325879', 'albertbus@gmail.com', 'administrateur', 'albert', 'albert', 'active', 0, '2021-08-24 15:07:27', '2021-08-24 15:08:17', 19, 19),
(19, 'valcourt', 'roobens', '325', 'inconnu', 'administrateur', 'vr7', 'vr7', 'active', 0, '2021-08-24 15:00:51', NULL, 18, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `return_product`
--
ALTER TABLE `return_product`
  ADD PRIMARY KEY (`id_return_product`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`sale_id`),
  ADD UNIQUE KEY `sale_code` (`sale_code`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `return_product`
--
ALTER TABLE `return_product`
  MODIFY `id_return_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `sale_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unit_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
