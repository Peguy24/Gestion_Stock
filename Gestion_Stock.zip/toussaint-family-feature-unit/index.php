<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: ./views/login.php');
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
    </head>

    <body>
        <?php
             header('Location: views/login.php');
             
        ?>
    </body>
</html>