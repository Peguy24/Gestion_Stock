<?php
class SaleManager
{
	//Update: extend connection
	private $_db;

	public  function last_sale_id(){
		$q = $this->_db->query('SELECT sale_id FROM sale ORDER BY sale_id DESC LIMIT 0,1');
		$data = $q->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

    // method to register a sale
	public function add(Sale $sale)
	{
		$returned = 0;
		
		if($sale->item_count() < 0){
			$returned = 1;
		}
		$q = $this->_db->prepare('INSERT INTO sale(user_id,sale_code,sale_date,sale_time,sale_amount,cash,due,discount,amount_discount,item_count,return_sale) VALUES(:user_id,:sale_code,now(),:sale_time,:sale_amount,:cash,:due,:discount,:amount_discount,:item_count,:return_sale)');

		$q->execute(array(':user_id'=>$sale->user_id(),':sale_code'=>$sale->sale_code(),':sale_time'=>$sale->sale_time(),
						  ':sale_amount'=>$sale->sale_amount(),':cash'=>$sale->cash(),
						  ':due'=>$sale->due(),':discount'=>$sale->discount(),':amount_discount'=>$sale->amount_discount(),':item_count'=>$sale->item_count(),':return_sale'=>$returned));
		if($q){
			$q1 = $this->_db->query('SELECT sale_id FROM sale ORDER BY sale_id DESC LIMIT 0,1');
			$data = $q1->fetch(PDO::FETCH_ASSOC);
			$sale_id = $data;
			return $sale_id;
		}else{
			return 'failed';
		}
	}
    
    public function add_return($sale_id, $sale_return_id){
    	$q = $this->_db->prepare('INSERT INTO return_product(sale_id,sale_returned_id) VALUES(:sale_id,:sale_returned_id)');

		$q->execute(array(':sale_id'=>$sale_id,':sale_returned_id'=>$sale_return_id));
		return "success";
    }
    //method to list a sale 
	public function get($sale_id)
	{
		$sale_id = (int) $sale_id;
		$q = $this->_db->query('SELECT * FROM sale s, user u WHERE u.user_id = s.user_id AND s.is_deleted = 0 AND s.sale_id = '.$sale_id);

		$data = $q->fetch(PDO::FETCH_ASSOC);

		//echo json_encode($data);
		return $data;
	}

	public function getBySaleCode($sale_id)
	{
		$sale = [];
		//$sale_code = (int) $sale_code;
		/*$q = $this->_db->prepare('SELECT s.sale_id, s.sale_code, concat(u.first_name," ", u.last_name), s.item_count, s.sale_amount,s.discount, s.amount_discount,s.cash,s.due, concat(s.sale_date," ",s.sale_time) as sale_dat FROM sale s, user u WHERE u.user_id = s.user_id  AND s.sale_code = :code');
		$q->execute(array(':code'=>$sale_code));
		$data = $q->fetch(PDO::FETCH_ASSOC);

		//echo json_encode($data);
		return $data;*/
		$sale_id = (int) $sale_id;
		$q = $this->_db->query('SELECT * FROM sale s, user u WHERE u.user_id = s.user_id AND  s.sale_id = '.$sale_id);

		//$data = $q->fetch(PDO::FETCH_ASSOC);
		while($data = $q->fetch(PDO::FETCH_ASSOC) ) 
		{
		   $sale[] = $data;
		}
		//echo json_encode($data);
		return $sale;
	}

	public function getList($returned)
	{
		$sale = [];
		$req = "";
		if($returned)
			$req = "SELECT * FROM sale s, user u where u.user_id = s.user_id AND s.return_sale = 1 AND s.is_deleted = 0 ORDER BY s.sale_id DESC";
		else
			$req = "SELECT * FROM sale s, user u where u.user_id = s.user_id AND s.return_sale = 0  AND s.is_deleted = 0 ORDER BY s.sale_id DESC";

		$q = $this->_db->query($req);

		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}

	public function getList2($date)
	{
		$sale = [];

		$q = $this->_db->prepare('SELECT s.sale_code, u.first_name, s.item_count, s.sale_amount,s.discount, s.amount_discount,s.cash,s.due, concat(s.sale_date," ",s.sale_time) as sale_dat FROM sale s, user u where u.user_id = s.user_id  AND s.sale_date = :dat ORDER BY s.sale_id DESC');
		$q->execute(array(':dat'=> $date));
		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}

	public function getListExport()
	{
		$sale = [];

		$q = $this->_db->query('SELECT s.sale_code, u.first_name, s.item_count, s.sale_amount,s.discount, s.amount_discount,s.cash,s.due, concat(s.sale_date," ",s.sale_time) as sale_dat FROM sale s, user u where u.user_id = s.user_id   ORDER BY s.sale_id DESC');
		
		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}

    public function getSales()
	{
		$sale = [];

		$q = $this->_db->query('SELECT sale_id, sale_code, user_id, sale_amount FROM sale ORDER BY sale_id DESC');

		/*while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}*/

		return $q;
	}

    //method to update a sale
	public function update(Sale $sale)
	{
		$q = $this->_db->prepare('UPDATE sale SET  user_id = :user_id, sale_date = :sale_date, sale_amount = :sale_amount WHERE sale_id = :sale_id');

		    $q->execute(array(':user_id'=>$sale->user_id(),':sale_date'=>$sale->sale_date(),':sale_amount'=>$sale->sale_amount(), 
				':sale_id'=>$sale->sale_id()));
		    echo 'success';
	}
    
    //method to delete a sale
	public function delete($sale_id, $id_user)
	{
		$sale_id = (int) $sale_id;
		try{
			$req = $this->_db->prepare("UPDATE product INNER JOIN sales_line ON product.product_id = sales_line.product_id SET product.quantity = (product.quantity + sales_line.quantity) WHERE sales_line.sale_id =:sale_id;");
			$req->execute(array(":sale_id"=>$sale_id));
			try{
				$q = $this->_db->prepare('UPDATE sale SET is_deleted = 1, user_id_auth = :id_user, updated_at = now() WHERE sale_id = :id');
				$q->execute(array(":id"=>$sale_id,":id_user" => $id_user));
				return "success";
			}catch(Exception $e){
				return "failed : ".$e->getMessage();
			}
		}catch(Exception $e){
			return "failed".$e->getMessage();
		}
	}


	public function solde_amount_daily($date_sale, $returned){
		if($returned){
			$request = 'SELECT SUM(sale_amount) AS "sum_daily" FROM sale WHERE sale_date=:sale_date AND return_sale = 1 AND is_deleted = 0';
		}else{
			$request = 'SELECT SUM(sale_amount) AS "sum_daily" FROM sale WHERE sale_date=:sale_date AND return_sale = 0 AND is_deleted = 0';
		}
		$req = $this->_db->prepare($request);
		$req->execute(array(':sale_date'=>$date_sale));
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function sale_amount_monthly($date_sale,$returned){
		if($returned)
		$request = 'SELECT SUM(sale_amount) AS "sum_monthly", sale_date FROM sale WHERE MONTH(sale_date)=MONTH(:sale_date) AND return_sale = 1 AND is_deleted = 0 ';
		else
		$request = 'SELECT SUM(sale_amount) AS "sum_monthly", sale_date FROM sale WHERE MONTH(sale_date)=MONTH(:sale_date) AND return_sale = 0 AND is_deleted = 0 ';
		
		$req = $this->_db->prepare($request);
		$req->execute(array(':sale_date'=>$date_sale));
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function solde_amount_discount_daily($date_sale){
		$req = $this->_db->prepare('SELECT SUM(sale_amount - discount) AS "sum_discount_daily" FROM sale WHERE sale_date=:sale_date AND is_deleted = 0');
		$req->execute(array(':sale_date'=>$date_sale));
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function solde_amount(){
		$req = $this->_db->query('SELECT SUM(sale_amount) AS "sum" FROM sale WHERE is_deleted = 0');
		//$req->execute();
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function solde_amount_discount(){
		//$req = $this->_db->query('SELECT SUM(sale_amount - amount_discount) AS "sum_discount" FROM sale ');
		$req = $this->_db->query('SELECT SUM(sale_amount - discount) AS "sum_discount" FROM sale ');
		//$req->execute(array(':sale_date'=>$date_sale));
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}
	
	public function sale_count($date_sale, $returned){
		if($returned){
			$request = 'SELECT count(*) AS "sum" FROM sale WHERE sale_date=:sale_date AND return_sale = 1 AND is_deleted = 0';
		}else{
			$request = 'SELECT count(*) AS "sum" FROM sale WHERE sale_date=:sale_date AND return_sale = 0 AND is_deleted = 0';
		}
		$req = $this->_db->prepare($request);
		$req->execute(array(':sale_date'=>$date_sale));
		$data = $req->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function sale_daily($date_sale,$returned){
			$sale = [];
			$req ="";
			if($returned)
				$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND s.return_sale = 1 AND s.is_deleted = 0 AND sale_date=:date_sale ORDER BY s.sale_id DESC";
			else
			$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND s.return_sale = 0 AND s.is_deleted = 0 AND sale_date=:date_sale ORDER BY s.sale_id DESC";

			$q = $this->_db->prepare($req);
			$q->execute(array(':date_sale' => $date_sale));
			while ($data = $q->fetch(PDO::FETCH_ASSOC))
			{
				$sale[] = $data;
			}
			return $sale;
	}

	public function sale_weekly($date_sale,$returned){
		$sale = [];
		$req ="";
		if($returned)
			$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND  s.return_sale = 1 AND s.is_deleted = 0 AND sale_date=:date_sale ORDER BY s.sale_id DESC";
		else
		$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND s.return_sale = 0 AND s.is_deleted = 0 AND sale_date=:date_sale ORDER BY s.sale_id DESC";

		$q = $this->_db->prepare($req);
		$q->execute(array(':date_sale' => $date_sale));
		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}
		return $sale;
}

	public function sale_daily2($date_sale){
			$sale = [];

			$q = $this->_db->prepare('SELECT s.sale_code, u.first_name, s.item_count, s.sale_amount,s.discount, s.amount_discount,s.cash,s.due, concat(s.sale_date," ",s.sale_time) as sale_dat FROM sale s, user u where u.user_id = s.user_id AND sale_date=:date_sale ORDER BY s.sale_id DESC');
			$q->execute(array(':date_sale' => $date_sale));
			while ($data = $q->fetch(PDO::FETCH_ASSOC))
			{
				$sale[] = $data;
			}

			return $sale;
	}

	public function sale_monthly($date_sale1, $date_sale2,$returned){
		$sale = [];
		$req = "";
			if($returned)
				$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND (s.sale_date BETWEEN :sale_date1 AND :sale_date2) AND s.return_sale = 1 AND s.is_deleted = 0 ORDER BY s.sale_id DESC";
			else
				$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND (s.sale_date BETWEEN :sale_date1 AND :sale_date2) AND s.return_sale = 0 AND s.is_deleted = 0 ORDER BY s.sale_id DESC";
			
				$q = $this->_db->prepare($req);
			$q->execute(array(':sale_date1' => $date_sale1,
							':sale_date2' => $date_sale2));
			while ($data = $q->fetch(PDO::FETCH_ASSOC))
			{
				$sale[] = $data;
			}

			return $sale;
	}

	public function sale_yearly($date_sale1, $date_sale2,$returned){
		$sale = [];
		$req ="";
		if($returned)
			$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND (s.sale_date BETWEEN :sale_date1 AND :sale_date2) AND s.return_sale = 1 AND s.is_deleted = 0 ORDER BY s.sale_id DESC";
		else
			$req = "SELECT * FROM sale s, user u WHERE s.user_id = u.user_id AND (s.sale_date BETWEEN :sale_date1 AND :sale_date2) AND s.return_sale = 0 AND s.is_deleted = 0 ORDER BY s.sale_id DESC";
			$q = $this->_db->prepare($req);
			$q->execute(array(':sale_date1' => $date_sale1,
							':sale_date2' => $date_sale2));
			while ($data = $q->fetch(PDO::FETCH_ASSOC))
			{
				$sale[] = $data;
			}

			return $sale;
	}

	public function setDb(PDO $db)
	{
		$this->_db = $db;
	}

	public function __construct($db)
	{
		$this->setDb($db);
	}
}
?>