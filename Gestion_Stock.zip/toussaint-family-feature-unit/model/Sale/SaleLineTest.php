<?php

  require_once("../Connection/ConnectionObject.php");
  require_once("Sale.php");
  require_once("SaleManager.php");
  require_once("SaleLine.php");
  require_once("SaleLineManager.php");

  $con = BddConnection::getConnection()->connect();
   global $con;
   
   $type = 1;

   //add
  if($type == 1){

  	$sale = new Sale([
  				'user_id'=>'1',
  				'sale_code'=>2032
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->add($sale);

  	$sale_id = $response['sale_id'];
  	//echo $sale_id;
  	$saleLine = new SaleLine([
  					'sale_id'=>$sale_id,
  					'product_id'=>16,
  					'quantity'=>13,
  					'price'=>234
  	            ]);
  	$manager2 = new SaleLineManager($con);
  	
  	$res = $manager2->add($saleLine);
  	echo $res;
  }
?>