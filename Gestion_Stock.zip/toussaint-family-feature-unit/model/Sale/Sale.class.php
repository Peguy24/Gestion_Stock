<?php
class Sale
{
    
    //ATTRIBUTS
	private $_sale_id;
	private $_sale_code;
	private $_user_id;
	private $_sale_date;
	private $_sale_amount;
	private $_cash;
	private $_due;
	private $_discount;
	private $_amount_discount;
	private $_item_count;
	private $_sale_time;
    
    //GETTERS
    public function amount_discount(){
    	return $this->_amount_discount;
    }
    public function discount(){
    	return $this->_discount;
    }
    public function sale_time(){
    	return $this->_sale_time;
    }
	public function sale_id(){
		return $this->_sale_id;
	}

	public function user_id(){
		return $this->_user_id;
	}

	public function sale_date(){
		return $this->_sale_date;
	}

	public function sale_amount(){
		return $this->_sale_amount;
	}
    public function cash(){
    	return $this->_cash;
    }
    public function due(){
    	return $this->_due;
    }
    public function item_count(){
    	return $this->_item_count;
    }
    public function sale_code(){
    	return $this->_sale_code;
    }
    //SETTERS
    public function setAmount_discount($amount_dis){
    	$this->_amount_discount = $amount_dis;
    }
    public function setDiscount($discount){
    	$this->_discount = $discount;
    }
    public function setSale_time($sale_time){
    	$this->_sale_time = $sale_time;
    }
    public function setSale_id($sale_id){
		 $this->_sale_id = $sale_id;
	}

	public function setUser_id($user_id){
		 $this->_user_id = $user_id;
	}

	public function setSale_date($sale_date){
		 $this->_sale_date = $sale_date;
	}

	public function setSale_amount($sale_amount){
		 $this->_sale_amount = $sale_amount;
	}
	public function setCash($cash){
		$this->_cash = $cash;
	}
	public function setDue($due){
		$this->_due = $due;
	}
	public function setItem_count($item_count){
		$this->_item_count = $item_count;
	}
	public function setSale_code($sale_code){
		$this->_sale_code = $sale_code;
	}
	public function hydrate(array $data){
		foreach($data as $key => $value){
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method)){
				$this->$method($value);
			}
		}
	}
    //CONSTRUCTOR
	public function __construct(array $data){
		$this->hydrate($data);
	}
}
?>
