<?php
class SaleLine
{
	private $_sale_id;
	private $_product_id;
	private $_quantity;
	private $_price;
	private $_sale_price;
	private $_discount_rate;
	private $_total;
	private $_unit_id;
	private $_unit_quantity;
	private $_unit_name;

	public function sale_id(){return $this->_sale_id;}
	public function product_id(){return $this->_product_id;}
	public function quantity(){return $this->_quantity;}
	public function price(){return $this->_price;}
	public function sale_price(){return $this->_sale_price;}
	public function discount_rate(){return $this->_discount_rate;}
	public function total(){return $this->_total;}
	public function unit_id(){return $this->_unit_id;}
	public function unit_quantity(){return $this->_unit_quantity;}
	public function unit_name(){return $this->_unit_name;}

	public function setSale_id($sale_id){ $this->_sale_id = $sale_id;}
	public function setProduct_id($product_id){$this->_product_id = $product_id;}
	public function setQuantity($quantity){$this->_quantity = $quantity;}
	public function setPrice($price){$this->_price = $price;}
	public function setSale_price($sale_price){$this->_sale_price = $sale_price;}
	public function setDiscount_rate($rate){$this->_discount_rate = $rate;}
	public function setTotal($total){$this->_total = $total;}
	public function setUnit_id($unitId){$this->_unit_id=$unitId;}
	public function	setUnit_quantity($unitQty){$this->_unit_quantity = $unitQty;}
	public function	setUnit_name($unitName){$this->_unit_name = $unitName;}

	public function hydrate(array $data){
		foreach($data as $key => $value){
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method)){
				$this->$method($value);
			}
		}
	}
    //CONSTRUCTOR
	public function __construct(array $data){
		$this->hydrate($data);
	}
}
?>