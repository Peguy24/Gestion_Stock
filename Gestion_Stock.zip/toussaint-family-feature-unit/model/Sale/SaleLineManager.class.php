<?php
class SaleLineManager
{
	//Update: extend connection
	private $_db;

	

    // method to register a sale
	public function add(SaleLine $saleLine, $qte, $returned)
	{
		$q = $this->_db->prepare('INSERT INTO sales_line(sale_id,product_id,quantity,price,total,unit_name,unit_quantity) 
		VALUES(:sale_id,:product_id,:quantity,:price,:total,:unit_name,:unit_quantity)');

		$q->execute(array(
			':sale_id'=>$saleLine->sale_id(),
			':product_id'=>$saleLine->product_id(),
			':quantity'=>$saleLine->quantity(),
			':price'=>$saleLine->price(),
			':total'=>$saleLine->total(),
			':unit_name'=>$saleLine->unit_name(),
			':unit_quantity'=>$saleLine->unit_quantity()
		));
		if($q){	
			$qt = 0;	
			$prodQuantity = $saleLine->quantity() * $saleLine->unit_quantity();
			if($returned){
				$req = $this->_db->query('SELECT quantity FROM product WHERE product_id = '.$saleLine->product_id());
				$data = $req->fetch(PDO::FETCH_ASSOC);
				$quantiteStock = $data['quantity'];
				$qt = $quantiteStock - ($prodQuantity);
				//return $qt;
			}else{
				$qt = $qte - ($prodQuantity);
			}
			//return $qt;
			//return 'ID '.$saleLine->product_id().'result '.$qt.' qtestock '.$qte.' ligne Quantite '.$saleLine->quantity();
			$q2 = $this->_db->prepare('UPDATE product SET quantity = :qt WHERE product_id = :id');
			$q2->execute(array(':qt'=> $qt,'id'=>$saleLine->product_id()));
			if ($q2) {
					# code...
				return 'success';
				}else{
					return 'failed';
				}	
			
		}else{
			return 'failed';
		}
	}
    
    //method to list a sale 
	public function get($sale_id)
	{
		$sale = [];

		$sale_id = (int) $sale_id;
		/*SELECT s.sale_id, p1.product_id, u.user_id FROM sale s, user u, sales_line s1, product p1, product_base p2 where s.user_id = u.user_id AND s1.sale_id = s.sale_id AND (p1.product_base_id = p2.product_base_id AND p1.product_id = s1.product_id)*/
		$q = $this->_db->query('SELECT p.product_name, p.product_id, p.quantity as quantity_stock, s.price, s.quantity as quantity, s.total FROM sales_line s, product p WHERE  p.product_id = s.product_id AND sale_id = '.$sale_id);

		/*while($data = $q->fetch(PDO::FETCH_ASSOC)){
			$sale[] =$data;
		}*/

		//echo json_encode($data);
		return $q;
	}

	public function getFac($sale_id)
	{
		$sale = [];

		$sale_id = (int) $sale_id;
		/*SELECT s.sale_id, p1.product_id, u.user_id FROM sale s, user u, sales_line s1, product p1, product_base p2 where s.user_id = u.user_id AND s1.sale_id = s.sale_id AND (p1.product_base_id = p2.product_base_id AND p1.product_id = s1.product_id)*/
		$q = $this->_db->query('SELECT p.product_name, p.product_id,  p.quantity, s.price, s.quantity, s.total FROM sales_line s,  product p WHERE p.product_id = s.product_id AND sale_id = '.$sale_id);

		while($data = $q->fetch(PDO::FETCH_ASSOC)){
			$sale[] =$data;
		}

		//echo json_encode($sale);
		return $sale;
	}

	public function get_qty($sale_id)
	{
		$sale = [];

		$sale_id = (int) $sale_id;
		/*SELECT s.sale_id, p1.product_id, u.user_id FROM sale s, user u, sales_line s1, product p1, product_base p2 where s.user_id = u.user_id AND s1.sale_id = s.sale_id AND (p1.product_base_id = p2.product_base_id AND p1.product_id = s1.product_id)*/
		$q = $this->_db->prepare('SELECT s1.product_id, sum(quantity) as qty FROM sales_line s1, return_product r1 WHERE s1.sale_id = r1.sale_returned_id AND r1.sale_id = :sale_id group by (s1.product_id);');

		$q->execute(array(':sale_id'=>$sale_id));

		while($data = $q->fetch(PDO::FETCH_ASSOC)){
			$sale[] =$data;
		}

		//echo json_encode($data);
		return $sale;
	}

	/*public function getList()
	{
		$sale = [];

		$q = $this->_db->query('SELECT * FROM sale s, account a where a.user_id = s.user_id ORDER BY sale_id DESC');

		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}*/

	/*public function getList()
	{
		$sale = [];

		$q = $this->_db->query('SELECT s1.sale_code,p1.product_name, s.price, s.quantity, s.total FROM sales_line s, product_base p1, product p2, sale s1 WHERE p1.product_base_id = p2.product_base_id AND  p2.product_id = s.product_id AND s.sale_id = s1.sale_id');
		

		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}*/
    
    public function getList($date)
	{
		$sale = [];

		$q = $this->_db->prepare('SELECT s1.sale_code,p1.product_name, s.price, s.quantity, s.total FROM sales_line s, product_base p1, product p2, sale s1 WHERE p1.product_base_id = p2.product_base_id AND  p2.product_id = s.product_id AND s.sale_id = s1.sale_id AND s1.sale_date = :dat');
		$q->execute(array(':dat'=>$date));

		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}

	public function getListExport()
	{
		$sale = [];

		$q = $this->_db->query('SELECT s1.sale_code,p1.product_name, s.price, s.quantity, s.total FROM sales_line s, product_base p1, product p2, sale s1 WHERE p1.product_base_id = p2.product_base_id AND  p2.product_id = s.product_id AND s.sale_id = s1.sale_id ');
		

		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}

    public function getInv($date){
    	$inv = [];

		$q = $this->_db->prepare('SELECT p1.product_name, SUM(s.quantity) as qty, SUM(s.total) as amount FROM sales_line s, product p, product_base p1, sale s1 WHERE s.product_id = p.product_id AND p.product_base_id = p1.product_base_id AND s.sale_id = s1.sale_id AND s1.sale_date = :dat group by s.product_id');
		$q->execute(array(':dat'=>$date));
		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$inv[] = $data;
		}

		return $inv;
    } 
    public function getListDaily($date)
	{
		$sale = [];

		$q = $this->_db->prepare('SELECT s1.sale_code,p1.product_name, s.price, s.quantity, s.total FROM sales_line s, product_base p1, product p2, sale s1 WHERE p1.product_base_id = p2.product_base_id AND  p2.product_id = s.product_id AND s.sale_id = s1.sale_id AND sale_date=:date_sale');
		$q->execute(array(':date_sale' => $date));
		while ($data = $q->fetch(PDO::FETCH_ASSOC))
		{
			$sale[] = $data;
		}

		return $sale;
	}
    //method to update a sale
	public function update(Sale $sale)
	{
		$q = $this->_db->prepare('UPDATE sale SET  user_id = :user_id, sale_date = :sale_date, sale_amount = :sale_amount WHERE sale_id = :sale_id');

		    $q->execute(array(':user_id'=>$sale->user_id(),':sale_date'=>$sale->sale_date(),':sale_amount'=>$sale->sale_amount(), 
				':sale_id'=>$sale->sale_id()));
		    echo 'success';
	}
    
    //method to delete a sale
	public function delete($sale_id)
	{
		$sale_id = (int) $sale_id;

		$q = $this->_db->query('DELETE FROM sales_line WHERE sale_id = '.$sale_id);
		if($q){
			echo 'success';
		}
	}

	public function setDb(PDO $db)
	{
		$this->_db = $db;
	}

	public function __construct($db)
	{
		$this->setDb($db);
	}
}
?>