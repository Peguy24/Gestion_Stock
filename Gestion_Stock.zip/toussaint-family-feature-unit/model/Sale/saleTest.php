<?php
	// Import de la classe
  require_once("../Connection/ConnectionObject.php");
  require_once("Sale.php");
  require_once("SaleManager.php");

   $con = BddConnection::getConnection()->connect();
   global $con;
   $type = 1;

  //add
  if($type == 1){

  	$sale = new Sale([
  				'user_id'=>'1',
  				'sale_amount'=>'123'
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->add($sale);
  	echo $response;
  }

//update
  if($type == 2){
  	$sale = new Sale([
  		'sale_id'=>'1',
  		'user_id'=>'1',
  		'sale_date'=>'2020-08-28',
  		'sale_amount'=>'750'
  			]);
  	$manager = new SaleManager($con);

  	$response = $manager->update($sale);
  	echo $response;
  }

  //get
  if($type == 3){
  	$manager = new SaleManager($con);

  	$response = $manager->get(1);
  	var_dump($response);
  }

//Get all data
  if($type == 4){
  	$manager = new SaleManager($con);

  	$response = $manager->getList();
  	var_dump($response);
  }
//delete 
  if($type == 5){
  	$manager = new SaleManager($con);

  	$response = $manager->delete(2);
  }

?>