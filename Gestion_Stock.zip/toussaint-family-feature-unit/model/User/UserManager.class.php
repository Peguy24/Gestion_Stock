<?php
require_once('User.class.php');

class UserManager{
    private $_db;

    public function __construct() {
        $this->_db = BddConnection::getConnection()->connect();
    }

    public function exist($username){
        //try{
        $users = [];
            $acc = $this->_db->prepare('SELECT * FROM user WHERE user_name = :username AND is_deleted = 0');
            $acc->execute(array(':username' => $username));
            while ($data = $acc->fetch(PDO::FETCH_ASSOC))
            {
                $users[] = $data;
            }
        //}
        if(count($users) > 0){
            return true;
        }else{
            return false;
        }
    }

    public function existUpdate($username, $id){
        //try{
        $users = [];
            $acc = $this->_db->prepare('SELECT * FROM user WHERE user_name = :username AND user_id != :id AND is_deleted = 0');
            $acc->execute(array(':username' => $username, ':id'=>$id));
            while ($data = $acc->fetch(PDO::FETCH_ASSOC))
            {
                $users[] = $data;
            }
        //}
        if(count($users) > 0){
            return true;
        }else{
            return false;
        }
    }
    //Login
    public function login($user, $pass)
    {
        try{
            $users = [];
            $q = $this->_db->prepare('SELECT * FROM user WHERE user_name = :user AND password = :pass AND is_deleted = 0');
            $q->execute(array(':user'=>$user,':pass'=>$pass));       
            while ($data = $q->fetch(PDO::FETCH_ASSOC))
            {
                $users[] = $data;
            }
            
            return $users;
        }catch(Exception $e){
            return "failed";
        }        
        
    }

    // method to register a sale
	public function add(User $user)
	{
        try{
		$q = $this->_db->prepare('INSERT INTO user(first_name,last_name,phone_number,email,status,user_name,password,account_state,created_at,created_by) 
        VALUES(:first_name,:last_name,:phone_number,:email,:status,:user_name,:password,:account_state,now(),:created_by)');

		$q->execute(array(':first_name'=>$user->first_name(),':last_name'=>$user->last_name(),
                          ':phone_number'=>$user->phone_number(),':email'=>$user->email(),
                          ':status'=>$user->status(),':user_name'=>$user->user_name(),
                          ':password'=>$user->password(),':account_state'=>$user->account_state(),
                          ':created_by'=> $user->created_by()));
		
            $q1 = $this->_db->query('SELECT * FROM user ORDER BY user_id DESC LIMIT 0,1');
			$data = $q1->fetch(PDO::FETCH_ASSOC);
			$userAdded = $data;
			return $userAdded;		
        }catch ( PDOException $e ) {
            //echo$e->getMessage();
            return 'failed';
        }
	}

    //List all user on the database 
    public function allUser($id) {
        $users = [];
        try {
            $select = "SELECT * FROM user WHERE is_deleted = 0 AND user_id !=:id";
            $request = $this->_db->prepare($select);
            $request->execute(array(":id"=>$id));
             while($data = $request->fetch(PDO::FETCH_ASSOC) ) 
            {
                 $users[] = $data;
            }
            //$listeUsers = $result->fetchAll();
            return $users;
        } catch ( PDOException $e ) {
            return 'failed';
        }
    }

   //Modify the table
   public function updateUser(User $user){
    try {
        $update = $this->_db->prepare('UPDATE user set first_name=:first_name, last_name=:last_name, phone_number=:phone_number, email=:email, user_name=:user_name, password=:password, account_state=:account_state, updated_at=now(), status=:status,updated_by=:updated_by where user_id=:user_id');
        $update->execute( array(
                          ':user_id'=>$user->user_id(),
                          ':first_name'=>$user->first_name(),':last_name'=>$user->last_name(),
                          ':phone_number'=>$user->phone_number(),':email'=>$user->email(),
                          ':status'=>$user->status(),':user_name'=>$user->user_name(),
                          ':password'=>$user->password(),':account_state'=>$user->account_state(),
                          ':updated_by'=>$user->updated_by() ) );
            $q1 = $this->_db->prepare('SELECT * FROM user WHERE user_id =:id');
            $q1->execute(array(':id'=>$user->user_id()));
			$data = $q1->fetch(PDO::FETCH_ASSOC);
			$userUpdated = $data;
			//return $userUpdated;
            return "success";
    } catch ( PDOException $e ) {
        return $e->getMessage();
    }
 } 
//Modify the profile
public function updateProfile(User $user){
    try {
        $update = $this->_db->prepare('UPDATE user set first_name=:first_name, last_name=:last_name, phone_number=:phone_number, email=:email, user_name=:user_name, password=:password, updated_at=now() where user_id=:user_id');
        $update->execute( array(
                          ':user_id'=>$user->user_id(),
                          ':first_name'=>$user->first_name(),':last_name'=>$user->last_name(),
                          ':phone_number'=>$user->phone_number(),':email'=>$user->email(),
                          ':user_name'=>$user->user_name(),':password'=>$user->password()));
            $q1 = $this->_db->prepare('SELECT * FROM user WHERE user_id =:id');
            $q1->execute(array(':id'=>$user->user_id()));
			$data = $q1->fetch(PDO::FETCH_ASSOC);
			$userUpdated = $data;
			return $userUpdated;
           // return "success";
    } catch ( PDOException $e ) {
        return "failed";
    }
 } 
  //Remove a user 
  public function deleteUser($id) {
    try {
        $update = $this->_db->prepare( 'UPDATE user set is_deleted=:del where user_id=:user_id');
        $update->execute( array(
            'user_id' =>$id,
            ':del'=>1)
                 );
            return "success";
    } catch ( PDOException $e ) {
        return "failed";
    }
 }

 public function getUser($id){
    try {
        $selOne="SELECT * FROM user  where user_id = :id";
        $result = $this->_db->prepare($selOne);
        $result->execute(array(":id"=>$id));
        //$listeUsers = $result->fetchAll();
        return $result->fetch(PDO::FETCH_ASSOC);;
    } catch (PDOException $e) {
        return "failed";
      // die(  $e->getMessage() );
    }
 }
}