<?php
    class User{
        private $_user_id;
        private $_first_name;
        private $_last_name;
        private $_phone_number;
        private $_email;
        private $_status;
        private $_user_name;
        private $_passsword;
        private $_account_state;
        private $_is_deteled;
        private $_created_at;
        private $_updated_at;
        private $_created_by;
        private $_updated_by;

        //All getters for User class
        function user_id(){ return $this->_user_id;}
        function first_name(){ return $this->_first_name;} 
        function last_name(){ return $this->_last_name;} 
        function phone_number(){ return $this->_phone_number;} 
        function email(){ return $this->_email;} 
        function status(){return $this->_status;}
        function user_name(){return $this->_user_name;}
        function password(){return $this->_password;}
        function account_state(){return $this->_account_state;}
        function is_deleted(){return $this->_is_deleted;}
        function created_at(){return $this->_created_at;}
        function updated_at(){return $this->_updated_at;}
        function created_by(){return $this->_created_by;}
        function updated_by(){return $this->_updated_by;}

        //All setters here
        function setUser_id($id){
            $this->_user_id = $id;
        }
        
        function setFirst_name($fName){ 
          $this->_first_name = $fName;              
        }

        function setLast_name($lName){ 
               $this->_last_name = $lName;            
        }

        function setPhone_number($phone){ 
               $this->_phone_number = $phone;            
        }

        function setEmail($mail){ 
              $this->_email = $mail;          
        }

        function setStatus($status){
            $this->_status = $status;
        }
        
        function setUser_name($userN){
            $this->_user_name = $userN;
        }
        
        function setPassword($pass){
            $this->_password = $pass;
        }

        function setAccount_state($state){
            $this->_account_state = $state;
        }

        function setIs_delete($deleted){
            $this->_is_deleted = $deleted;
        }

        function setCreated_at($created){
            $this->_created_at = $created;
        }

        function setUpdated_at($updated){
            $this->_updated_at = $updated;
        }
        function setCreated_by($created_b){
            $this->_created_by = $created_b;
        }
        function setUpdated_by($updated_b){
            $this->_updated_by = $updated_b;
        }

        function hydrate(array $data){
            foreach($data as $key => $value){
                $method = 'set'.ucfirst($key);
                if(method_exists($this,$method)){
                    $this->$method($value);
                }
            }
        }

        //Class constructor
        function __construct(array $data){
            $this->hydrate($data);
        }
    }