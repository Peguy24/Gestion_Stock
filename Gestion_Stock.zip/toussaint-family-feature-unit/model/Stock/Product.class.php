<?php

/**
 * class represent the products
 */
//declare(strict_types=1);
class Product 
{
  private $_errors = [],
          $_product_id,
          $_user_id,
          $_product_name,
          $_price,
          $_comment,
          $_created_at,
          $_updated_at,          
          $_product_price,
          $_is_deleted;
  private $_quantity;
  public function __construct( array $data )
  {
      $this->hydrate( $data );
  }

  private function hydrate($data)
  {
    foreach ($data as $key => $value)
    {
      $method = 'set'.ucfirst($key);
 
      if (is_callable([$this, $method]))
      {
        $this->$method($value);
      }
    }
  }

  public function errors() { return $this->_errors; }
  public function product_id() { return $this->_product_id; }
  public function user_id() { return $this->_user_id; }
  public function product_name() { return $this->_product_name; }
  public function price() { return $this->_price; }
  public function comment() { return $this->_comment; }

  public function created_at() { return $this->_created_at; }
  public function updated_at(){return $this->_updated_at;}
  public function quantity() { return $this->_quantity; }
 

  public function setProduct_id( $id ) 
  {
      $this->_product_id = (int) $id;
  }

 
  public function setUser_id( $uid ) 
  {
      $this->_user_id = (int) $uid;
  }

  public function setProduct_name( $product_name ) 
  {
    if( !is_string($product_name) || empty($product_name) )
    {
        //throw new \InvalidArgumentException('Assurez-vous de rentrez du texte pour les noms de produits');
        $this->_errors[] = 'Assurez-vous de rentrez du texte pour les noms de produits';

      }

    $this->_product_name = $product_name;
  }

  public function setPrice($price) 
  {
    $this->_price = $price;
  }

  public function setComment($product_comment)
  {
    if( !is_string($product_comment) || empty($product_comment) )
    {
      $this->_errors[] = 'Assurez-vous de saisir du texte pour le commentaire';
    }
    $this->_comment = $product_comment;
  }

  public function setCreated_at($creation_date)
  {
    $this->_created_at = $creation_date;
  }

  public function setUpdated_at($update)
  {
    $this->_updated_at = $update;
  }

  public function setQuantity($product_quantity) 
  {
      // if( !is_int($product_quantity) || empty($product_quantity) )
      // {
      //   throw new Exception('Assurez-vous de saisir du chiffre pour la quantite de produit','02bc3998-b9ff-431e-9058-8ab333ff7742');
      // }
      try{
        $this->_quantity = $product_quantity;
      }catch(Exceotion $e){
        return $e->getMessage();
      }
      
  }

  private function current_date_and_time()
  {
    date_default_timezone_set('America/New_York');
    return date('Y/m/d H:i:s'); 
  }

}