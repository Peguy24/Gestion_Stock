<?php

//use jjjp\stock_management\model;

class ProductManager
{
    private $_db;

    public function __construct( PDO $db ) 
    {
        $this->_db = $db;
    }

    /**
     * determine if a product exist by product_name or product_base_id
     * 
     * return a boolean [true or false]
     */
    
    public function exists($info)
    {
        try{
            $q = $this->_db->prepare('SELECT COUNT(*) FROM product WHERE is_deleted = 0 AND product_name = :product_name');
            $q->execute([':product_name' => $info]);
            return (bool) $q->fetchColumn();
        }catch(PDOException $e){
            return "failed";
        }
    }

    /**
     * determine if a product exist by product_name except the product who 
     * is upd..by user
     * 
     * return a boolean [true or false]
     */
    public function exists_update($info, $id)
    {
           
     try{
        $q = $this->_db->prepare('SELECT COUNT(*) FROM product WHERE is_deleted = 0 AND product_name = :product_name AND product_id != :id');
        $q->execute([':product_name' => $info,':id'=>$id]);      
        return (bool) $q->fetchColumn();
     }catch(PDOException $e){
         return $e->getMessage();
     }
    }

    
    /**
     * method to add a product
     * return a product added for success
     * return failed for error
     */
    public function add( Product $product )
    {
        try{
            $request = $this->_db->prepare('INSERT INTO product 
            (user_id, product_name, quantity, created_at, comment)
            VALUES(:user_id, :product_name, :quantity, :created_at, :comment)');    
            $request->bindValue(':user_id', (int) $product->user_id(), \PDO::PARAM_INT );
            $request->bindValue( ':product_name', $product->product_name() );
            //$request->bindValue( ':price', $product->price() );
            $request->bindValue( ':quantity', $product->quantity());
            $request->bindValue( ':comment', $product->comment());
            $request->bindValue( ':created_at', $product->created_at());
            $res = $request->execute();
            // $q1 = $this->_db->query('SELECT * FROM product ORDER BY product_id DESC LIMIT 0,1');
			// $data = $q1->fetch(PDO::FETCH_ASSOC);
			// $prodAdded = $data;
            // return $prodAdded;
            return "success";
        }catch(PDOException $e){
            return "failed";
        }
    }

    /**
     * list of product
     */
    public function count()
    {
        return $this->_db->query('SELECT COUNT(*) FROM product_base')->fetchColumn();
    }
    
    /**
     * delete a product
     * return 1 for success
     * zero for failed
     */
    public function delete($id)
    {
       /* if( $this->exists($id) )
        {
        $res = 0;

        $del = $this->_db->exec('DELETE FROM  product WHERE product_base_id = '.(int) $id);

        if( $del !== 0 || $del === true ) 
        {
            $del_1 = $this->_db->exec('DELETE FROM  product_base WHERE product_base_id = '.(int) $id);
            if( $del_1 !== 0 || $del_1 === true )
            {
                $res="success";
            }
        }
        else{
            $res = 0;
        }
        }
        else
        {
           // throw new \Exception('ID introuvable');
            return 'ID introuvable';
        }
        return $res;*/
        try{
            $req = $this->_db->prepare('UPDATE product SET is_deleted = :val WHERE product_id =:id');
            $req->execute([':val' => 1,':id' => $id]);
            return 'success';
        }catch(Exception $e){
            return "failed";
        }
       
    }

public function delete_quantity($id,$qty)
    {
        try{
            $req = $this->_db->prepare('UPDATE product SET quantity = :val, updated_at=now() WHERE product_id =:id AND is_deleted = 0');
            $req->execute([':val' => $qty,':id' => $id]);
            return 'success';
        }catch(Exception $e){
            return "failed";
        }
    }
    
    /**
     * list products a specific quantity of product
     * 
     * return the products
     */

    public function getList($start = -1, $limit = -1)
    {
        try{
            $list_product = [];

            //$sql = 'SELECT * FROM product_base RIGHT JOIN product USING(product_base_id) ORDER BY product_base_id';
            $sql = 'SELECT * FROM product WHERE is_deleted = 0';

        /* if ( ($start != -1 || $limit != -1 ) )
            {
                $sql .= ' LIMIT '.(int) $limit.' OFFSET '.(int) $start;
            }*/
            
            $request = $this->_db->query($sql) or die( print_r( $this->_db->errorInfo() ) );
        
            while($data = $request->fetch(PDO::FETCH_ASSOC) ) 
            {
                $list_product[] = $data;
            }

        // $request->closeCursor();

            return $list_product;
        }catch(PDOException $e){
            return $e->getMessage();
        }
    }

    /**
     * list a specific product
     * return the product 
     */
    public function getUnique($info)
    {
                $products = [];   
                try{
                    $sql = 'SELECT * FROM  product
                    WHERE product_id = :product_id AND is_deleted = 0';
                    $q = $this->_db->prepare($sql);
                    $q->bindValue(':product_id', (int) $info, \PDO::PARAM_INT);
                    $q->execute();
                    while($data = $q->fetch(PDO::FETCH_ASSOC) ) 
                    {
                        $products[] = $data;
                    }            
                //return new Product( $product ); 
                    return $products;
                }catch(PDOException $e){
                    return $products;
                }    
                   
        
    }    


    /**
     * update a product
     */
    public function update(Product $product)
    {
        try{
            $q = 'UPDATE product SET comment = :comment, updated_at = now(),
            quantity = :quantity, product_name = :product_name WHERE product_id = :product_id';

            $request = $this->_db->prepare($q);
            $request->bindValue( ':product_id', $product->product_id(), PDO::PARAM_INT );
            $request->bindValue( ':product_name', $product->product_name() );
            $request->bindValue( ':quantity', $product->quantity() );
           // $request->bindValue( ':price', $product->price() );
            $request->bindValue( ':comment', $product->comment() );
            $request->execute();
            return "success";
            //return $response = $product->product_id()."-".$product->product_name()."-".$product->quantity()."-".$product->price()."-".$pro->comment();
        }catch(PDOException $e){
            return "failed";
        }
        
    }

    public function out_of_stock(){
        $list_product = [];

        $sql = 'SELECT * FROM product WHERE quantity <= 0  AND is_deleted = 0';
        $request = $this->_db->query($sql) or die( print_r( $this->_db->errorInfo() ) );
    
         while($data = $request->fetch(PDO::FETCH_ASSOC) ) 
         {
            $list_product[] = $data;
         }
        return $list_product;
    }

    public function out_of_stock_soon(){
        $list_product = [];

        $sql = 'SELECT * FROM product WHERE (quantity BETWEEN 1 AND 10) AND is_deleted = 0';
        $request = $this->_db->query($sql) or die( print_r( $this->_db->errorInfo() ) );
    
         while($data = $request->fetch(PDO::FETCH_ASSOC) ) 
         {
            $list_product[] = $data;
         }
        return $list_product;
    }
}