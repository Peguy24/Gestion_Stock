<?php

//use jjjp\stock_management\model;

class UnitManager
{
    private $_db;

    public function __construct( PDO $db ) 
    {
        $this->_db = $db;
    }

    /**
     * determine if a product exist by product_name or product_base_id
     * 
     * return a boolean [true or false]
     */
    
    public function exists($info)
    {
        try{
            $q = $this->_db->prepare('SELECT COUNT(*) FROM unit WHERE is_deleted = 0 AND unit_name = :unit_name');
            $q->execute([':unit_name' => $info]);
            return (bool) $q->fetchColumn();
        }catch(PDOException $e){
            return "failed";
        }
    }

    /**
     * determine if a product exist by product_name except the product who 
     * is upd..by user
     * 
     * return a boolean [true or false]
     */
    public function exists_update($info, $id)
    {
           
     try{
        $q = $this->_db->prepare('SELECT COUNT(*) FROM unit WHERE is_deleted = 0 AND unit_name = :unit_name AND unit_id != :id');
        $q->execute([':unit_name' => $info,':id'=>$id]);      
        return (bool) $q->fetchColumn();
     }catch(PDOException $e){
         return $e->getMessage();
     }
    }

    /**
     * method to add a product
     * return a product added for success
     * return failed for error
     */
    public function add( Unit $unit )
    {
        try{
            $request = $this->_db->prepare('INSERT INTO unit 
            (product_id, unit_name, unit_price, unit_quantity, created_at)
            VALUES(:product_id, :unit_name, :unit_price,:unit_quantity, now())');    
            $request->bindValue(':product_id', (int) $unit->product_id(), \PDO::PARAM_INT );
            $request->bindValue( ':unit_name', $unit->unit_name() );
            $request->bindValue( ':unit_price', $unit->unit_price() );
            $request->bindValue( ':unit_quantity', $unit->unit_quantity());            
            // $request->bindValue( ':created_at', now());
            $res = $request->execute();
            // $q1 = $this->_db->query('SELECT * FROM product ORDER BY product_id DESC LIMIT 0,1');
			// $data = $q1->fetch(PDO::FETCH_ASSOC);
			// $prodAdded = $data;
            // return $prodAdded;
            return "success";
        }catch(PDOException $e){
            return "failed";
        }
    }

    /**
     * list of product
     */
    public function count()
    {
        return $this->_db->query('SELECT COUNT(*) FROM product_base')->fetchColumn();
    }
    
    /**
     * delete a product
     * return 1 for success
     * zero for failed
     */
    public function delete($id)
    {
        try{
            $req = $this->_db->prepare('UPDATE unit SET is_deleted = :val WHERE unit_id =:id');
            $req->execute([':val' => 1,':id' => $id]);
            return 'success';
        }catch(Exception $e){
            return "failed";
        }
       
    }

public function delete_quantity($id,$qty)
    {
        try{
            $req = $this->_db->prepare('UPDATE product SET quantity = :val, updated_at=now() WHERE product_id =:id AND is_deleted = 0');
            $req->execute([':val' => $qty,':id' => $id]);
            return 'success';
        }catch(Exception $e){
            return "failed";
        }
    }
    
    
    /**
     * list a specific product
     * return the product 
     */
    public function get($info)
    {
                $units = [];   
                try{
                    $sql = 'SELECT * FROM  unit
                    WHERE product_id = :product_id AND is_deleted = 0';
                    $q = $this->_db->prepare($sql);
                    $q->bindValue(':product_id', (int) $info, \PDO::PARAM_INT);
                    $q->execute();
                    while($data = $q->fetch(PDO::FETCH_ASSOC) ) 
                    {
                        $units[] = $data;
                    }            
                //return new Product( $product ); 
                    return $units;
                }catch(PDOException $e){
                    return $units;
                }    
                   
        
    }

    /**
     * update a product
     */
    public function update(Unit $unit)
    {
        try{
            $q = 'UPDATE unit SET unit_price = :price, updated_at = now(),
            unit_quantity = :quantity, unit_name = :unit_name WHERE unit_id = :unit_id';

            $request = $this->_db->prepare($q);
            $request->bindValue( ':unit_id', $unit->unit_id(), PDO::PARAM_INT );
            $request->bindValue( ':unit_name', $unit->unit_name() );
            $request->bindValue( ':quantity', $unit->unit_quantity() );
            $request->bindValue( ':price', $unit->unit_price());
           // $request->bindValue( ':comment', $product->comment() );
            //$request->execute();
            //return "success";
            return $request->execute();
            //return $response = $product->product_id()."-".$product->product_name()."-".$product->quantity()."-".$product->price()."-".$pro->comment();
        }catch(PDOException $e){
            return $e->getMessage();
        }
        
    }

 public function getUnit()
{
     try{
        $units = [];
        $q = $this->_db->query('SELECT * FROM unit WHERE is_deleted = 0');
        
    
         while($data = $q->fetch(PDO::FETCH_ASSOC) ) 
         {
             $units[] = $data;
         }
     return $units;
     }catch(PDOException $e){
         return $e->getMessage();
     }
}

}

