<?php

/**
 * class represent the products
 */
//declare(strict_types=1);
class Unit 
{
     private     $_unit_id,
          $_product_id,
          $_unit_name,
          $_unit_price,         
          $_created_at,
          $_updated_at,
          $_is_deleted;
  private $_unit_quantity;
  public function __construct( array $data )
  {
      $this->hydrate( $data );
  }

  private function hydrate($data)
  {
    foreach ($data as $key => $value)
    {
      $method = 'set'.ucfirst($key);
 
      if (is_callable([$this, $method]))
      {
        $this->$method($value);
      }
    }
  }

  public function product_id() { return $this->_product_id; }
  public function unit_id() { return $this->_unit_id; }
  public function unit_name() { return $this->_unit_name; }
  public function unit_price() { return $this->_unit_price; }
  public function created_at() { return $this->_created_at; }
  public function updated_at(){return $this->_updated_at;}
  public function unit_quantity() { return $this->_unit_quantity; }
 

  public function setProduct_id( $id ) 
  {
      $this->_product_id = (int) $id;
  }


  public function setUnit_name( $name ) 
  {
    // if( !is_string($product_name) || empty($product_name) )
    // {
    //     //throw new \InvalidArgumentException('Assurez-vous de rentrez du texte pour les noms de produits');
    //     $this->_errors[] = 'Assurez-vous de rentrez du texte pour les noms de produits';

    //   }

    $this->_unit_name = $name;
  }

  public function setUnit_price($price) 
  {
    $this->_unit_price = $price;
  }

  public function setCreated_at($creation_date)
  {
    $this->_created_at = $creation_date;
  }

  public function setUpdated_at($update)
  {
    $this->_updated_at = $update;
  }

  public function setUnit_id($id)
  {
    $this->_unit_id = $id;
  }

  public function setUnit_quantity($quantity) 
  {
      // if( !is_int($product_quantity) || empty($product_quantity) )
      // {
      //   throw new Exception('Assurez-vous de saisir du chiffre pour la quantite de produit','02bc3998-b9ff-431e-9058-8ab333ff7742');
      // }
      try{
        $this->_unit_quantity = $quantity;
      }catch(Exceotion $e){
        return $e->getMessage();
      }
      
  }

  private function current_date_and_time()
  {
    date_default_timezone_set('America/New_York');
    return date('Y/m/d H:i:s'); 
  }

}