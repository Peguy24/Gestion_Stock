<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Utilisateurs | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
    </head>

    <body >
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap ">
                <?php include('partials/menu.php'); ?>

                <div class="main-content">
                        <div class="container">
                            <div class="page-header ">
                                <div class="row">
                                    <!-- <div class="col-12">
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong>Holy guacamole!</strong> You should check in on some of those fields below.
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>

                                    </div> -->
                                    
                                    <div class="col-lg-4">
                                        <nav class="breadcrumb p-0" style="background:none !important" aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item">
                                                    <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item active" aria-current="page">Data Table</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header"><div><h3>Data Table</h3></div>
                                        <div class="ml-auto">
                                        <button  type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#AddModal">
                                            AJOUTER UTILISATEUR
                                        </button>
                                        </div>
                                    </div>
                                        <div class="card-body" style="height: 400px;max-height:400px; overflow:auto">
                                            <table id="myTable" class="p-2 table">
                                                <thead>
                                                    <tr>
                                                        <th>Id</th>
                                                        <th>Prenom</th>
                                                        <th>Nom</th>
                                                        <th>Pseudo</th>
                                                        <th>Status</th>
                                                        <th >Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="t_body">
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('partials/footer.php');?>
                    
                </div>
            </div>
        <?php include('partials/modal/user-modal/add-modal.php');?>
        <?php include('partials/modal/user-modal/modify-modal.php');?>
        <?php include('partials/modal/user-modal/delete-modal.php');?>
        <?php include('partials/scripts.php');?>
        <!-- <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> -->
        <script src="../controller/user/user.js"></script>
        <!-- <script src="//cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script> -->
        <!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> -->
        
        <script>
            (function($){
                //$(document).ready( function () {
                    
               // } );
                //$('.user-item').addClass('active')
                activeMenu(".user-item");
                //$('.alert').addClass("show")
                setTimeout(() => {
                    $('.alert').alert("close")
                }, 5000);
            })(jQuery)
        </script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
      
    </body>
</html>