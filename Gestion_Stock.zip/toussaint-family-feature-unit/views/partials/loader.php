<div id="cover"> 
            <div class="spinner-border" style="width: 5rem; height: 5rem;color:rgb(255,99,132);" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <h3 class="text-center" style="color:rgb(255,99,132);">Toussaint Family</h3>
        </div>