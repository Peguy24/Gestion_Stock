<div class="nav-item profileItem" >
  <a href="profile.php" id="profile-item"><i class="fa fa-user "></i><span>PROFIL</span></a>
</div>