<div class="nav-item accountingItem">
   <a href="accounting.php"><i class="fa fa-chart-line"></i><span>COMPTABILITE</span></a>
</div>