<div class="nav-item stock-item">
   <a href="stock.php" class="d-flex align-items-center">
   <i class="fas fa-warehouse"></i>
      <span class="">PRODUIT</span>
   </a>
</div>