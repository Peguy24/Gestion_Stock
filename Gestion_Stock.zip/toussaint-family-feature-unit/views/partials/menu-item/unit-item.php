<div class="nav-item unit-item">
   <a href="unit.php" class="d-flex align-items-center">
   <i class="fas fa-warehouse"></i>
      <span class="">Unite</span>
   </a>
</div>