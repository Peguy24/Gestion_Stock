<div class="nav-item user-item mb-3">
   <a href="user.php"><i class="fa fa-users"></i><span>UTILISATEUR</span></a>
</div>