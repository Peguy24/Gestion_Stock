<!-- <div class="nav-item has-sub saleItem">
     <a href="#"><i  class="ik ik-lock"></i><span>VENTE</span></a>
      <div class="submenu-content">
          <a href="sale.php" class="menu-item">AJOUTER UNE VENTE</a>
          <a href="saleList.php" class="menu-item">LISTER LES VENTES</a>
      </div>
</div> -->
<div class="nav-item saleItem">
   <a href="sale.php" class="d-flex align-items-center ">
   <i class="fas fa-cash-register"></i>
      <span class="">SALE</span>
   </a>
</div>