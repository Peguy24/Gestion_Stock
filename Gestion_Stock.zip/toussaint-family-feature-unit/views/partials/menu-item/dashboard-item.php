<div class="nav-item active dash mb-3 pt-1 d-flex">
    <a href="dashboard.php" class="">
        <i class="fa fa-home " ></i>
        <span style="position:relative !important;top:2px !important;">DASHBOARD</span>
    </a>
</div>