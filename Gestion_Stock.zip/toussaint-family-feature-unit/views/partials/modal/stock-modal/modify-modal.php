<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="ModifyModal" tabindex="-1" role="dialog" aria-labelledby="ModifyModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModifyModalLabel">MODIFIER PRODUIT</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="update-prod-form">
        
          <div class="form-group">
          <label for="exampleInputEmail1">NOM PRODUIT</label>
            <input type="text" class="form-control" name="product_name" id="product-namem" placeholder="nom du produit" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
          <div class="row">
              <div class="col">
                <div class="form-group">
                    <label for="exampleInputEmail1">Quantité </label>
                    <input type="number" name="qty" id="quantitym" readonly class="form-control" placeholder="23" required/>          
                </div>
              </div>
              <div class="col">
                <div class="form-group">
                    <label for="exampleInputEmail1">Augmenté la Quantité </label>
                    <input type="number" name="quantity" id="quantityNew" min="0" class="form-control" placeholder="23" required/>
                    <div class="text-error">
                        Please provide a valid zip.
                    </div>           
                 </div>
              </div>
          </div>
            
       
       
          <!-- <div class="form-group">
            <label for="exampleInputEmail1">PRIX </label>
            <input type="number" step="0.00001" class="form-control"  name="price" id="pricem" aria-describedby="emailHelp" placeholder="234,50" required />
            <div class="text-error">
                    Please provide a valid zip.
            </div>
        </div> -->

          

        <div class="row">
          <div class="col">
            <div class="form-group">
            <label for="exampleInputEmail1">DATE D'AJOUT</label><br/>
            <input type="text" readonly class="form-control"  name="date" id="datem" aria-describedby="emailHelp" required />
              <div class="text-error">
                      Please provide a valid zip.
              </div>
          </div>
          </div>
          <div class="col">
            <div class="form-group">
            <label for="exampleInputEmail1">DATE DE MODIFICATION</label><br/>
            <input type="text" readonly class="form-control"  name="datem" id="updated_at" aria-describedby="emailHelp" required />
              <div class="text-error">
                      Please provide a valid zip.
              </div>
          </div>
          </div>
        </div>
        <div class="form-group">
          <label for="exampleTextarea1">COMMENTAIRE</label>
            <textarea class="form-control" id="commentm" rows="4" name="comment"></textarea>
        </div>
        <input type="hidden" name="type" value="2"/>
        <input type="hidden" name="product_id" id="prod_id"/>
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary close" data-dismiss="modal">ANNULER</button>
        <button id="update-prod" type="submit" class="btn btn-primary">ENREGISTRER</button>
      </div>
    </div>
  </div>
</div>