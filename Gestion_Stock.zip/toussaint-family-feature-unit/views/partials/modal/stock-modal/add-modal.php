<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="AddModal" tabindex="-1" role="dialog" aria-labelledby="AddModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AddModalLabel">AJOUTER PRODUIT</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="prod-form">
        
          <div class="form-group">
          <label for="exampleInputEmail1">NOM PRODUIT</label>
            <input type="text" class="form-control" name="product_name" id="product-name" placeholder="nom du produit" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
         
            <div class="form-group">
              <label for="exampleInputEmail1">Quantité</label>
              <input type="number" name="quantity" id="quantity" class="form-control" placeholder="23" required/>
              <div class="text-error">
                Please provide a valid zip.
              </div>           
          </div>
       
       
          <!-- <div class="form-group">
            <label for="exampleInputEmail1">PRIX </label>
            <input type="number" step="0.00001" class="form-control"  name="price" id="price" aria-describedby="emailHelp" placeholder="234,50" required />
            <div class="text-error">
                    Please provide a valid zip.
            </div>
          </div> -->

          <div class="form-group">
          <label for="exampleInputEmail1">DATE D'AJOUT</label><br/>
          <input type="date" class="form-control"  name="date" id="date" aria-describedby="emailHelp" required />
            <div class="text-error">
                    Please provide a valid zip.
            </div>
        </div>
        <div class="form-group">
          <label for="exampleTextarea1">COMMENTAIRE</label>
            <textarea class="form-control" id="exampleTextarea1" rows="4" name="comment"></textarea>
        </div>
        <input type="hidden" name="type" value="1"/>
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="add-prod" type="submit" class="btn btn-primary">ENREGISTRER</button>
      </div>
    </div>
  </div>
</div>