<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="DeleteModal" tabindex="-1" role="dialog" aria-labelledby="DeleteModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="DeleteModalModalLabel">SUPPRIMER PRODUIT</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>VOULEZ VOUS VRAIMENT REALISER CETTE ACTION ?</p>
        <form id="sup-form">
        <div class="form-group hide">
          <label for="exampleInputEmail1">VEUILLEZ RENSEIGNEZ LE NOMBRE DE PRODUIT A SUPPRIMER</label>
          <input type="number" class="form-control" aria-describedby="emailHelp" id="del_qty" min="1"  value="1" required>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
          <div class="row">
            <div class="col">
              <div class="form-check form-check-inline">
              <input class="form-check-input option" type="radio" checked name="del_option"  id="num" >
              <label class="form-check-label" for="inlineRadio2">Renseigner le nombre</label>
              </div>
            </div>
            <div class="col">
              <div class="form-check form-check-inline">
              <input class="form-check-input option" type="radio" name="del_option"  id="all" >
              <label class="form-check-label" for="inlineRadio2">Supprimer tout le stock</label>
              </div>
            </div>
          </div>
           <!-- <label>Quantite En Stock</label> <input type="number" readonly id="qty_stock" /><br/> -->
           <!-- <label>Quantite A Supprimer</label><input type="number" id="del_qty" min="1"   required/>
            <label>Supprimer une quantite</label><input type="radio" name="del_option"  class="option"  id="num"/><br/>
            <label>Supprimer le produit du systeme</label><input type="radio" name="del_option" class="option" id="all"/> -->
        </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="delete-prod" type="submit" class="btn btn-danger">Supprimer</button>
      </div>
    </div>
  </div>
</div>