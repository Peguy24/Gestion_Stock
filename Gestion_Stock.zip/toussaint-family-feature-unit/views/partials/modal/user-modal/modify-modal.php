<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="ModifyModal" tabindex="-1" role="dialog" aria-labelledby="ModifyModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModifyModalLabel">MODIFIER UTILISATEUR</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="update-form">
        <input type="hidden" name="user-id" id="user-id">
        <div class="row">
          <div class="col">
          <label for="exampleInputEmail1">PRENOM</label>
            <input type="text" class="form-control" name="first-name" id="first-namem" placeholder="First name" value="Al" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div> 
          </div>
          <div class="col">
          <label for="exampleInputEmail1">NOM</label>
            <input type="text" name="last-name" id="last-namem" class="form-control" placeholder="Last name" value="AB" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">TELEPHONE</label>
          <input type="text" class="form-control"  name="phone" id="phonem" aria-describedby="emailHelp" placeholder="Enter email" value="325" required>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">EMAIL </label>
          <input type="email" class="form-control" name="email" id="emailm" aria-describedby="emailHelp" placeholder="Enter email" value="ad@gmail.com" required>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">PSEUDO</label>
          <input type="text" class="form-control" name="user-name" id="user-namem" aria-describedby="emailHelp" placeholder="Pseudo"  required>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">MOT DE PASSE</label>
          <input type="text" class="form-control" name="password" id="passwordm" aria-describedby="emailHelp" placeholder="Enter email" value="1234" required>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
        <div class="row">
          <div class="col">
          <label for="exampleInputEmail1">STATUS</label>
          <select id="statusm" name="status" class="form-control" required>
          <option value="">INCONNU</option>
          <option value="administrateur" selected class="status" id="administrateur">ADMINISTRATEUR</option>
          <option value="superviseur" class="status" id="superviseur">SUPERVISEUR</option>
          <option value="caissier" class="status" id="caissier">CAISSIER(E)</option>
          </select>
          <div class="text-error">
                Please provide a valid zip.
          </div>
          </div>
          <div class="col">
          <label for="exampleInputEmail1">ETAT DU COMPTE</label><br/>
          <div class="form-check form-check-inline">
            <input class="form-check-input account-state" type="radio" name="account-state" id="active" value="active">
            <label class="form-check-label" for="inlineRadio1">ACTIVE</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input account-state" type="radio" name="account-state" id="inactive" value="inactive">
            <label class="form-check-label" for="inlineRadio2">INACTIVE</label>
          </div>
        </div>
        </div>
        <input type="hidden" name="type" value="4"/>
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="update-user" type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>