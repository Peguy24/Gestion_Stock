<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="AddModal" tabindex="-1" role="dialog" aria-labelledby="AddModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AddModalLabel">AJOUTER UTILISATEUR</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="user-form">
        <div class="row">
          <div class="col">
          <label for="exampleInputEmail1">PRENOM</label>
            <input type="text" class="form-control" name="first-name" id="first-name" placeholder="First name" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
          <div class="col">
            <div class="form-group">
              <label for="exampleInputEmail1">NOM</label>
              <input type="text" step="2" name="last-name" id="last-name" class="form-control" placeholder="Last name" required/>
              <div class="text-error">
                Please provide a valid zip.
              </div>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="form-group">
            <label for="exampleInputEmail1">TELEPHONE</label>
            <input type="text" class="form-control"  name="phone" id="phone" aria-describedby="emailHelp" placeholder="+5094555555" value="325" >
            
          </div>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">EMAIL </label>
          <input type="email" class="form-control" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email"  >
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">PSEUDO</label>
          <input type="text" class="form-control" name="user-name" id="user-name" aria-describedby="emailHelp" placeholder="Pseudo"  required>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">MOT DE PASSE</label>
          <input type="password" class="form-control" name="password" id="password" aria-describedby="emailHelp" placeholder="Enter mot de passe"  required>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
        <div class="row">
          <div class="col">
          <label for="exampleInputEmail1">STATUS</label>
          <select id="status" name="status" class="form-control" required>
            <option value="">inconnu</option>
          <option value="administrateur" >ADMINISTRATEUR</option>
          <option value="superviseur" >SUPERVISEUR</option>
          <option value="caissier">CAISSIER(E)</option>
          </select>
          <div class="text-error">
                Please provide a valid zip.
          </div>
          </div>
          <div class="col">
          <label for="exampleInputEmail1">ETAT DU COMPTE</label><br/>
          <div class="form-check form-check-inline">
            <input class="form-check-input account-state" type="radio"  name="account-state"  value="active" required>
            <label class="form-check-label" for="inlineRadio1">ACTIVE</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input account-state" type="radio" name="account-state"  value="inactive">
            <label class="form-check-label" for="inlineRadio2">INACTIVE</label>
          </div>
        </div>
        <div class="text-error">
                Please provide a valid zip.
        </div>
        </div>
        <input type="hidden" name="type" value="2"/>
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="add-user" type="submit" class="btn btn-primary">ENREGISTRER</button>
      </div>
    </div>
  </div>
</div>