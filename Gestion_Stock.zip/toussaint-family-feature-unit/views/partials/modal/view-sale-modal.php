<div class="modal fade" id="AddModal2" tabindex="-1" role="dialog" aria-labelledby="AddModal2Label" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AddModalLabel2">IMPRIMMER LA VENTE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="user-form2">
        <div class="row">
          <div class="col">
          <label for="exampleInputEmail1">Sous-total</label>
            <input type="text" class="subtotal subtotalm form-control" name="subtotal" readonly/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
          <div class="col">
            <div class="form-group">
              <label for="exampleInputEmail1">Total</label>
              <input type="text"  name="total" readonly class="total totalm form-control" placeholder="Last name" required/>
              <div class="text-error">
                Please provide a valid zip.
              </div>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="form-group">
            <label for="exampleInputEmail1">Cash</label>
            <input type="number" step="0.000001" class="cash cashm cashmp form-control"  name="cash" aria-describedby="emailHelp" required id="cash/> 
          </div>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Change </label>
          <input type="email" class="change changem changems form-control" name="change" readonly value="0" />
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Item count</label>
          <input type="text" class="item_count item_countm form-control" name="item_count" readonly/>
          <div class="text-error">
                Please provide a valid zip.
          </div>
        </div>
        
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="add-sale" type="submit" class="btn btn-primary">ENREGISTRER</button>
      </div>
    </div>
  </div>
</div>