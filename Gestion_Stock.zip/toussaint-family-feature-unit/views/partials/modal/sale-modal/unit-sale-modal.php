<div class="modal fade" id="UnitSaleModal" tabindex="-1" role="dialog" aria-labelledby="UnitSaleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="UnitSaleModalLabel">CHOISIR L'UNITE DE VENTE ET LA QUANTITE </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="unit-sale-form">
            <div class="row">
                <div class="col">
                <label for="exampleInputEmail1">Unite de Vente</label>
                <input list="unitSale" name="browser" id="unitSaleSearch" class="form-control" required /> 
                <datalist id="unitSale" >                                       
                </datalist>
                  <div class="text-error">
                      Please provide a valid zip.
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Quantite de l'unite</label>
                    <input type="text"  name="qty1" id="unitQty" class="form-control" placeholder="" readonly/>
                    <div class="text-error">
                      Please provide a valid zip.
                    </div>
                  </div>
                </div>
            </div>
            <div >
              <div class="form-group">
                <label for="exampleInputEmail1">Prix de l'unite</label>
                <input type="text"  name="unitPrice" class="form-control" id="unitPrice" placeholder="" readonly/>
                <div class="text-error">
                  Please provide a valid zip.
                </div>
              </div>
            </div>
         
        </form>
      </div>
      <div class="modal-footer">        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="addUnit-sale" type="button" class="btn btn-primary">AJOUTER</button>
      </div>
    </div>
  </div>
</div>