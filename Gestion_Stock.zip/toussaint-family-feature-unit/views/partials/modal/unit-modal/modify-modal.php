<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="EditModal" tabindex="-1" role="dialog" aria-labelledby="EditModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EditModalLabel">AJOUTER UNITE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="update-unit-form">
        
          <div class="form-group">
          <label for="exampleInputEmail1">NOM UNITE</label>
            <input type="text" class="form-control" name="unit_name" id="unit-namem" placeholder="nom imite" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
         
            <div class="form-group">
              <label for="exampleInputEmail1">Quantité</label>
              <input type="number" name="unit_quantity" id="unit-quantitym" class="form-control" placeholder="23" required/>
              <div class="text-error">
                Please provide a valid zip.
              </div>           
          </div>
       
       
          <div class="form-group">
            <label for="exampleInputEmail1">PRIX </label>
            <input type="number" step="0.00001" class="form-control"  name="unit_price" id="unit-pricem" aria-describedby="emailHelp" placeholder="234,50" required />
            <div class="text-error">
                    Please provide a valid zip.
            </div>
        </div>

        <div class="row">
                                            <div class="col">
                                            <div class="form-group">
                                            <label for="exampleInputEmail1">DATE D'AJOUT</label><br/>
                                            <input type="text" readonly class="form-control"  name="date" id="unit-datem" aria-describedby="emailHelp" value="<?=$prod['created_at']?>" required />
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col">
                                            <div class="form-group">
                                            <label for="exampleInputEmail1">DATE DE MODIFICATION</label><br/>
                                            <input type="text" readonly class="form-control"  name="datem" id="unit-updated_atm" aria-describedby="emailHelp" value="<?=$prod['updated_at']?>" required />
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                            </div>
                                            </div>
                                        </div>

        <div class="form-group">
          <label for="exampleTextarea1">COMMENTAIRE</label>
            <textarea class="form-control" id="exampleTextarea1" rows="4" name="unit-comment"></textarea>
        </div>
        <input type="hidden" name="type" value="2"/>
        <input type="hidden" name="unit_id" id="unit_id" />
        <!-- <input type="hidden" name="product_qty" id="product_qty_unit" /> -->
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <a href="#" id="edit-unit" type="button" class="btn btn-primary">MODIFIER</a>
      </div>
    </div>
  </div>
</div>