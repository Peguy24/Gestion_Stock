<!-- Button trigger modal -->
<!-- Modal -->
<div class="modal fade" id="AddModal" tabindex="-1" role="dialog" aria-labelledby="AddModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AddModalLabel">AJOUTER UNITE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="unit-form">
        
          <div class="form-group">
          <label for="exampleInputEmail1">NOM UNITE</label>
            <input type="text" class="form-control" name="unit_name" id="unit-name" placeholder="nom imite" required/>
            <div class="text-error">
                Please provide a valid zip.
            </div>
          </div>
         
            <div class="form-group">
              <label for="exampleInputEmail1">Quantité</label>
              <input type="number" name="unit_quantity" id="unit-quantity" class="form-control" placeholder="23" required/>
              <div class="text-error">
                Please provide a valid zip.
              </div>           
          </div>
       
       
          <div class="form-group">
            <label for="exampleInputEmail1">PRIX </label>
            <input type="number" step="0.00001" class="form-control"  name="unit_price" id="unit-price" aria-describedby="emailHelp" placeholder="234,50" required />
            <div class="text-error">
                    Please provide a valid zip.
            </div>
        </div>

         
        <div class="form-group">
          <label for="exampleTextarea1">COMMENTAIRE</label>
            <textarea class="form-control" id="exampleTextarea1" rows="4" name="unit-comment"></textarea>
        </div>
        <input type="hidden" name="type" value="1"/>
        <input type="hidden" name="product_id" id="product_id_unit" />
        <input type="hidden" name="product_qty" id="product_qty_unit" />
      </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ANNULER</button>
        <button id="add-unit" type="submit" class="btn btn-primary">ENREGISTRER</button>
      </div>
    </div>
  </div>
</div>