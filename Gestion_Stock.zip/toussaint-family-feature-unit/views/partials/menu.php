<div class="app-sidebar colored">
                    <div class="sidebar-header">
                        <a class="header-brand" href="dashboard.php">
                            <!-- <div class="logo-img">
                               <img src="src/img/brand-white.svg" class="header-brand-img" alt="lavalite"> 
                            </div> -->
                            <span class="text" style="font-size: 15px !important;">TOUSSAINT FAMILY</span>
                        </a>
                        <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
                        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
                    </div>
                    
                    <div class="sidebar-content">
                    <div class="card " style="background: none !important">
                        <div class="card-body">
                            <div class="text-center text-white"> 
                                            <!-- <img src="../img/user.jpg" class="rounded-circle" width="150" /> -->
                                <i class="fa fa-user-circle" style="font-size:4rem;color:white"></i>
                                 <h4 class="card-title mt-10" id="fullNameM">John Doe</h4>
                                  <p class="card-subtitle" id="statusM">Front End Developer</p>
                                  <!-- <p class="card-subtitle" id="emailM">Front End Developer</p> -->
                             </div>
                        </div>
                    </div>
                        <div class="nav-container">
                            <nav id="main-menu-navigation" class="navigation-main">
                            <?php
                            $status = $_SESSION['tf_status'];
                        if($status == 'administrateur'){
                          include('menu-item/dashboard-item.php');
                          include('menu-item/user-item.php');
                          include('menu-item/stock-item.php');
                          //include('menu-item/unit-item.php');
                          include('menu-item/accounting-item.php');                          
                        }else if($status == 'superviseur'){
                          include('menu-item/dashboard-item.php');
                          include('menu-item/stock-item.php');
                          //include('menu-item/unit-item.php');
                          include('menu-item/accounting-item.php');
                        }                        
                        include('menu-item/sale-item.php');
                        include('menu-item/profil-item.php');
                        
                        /*if($_SESSION['status'] !== 'caissier' && $_SESSION['status'] !== 'superviseur')
                        {
                          include('menu-item/dashboard-item.php');
                          include('menu-item/stock-item.php');
                          include('menu-item/sale-item.php');
                          include('menu-item/account-item.php');
                          include('menu-item/accounting-item.php');
                        }
                        else
                        {
                          include('menu-item/sale-item.php');
                        }
                        if ($_SESSION['status'] == 'administrateur')
                        {
                          include('menu-item/return-item.php');
                        }

                        if(isset($_GET['user']))
                        {
                          include('menu-item/profil-item.php');
                        }*/
                  ?>
                            </nav>
                        </div>
                    </div>
                </div>