                                            <div class="row mt-3 ml-1">
                                                <div class="col-12 row">
                                                    <div class="btn-group btn-group-toggle mr-auto d-flex flex-wrap" data-toggle="buttons">
                                                        <label class="btn btn-danger" id=<?=$idSaleDaily?>>
                                                            AUJOURD'HUI
                                                            <input type="radio" name="options" id="option1" autocomplete="off">
                                                        </label>
                                                        <!-- <label class="btn btn-primary mx-2 mb-2">
                                                            CETTE SEMAINE
                                                            <input type="radio" name="options" id="option2" autocomplete="off">
                                                        </label> -->
                                                        <label class="btn btn-success ml-2"  id=<?=$idSaleMonthly?> >
                                            
                                                            <input type="radio" name="options" id="option3" autocomplete="off"> CE MOIS-CI
                                                        </label>
                                                        <label class="btn btn-success ml-2 mb-2" id=<?=$idSaleYearly?> >
                                                            CETTE ANNEE
                                                            <input type="radio" name="options" id="option3" autocomplete="off"> 
                                                        </label>
                                                        <label class="btn btn-success ml-2"  id=<?=$idSales?>>
                                                            TOUTES LES VENTES
                                                            <input type="radio" name="options" id="option3" autocomplete="off">
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>