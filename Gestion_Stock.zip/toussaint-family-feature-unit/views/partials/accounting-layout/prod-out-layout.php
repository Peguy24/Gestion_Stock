<div class="tab-pane fade" id="prod_out" role="tabpanel" aria-labelledby="pills-profile-tab">
                                            <div class="card-body" style="height: 400px;max-height:400px; overflow:auto">
                                                    <table id="tableProdOut" class="table m-0 p-0" >
                                                        <thead>
                                                            <tr>
                                                            <th>Id</th>
                                                            <th>Nom</th>
                                                            <th>Prix</th>
                                                            <th>Quantite</th>
                                                            
                                                            <!-- <th >Action</th> -->
                                                            </tr>
                                                        </thead>
                                                        <tbody id="t_body_prod_out" class="m-0 p-0">
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>