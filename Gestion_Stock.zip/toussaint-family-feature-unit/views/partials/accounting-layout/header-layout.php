<div class="row clearfix">
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body bg-primary">
                                        <div class="d-flex ">
                                            <div class="state">
                                                <h6>Vente </h6>
                                                <h2 id="daily_sale_qty">0</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-award"></i>
                                            </div> -->
                                            
                                        </div>
                                        <small class="text-small mt-10 d-block">Vente Realisée Aujourd'hui</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body " style="background-color:#3498db;">
                                        <div class="d-flex ">
                                            <div class="state">
                                                <h6>Retour </h6>
                                                <h2 id="daily_return_qty">0</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-award"></i>
                                            </div> -->
                                            
                                        </div>
                                        <small class="text-small mt-10 d-block">Retour Realisée Aujourd'hui</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body bg-success">
                                        <div class="d-flex ">
                                            <div class="state">
                                                <h6>Montant Total </h6>
                                                <h2 id="daily_sale_amount">0 HTG</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-thumbs-up"></i>
                                            </div> -->
                                           
                                        </div>    
                                        <small class="text-small mt-10 d-block">Montant Total De Vente D'Aujourd'hui</small>                                    
                                    </div>                                   
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body " style="background-color:#1abc9c;">
                                        <div class="d-flex ">
                                            <div class="state">
                                                <h6>Montant Total </h6>
                                                <h2 id="daily_return_amount">0 HTG</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-thumbs-up"></i>
                                            </div> -->
                                           
                                        </div>    
                                        <small class="text-small mt-10 d-block">Montant Total De Retour D'Aujourd'hui</small>                                    
                                    </div>                                   
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body bg-danger">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="state">
                                                <h6>En Rupture De Stock</h6>
                                                <h2 id="prod_out_of_stock">0</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-calendar"></i>
                                            </div> -->
                                        </div>
                                        <small class="text-small mt-10 d-block">Produits En Ruptures De Stock</small>
                                    </div>
                                    <!-- <div class="progress progress-sm">
                                        <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="31" aria-valuemin="0" aria-valuemax="100" style="width: 31%;"></div>
                                    </div> -->
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12">
                                <div class="widget">
                                    <div class="widget-body bg-warning">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="state">
                                                <h6> Bientot En Rupture </h6>
                                                <h2 id="prod_out_of_stock_soon">0</h2>
                                            </div>
                                            <!-- <div class="icon">
                                                <i class="ik ik-calendar"></i>
                                            </div> -->
                                        </div>
                                        <small class="text-small mt-10 d-block">Produits Bientot En Ruptures De Stock</small>
                                    </div>
                                    <!-- <div class="progress progress-sm">
                                        <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="31" aria-valuemin="0" aria-valuemax="100" style="width: 31%;"></div>
                                    </div> -->
                                </div>
                            </div>
                        </div>