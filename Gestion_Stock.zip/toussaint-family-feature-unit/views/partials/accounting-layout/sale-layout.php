                                 
                                        <div class="tab-pane fade show active" id="sales" role="tabpanel" aria-labelledby="pills-timeline-tab">
                                            <?php 
                                                $idSaleDaily="daily_sale_btn";
                                                $idSaleMonthly="this_month_sale";
                                                $idSaleYearly="this_year_sale";
                                                $idSales="all_sales";
                                            ?>
                                            <!-- header for tab-pane sales and return-->
                                            <?php include("header-tab-pane-sale.php");?>
                                            <div class="card-body" style="height: 400px;max-height:400px; overflow:auto" id="card-body-sale">
                                                <table id="tableSale" class="table m-0 p-0" >
                                                    <thead>
                                                        <tr>
                                                            <th>CODE</th>
                                                            <th>Realise Par</th>
                                                            <th>Nombres de Produit</th>
                                                            <th>Montant</th>
                                                            <th>Cash</th>
                                                            <th >Change</th>
                                                            <th >Date</th>
                                                            <th >Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="t_body_sale" class="m-0 p-0">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="return" role="tabpanel" aria-labelledby="pills-profile-tab">
                                        <?php 
                                                $idSaleDaily="daily_return_btn";
                                                $idSaleMonthly="this_month_return";
                                                $idSaleYearly="this_year_return";
                                                $idSales="all_returns";
                                            ?>
                                            <!-- header for tab-pane sales and return-->
                                             <?php include("header-tab-pane-sale.php");?>
                                            <div class="card-body" style="height: 400px;max-height:400px; overflow:auto">
                                                    <table id="tableReturn" class="table m-0 p-0" >
                                                        <thead>
                                                            <tr>
                                                                <th>CODE</th>
                                                                <th>Realise Par</th>
                                                                <th>Nombres de Produit</th>
                                                                <th>Montant</th>
                                                                <th>Cash</th>
                                                                <th >Change</th>
                                                                <th >Date</th>
                                                                <th >Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="t_body_sale_return" class="m-0 p-0">
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>