
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800" rel="stylesheet">

<link rel="stylesheet" href="../plugins/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css"> 
<link rel="stylesheet" href="../plugins/icon-kit/dist/css/iconkit.min.css">
<link rel="stylesheet" href="../plugins/ionicons/dist/css/ionicons.min.css">
<link rel="stylesheet" href="../plugins/perfect-scrollbar/css/perfect-scrollbar.css">
<!-- <link rel="stylesheet" href="../plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css"> -->
<link rel="stylesheet" href="../plugins/jvectormap/jquery-jvectormap.css">
<link rel="stylesheet" href="../plugins/tempusdominus-bootstrap-4/build/css/tempusdominus-bootstrap-4.min.css">
<link rel="stylesheet" href="../plugins/weather-icons/css/weather-icons.min.css">
<link rel="stylesheet" href="../plugins/c3/c3.min.css">
<link rel="stylesheet" href="../plugins/owl.carousel/dist/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../plugins/owl.carousel/dist/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="../dist/css/theme.min.css">
<link rel="stylesheet" href="../dist/css/styles.css">
<link rel="stylesheet" href="../plugins/fontawesome/css/all.css">
<link rel="stylesheet" href=" ../plugins/toastr-master/build/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.0/css/buttons.dataTables.min.css">

<script src="../src/js/vendor/modernizr-2.8.3.min.js"></script>

<!-- <link rel="stylesheet" href="../plugins/bootstrap/dist/css/bootstrap.min.css"> -->