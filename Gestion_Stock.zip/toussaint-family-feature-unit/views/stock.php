<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Toussaint Family - Stock</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
        <!-- <style>
            #del_qty{
                max-width: 30px !important;
                width:30px !important;
                min-width: 30px !important;
            }
        </style> -->
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap">
            <?php include('partials/menu.php'); ?>

            <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header m-0 p-0">
                            <div class="row">
                                <div class="col-lg-4">
                                    <nav class="breadcrumb p-0" style="background:none !important" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Produit</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header"><div><h3>Liste Produit</h3></div>
                                    <div class="ml-auto">
                                    <button  type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#AddModal">
                                        AJOUTER PRODUIT
                                    </button>
                                    </div>
                                  </div>
                                    <!-- <div class="card-body" style="height: 400px;max-height:400px; overflow:auto">
                                        <table id="myTable" class="table table-hover m-0 p-0" >
                                            <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Nom</th>
                                                    <th>Prix</th> 
                                                    <th>Quantite</th>
                                                     <th>Status</th>
                                                    <th >Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="t_body_prod" class="m-0 p-0">
                                            </tbody>
                                        </table> -->
                                    <!-- </div> -->
                                    <div class="card-body" style="height: 400px;max-height:400px; overflow:auto">
                                            <table id="myTable" class="p-2 table">
                                                <thead>
                                                    <tr>
                                                    <th>Id</th>
                                                    <th>Nom</th>
                                                    <!-- <th>Prix</th>  -->
                                                    <th>Quantite</th>
                                                     <!-- <th>Status</th> -->
                                                    <th >Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="t_body_prod">
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('partials/footer.php');?>
                
            </div>
        </div>
        <?php include('partials/modal/stock-modal/add-modal.php');?>
        <?php include('partials/modal/stock-modal/modify-modal.php');?>
        <?php include('partials/modal/stock-modal/delete-modal.php');?>
        <?php include('partials/scripts.php');?>
        <script src="../controller/Stock/product.js"></script>
        <script>
            (function($){
                //$('.user-item').addClass('active')
                activeMenu(".stock-item");
            })(jQuery)
        </script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
      
    </body>
</html>