<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Vente | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
        <!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
        
    </head>

    <body>
    
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap">
            <?php include('partials/menu.php'); ?>

            <div class="main-content">
            <div class="container-fluid">
                        <div class="page-header m-0 p-0 ">
                            <div class="row">
                                <div class="col-lg-4 d-none d-md-block">
                                    <nav class="breadcrumb p-0 my-0" style="background:none !important" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Vente</li>
                                        </ol>
                                    </nav>
                                </div>
                                
                            </div>
                        </div>

                        <div class="row">
                            
                            <!-- <div class="col-lg-5 col-md-7"> -->
                            <div class="col-12 col-lg-5 col-md-7">
                                <div class="card p-0 " style="height: 500px;max-height:500px" >
                               
                                <!-- <div class="card-header d-lg-none d-sm-block row"> -->
                                <div class="card-header d-none  row">
                                    <form class="mx-auto">
                                        <label for="browser" class="">Rechercher le Produit</label></br>
                                        <div class="d-flex">
                                        <input list="productsM" name="browser" id="prod_search" class="form-control" required />
                                        
                                        <datalist id="productsM">                                       
                                        </datalist>
                                        <button class="btn btn-success text-center" type="button" value="Add" id="add-prod-mobile">
                                            <i class="fas fa-plus text-center"></i>
                                        </button>
                                        </div>
                                    </form>
                                    
                                </div>
                                <div class="card-body p-0 " style="height: 300px;max-height:300px; overflow:auto">
                                 <form id="checkout" method="post" class="chk " >
                                    
                                        <table id="customers2" class="table table-hover chk-header m-0 p-0" >
                                        <thead class="thead p">
                                            <th>PRODUIT</th>
                                            <th>PRIX</th>
                                            <th class="text-center">QUANTITE</th>
                                            <th>TOTAL</th>
                                        </thead>    
                                        <tbody id="tbody_checkout" class="tbody-checkout "></tbody>
                                        </table>
                                    </div>
                                    <hr class="mb-0"> 
                                    <div class="card-body  " > 
                                        <table class="chk-footer table " style="-">
                                            <tfoot>
                                                <tr class=""><td colspan="2" class="pt-2">Sous-total</td><td class="py-1 border-none" colspan="2"><input type="text" class="subtotal in-content form-control text-center" name="subtotal" readonly="true" /></td></tr>
                                                <tr><td colspan="2" class="pt-2">Total</td><td colspan="2" class="py-1 border-none"><input type="text" class="total in-content form-control text-center" name="total" readonly="true"/></td></tr>
                                                <tr><td colspan="2" class="pt-2">Item count</td><td colspan="2" class="py-1 border-none"><input type="text" class="item_count in-content form-control text-center" name="item_count" readonly="true"/></td></tr>
                                                <input type="hidden"  name="type" value="7"/>
                                            </tfoot>
                                        </table>                                       
                                    </div>
                                    <div class="card-footer mx-auto p-sm-2" style="border:none !important">
                                        <div class="btn-group mx-auto" data-toggle="buttons">
                                           
                                        <label class="btn btn-danger " id="cancel-sale">
                                            ANNULER
                                            <!-- <input type="button" name="options" id="option1" autocomplete="off" checked> Active -->
                                        </label>
                                        <label class="btn btn-primary mx-2" id="list">
                                            LISTE
                                            <!-- <input type="button" name="options" id="option2" autocomplete="off"> Radio -->
                                        </label>
                                        <label class="btn btn-success " data-toggle="modal" data-target="#AddModal" id="valider" title="Valider la Vente">
                                            ENREGISTRER
                                            <!-- <input type="button" name="options" id="option3" autocomplete="off"> Radio -->
                                        </label>
                                        </div>
                                    </div>
                                 </form>
                                </div>
                            </div>
                            <div class="d-none">
                                <table id="units_table">
                                    
                                </table>
                            </div>
                            <!-- <div class="col-lg-7 col-md-5 d-none d-md-block"> -->
                            <div class="col-12 col-lg-7 col-md-5">
                                <div class="card" >
                                <div class="card-body " style="height: 450px;max-height:500px; overflow:auto">
                                        <table id="tableProdSale" class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Nom</th>
                                                    <!-- <th>Prix</th> -->
                                                    <th>Quantite</th>
                                                    <th>Quantite Restante</th>
                                                    <th >Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="t_body_prod_sale" class="">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                <?php include('partials/footer.php');?>
            </div>
        </div>
        <?php include('partials/modal/sale-modal/add-modal.php');?>
        <?php include('partials/modal/sale-modal/add-modal.php');?>
        <?php include('partials/modal/sale-modal/unit-sale-modal.php');?>
        <?php include('partials/scripts.php');?>
    
        <script src="../controller/Sale/saleFunctions.js"></script>
        <script src="../controller/Sale/checkout.js"></script>
        <script src="../controller/Sale/sale.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
         <!-- <script src="../js/menu.js"></script> -->
        <script>
            (function($){
                //$('.user-item').addClass('active')
                activeMenu(".saleItem");
                //alert(sessionStorage.getItem("printContent"));
               // $("#AddModal2").modal('show');
                $("#list").on("click",function(){
                    window.location.href = "saleList.php";
                   
                })
              
                //removeItem();
            })(jQuery)
        </script>
    </body>
</html>