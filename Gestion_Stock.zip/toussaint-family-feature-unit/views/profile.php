<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Profile | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap">
            <?php include('partials/menu.php'); ?>

            <div class="main-content">
            <div class="container-fluid">
                        <div class="page-header m-0 p-0">
                            <div class="row">
                                <div class="col-lg-4">
                                    <nav class="breadcrumb p-0" style="background:none !important" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Profil</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4 col-md-5">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="text-center"> 
                                            <!-- <img src="../img/user.jpg" class="rounded-circle" width="150" /> -->
                                            <i class="fa fa-user-circle" style="font-size:10rem;color:#404E67"></i>
                                            <h4 class="card-title mt-10" id="fullNameP">John Doe</h4>
                                            <p class="card-subtitle" id="statusP">Front End Developer</p>
                                            
                                        </div>
                                    </div>
                                    <hr class="mb-0"> 
                                    <div class="card-body"> 
                                        <small class="text-muted d-block">Email </small>
                                        <h6 id="emailP">johndoe@admin.com</h6> 
                                        <small class="text-muted d-block pt-10">Telephone</small>
                                        <h6 id="phoneP">(123) 456 7890</h6> 
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-7">
                                <div class="card">
                                    <ul class="nav nav-pills custom-pills" id="pills-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="pills-setting-tab" data-toggle="pill" href="#previous-month" role="tab" aria-controls="pills-setting" aria-selected="false">Setting</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                      
                                        <div class="tab-pane fade show active" id="previous-month" role="tabpanel" aria-labelledby="pills-setting-tab">
                                            <div class="card-body">
                                            <form id="profil-form">
                                                <input type="hidden" name="id-profile" id="id-profile"/>
                                                <input type="hidden" name="type" value="8"/>
                                                <div class="row">
                                                <div class="col">
                                                <label for="exampleInputEmail1">PRENOM</label>
                                                    <input type="text" class="form-control" name="first-name" id="first-nameP" placeholder="First name"  required/>
                                                    <div class="text-error">
                                                            Please provide a valid zip.
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-group">
                                                    <label for="exampleInputEmail1">NOM</label>
                                                    <input type="text" name="last-name" id="last-nameP" class="form-control" placeholder="Last name"  required/>
                                                    <div class="text-error">
                                                            Please provide a valid zip.
                                                    </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="form-group">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">TELEPHONE</label>
                                                    <input type="text" class="form-control"  name="phone" id="phone-P" aria-describedby="emailHelp" placeholder="Enter Phone" >
                                                </div>
                                                </div>
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">EMAIL </label>
                                                <input type="email" class="form-control" name="email" id="email-P" aria-describedby="emailHelp" placeholder="Enter email"  >
                                                </div>
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">PSEUDO</label>
                                                <input type="text" class="form-control" name="user-name" id="user-nameP" aria-describedby="emailHelp" placeholder="Pseudo"  required>
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                                </div>
                                                <div class="form-group">
                                                <label for="exampleInputEmail1">MOT DE PASSE</label>
                                                <input type="text" class="form-control" name="password" id="passwordP" aria-describedby="emailHelp" placeholder="Enter email"  required>
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                                </div>
                                                <button class="btn btn-success" type="button" id="update-profile">Update Profile</button>

                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('partials/footer.php');?>
            </div>
        </div>
        <?php include('partials/modal/user-modal/add-modal.php');?>
        <?php include('partials/modal/user-modal/modify-modal.php');?>
        <?php include('partials/modal/user-modal/delete-modal.php');?>
        <?php include('partials/scripts.php');?>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
         <!-- <script src="../js/menu.js"></script> -->
        <script>
            (function($){
                //$('.user-item').addClass('active')
                activeMenu(".profileItem");
            })(jQuery)
        </script>
    </body>
</html>