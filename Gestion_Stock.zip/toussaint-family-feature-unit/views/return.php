<?php 
   session_start();
   require_once("SaleController2.php");
   if(!isset($_SESSION['tf_status']))
   {
      header('Location: login.php');
   }

   if(!isset($_GET['id'])){
       if($_SESSION['tf_status'] != "caissier")
     header('Location:accounting.php');
     else
     header('Location:sale.php');
   }

   $sale_line = [];
    if(isset($_GET['id'])){
    $sale_id = $_GET['id'];
    $sale_line = getSaleLine($_GET['id']);
    $sale_line1 = getSaleLine($_GET['id']);
   
    $sale_line_qty = get_qty($_GET['id']);
    $sale = get($_GET['id']);
    if(!$sale['sale_id']){
        if($_SESSION['tf_status'] != "caissier")
        header('Location:accounting.php');
        else
        header('Location:sale.php');
    }
   //Check if is a return sale
    if($sale['return_sale'] == 1){
        header('Location:saleList.php');
    }

   $reduction = $sale['discount'];
    $item_count = $sale['item_count'];
    $reduction_prod = ($reduction/$item_count);
    }
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Retour | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap">
            <?php include('partials/menu.php'); ?>

            <div class="main-content">
            <div class="container-fluid">
                        <div class="page-header m-0 p-0">
                            <div class="row">
                                <div class="col-lg-4">
                                    <nav class="breadcrumb p-0 my-0" style="background:none !important" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item">
                                                <a href="saleList.php">Liste de Vente</a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page">Retour</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-5 col-md-7">
                                <div class="card p-0 " style="height: 500px;max-height:500px" >
                                <div class="card-header d-lg-none d-sm-block row">
                                    <form id="form_search">
                                        <label for="prod_search" class="col-12">Rechercher le produit</label><br/>
                                       <div class="col-12">
                                       <div class="d-flex">
                                           <div>
                                                <input list="productsM" name="prod_search"  id="prod_search" class="form-control w-100" required>
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div> 
                                            </div>
                                            <button class="btn btn-success text-center" type="button" value="Add" id="add-prod-mobile">
                                                <i class="fas fa-plus text-center"></i>
                                         </button>
                                        </div>
                                       
                                        <datalist id="productsM">
                                        <?php
                                         
                                            while($data1 = $sale_line1->fetch(PDO::FETCH_ASSOC)){
                                            $product = $data1['product_id']."-".$data1['product_name'];
                                            echo '<option value="'.$product.'"></option>';
                                            }                                                 
                                        ?>                                        
                                        </datalist>
                                               
                                       </div>
                                
                                    </form>
                                </div>
                                <div class="card-body p-0 " style="height: 260px;max-height:260px; overflow:auto">
                                 <form id="checkout" method="post" class="chk " >
                                    
                                        <table id="customers2" class="table table-hover chk-header m-0 p-0" >
                                        <thead class="thead p">
                                            <th>PRODUIT</th>
                                            <th>PRIX</th>
                                            <th class="text-center">QUANTITE</th>
                                            <th>TOTAL</th>
                                        </thead>
                                        <tbody id="tbody_checkout" class="tbody-checkout "></tbody>
                                        </table>
                                    </div>
                                    <hr class="mb-0"> 
                                    <div class="card-body  " > 
                                        <table class="chk-footer table table-hover" style="margin-bottom:-10px !important">
                                            <tfoot>
                                                <tr class=""><td colspan="2" class="pt-2">Sous-total</td><td class="py-1 border-none" colspan="2"><input type="text" class="subtotal in-content form-control " name="subtotal" readonly="true" /></td></tr>
                                                <tr class="d-none"><td colspan="2">Reduction</td><td colspan="2"><input type="number" class="reduction in-content" name="reduction" readonly="true" /></td></tr>
                                                <tr><td colspan="2" class="pt-2">Total</td><td colspan="2" class="py-1 border-none"><input type="text" class="total in-content form-control " name="total" readonly="true"/></td></tr>
                                                <tr><td colspan="2">Cash</td><td colspan="2" class="py-1 border-none"><input type="text" class="cash in-content form-control" name="cash" maxlength="12" readonly="true" /></td></tr>
                                                <tr class="d-none"><td colspan="2">Change</td><td colspan="2" class="py-1 border-none"><input type="text" class="change in-content form-control" name="change" readonly="true" value="0" /></td></tr>
                                                <tr><td colspan="2" class="pt-2">Item count</td><td colspan="2" class="py-1 border-none"><input type="text" class="item_count in-content form-control " name="item_count" readonly="true"/></td></tr>
                                                <input type="hidden"  name="type" value="7"/>
                                                <input type="hidden" name="sale_id" value="<?=$sale_id;?>" id="sale_id" />
                                                 <input type="hidden" name="reduction_prod" value="<?=$reduction_prod?>" id="reduction_prod"/>
                                            </tfoot>
                                        </table>                                       
                                    </div>
                                    <div class="card-footer mx-auto" style="border:none !important">
                                        <div class="btn-group mx-auto" data-toggle="buttons">
                                        <label class="btn btn-danger ">
                                            ANNULER
                                            <!-- <input type="button" name="options" id="option1" autocomplete="off" checked> Active -->
                                        </label>
                                        <label class="btn btn-primary mx-2" id="list">
                                            LISTE
                                            <!-- <input type="button" name="options" id="option2" autocomplete="off"> Radio -->
                                        </label>
                                        <label class="btn btn-success " id="valider_return" title="Valider la Vente">
                                            ENREGISTRER
                                            <!-- <input type="button" name="options" id="option3" autocomplete="off"> Radio -->
                                        </label>
                                        </div>
                                    </div>
                                 </form>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-5">
                                <div class="card">
                                <div class="card-body p-0">
                                        <table id="customers" class="table table-hover m-0 p-0">
                                            <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Nom</th>
                                                    <th>Prix</th>
                                                    <th>Quantite</th>
                                                    <th>Quantite A Retourne</th>
                                                    <th>Sous total</th> 
                                                    <th >Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody_sale_prod" class="m-0 p-0">
                                            <?php
                                                 $j=1;
                                                while($data = $sale_line->fetch(PDO::FETCH_ASSOC)){                                                   
                                                ?>
                                                 <tr                                                 
                                                    id=<?=$data["product_id"];?> 
                                                     data-prodName="<?=$data['product_name'];?>"
                                                     
                                                     data-priceM=<?=$data['price'];?>
                                                     
                                                     data-line_qty=<?=$data['quantity'];?>
                                                     
                                                     data-s_qty=<?=$data['quantity'];?>
                                                 >
                                                <td style="text-align: center;"><?=$j++;?></td>
                                                    <td ><?=$data['product_name'];?></td>
                                                    <td ><?=$data['price'];?></td>
                                                    <td ><?=$data['quantity'];?></td>
                                                    <td class="return_qty"><?php
                                                                if(count($sale_line_qty)>0){
                                                                    for($i=0;$i<count($sale_line_qty);$i++){
                                                                    if($data['product_id']==$sale_line_qty[$i]['product_id']){
                                                                        echo $data['quantity']+($sale_line_qty[$i]['qty']);
                                                                        break;
                                                                    }
                                                                }
                                                                }
                                                                else{
                                                                    echo $data['quantity'];
                                                                }
                                                            ;?></td>
                                                    <td ><?=$data['total'];?></td>
                                                    <td >
                                                    
                                                    <button  class="prod-addr"
                                                            data-product_id ="<?=$data['product_id'];?>"                                                             
                                                            data-name="<?=$data['product_name'];?>"
                                                            data-quantity="<?php
                                                                if(count($sale_line_qty)>0){
                                                                    for($i=0;$i<count($sale_line_qty);$i++){
                                                                    if($data['product_id']==$sale_line_qty[$i]['product_id']){
                                                                       echo $data['quantity']+($sale_line_qty[$i]['qty']);
                                                                        //echo "OK";
                                                                        break;
                                                                    }
                                                                }
                                                                }
                                                                else{
                                                                    echo $data['quantity'];
                                                                }
                                                            ?>"
                                                            
                                                            data-product_quantity="<?=$data['quantity'];?>"
                                                            data-sale_price="<?=$data['price'];?>"
                                                    >
                                                       <i class="fa fa-undo-alt"></i>&nbspRetour
                                                    </button>

                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                ?>
                                                <script></script>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        
                <?php include('partials/footer.php');?>
            </div>
        </div>
        <?php include('partials/scripts.php');?>
        <script src="../controller/Return/checkoutReturn.js"></script>
        <script src="../controller/Return/return.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
         <!-- <script src="../js/menu.js"></script> -->
        <script>
            (function($){
                //$('.user-item').addClass('active')
                activeMenu(".saleItem");
                $("#list").on("click",function(){
                    window.location.href = "saleList.php";                   
                })
                dataTable("#customers")
                //removeItem();
            })(jQuery)
        </script>
    </body>
</html>