<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }       
    include("../controller/Stock/ProductController2.php");
    $prod = null;
    $units = [];
    $prod = getProduct($_GET['id'])[0];
     if($prod != null){
        $units = getUnit($_GET['id']);
     }
   // echo($prod['product_id'])
   //var_dump($units);
   
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Modification Produit | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <?php include('partials/links.php');?>
    </head>

    <body >
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap ">
                <?php include('partials/menu.php'); ?>

                <div class="main-content">
                        <div class="container">
                            <div class="page-header ">
                                <div class="row">
                                    <!-- <div class="col-12">
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong>Holy guacamole!</strong> You should check in on some of those fields below.
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>

                                    </div> -->
                                    
                                    <div class="col-lg-4">
                                        <nav class="breadcrumb p-0" style="background:none !important" aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item">
                                                    <a href="dashboard.php"><i class="fa fa-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                    <a href="stock.php"><i >produit</i></a>
                                                </li>
                                                <li class="breadcrumb-item active" aria-current="page">Modification Produit</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-7 col-12">
                                    <div class="card">
                                        <div class="card-header"><div><h3>MODIFIER PRODUIT</h3></div>
                                       
                                    </div>
                                        <div class="card-body">
                                            <form id="update-prod-form">

                                            <div class="form-group">
                                            <label for="exampleInputEmail1">NOM PRODUIT</label>
                                            <input type="text" class="form-control" name="product_name" id="product-namem" value="<?=$prod['product_name']?>" required/>
                                            <div class="text-error">
                                                Please provide a valid zip.
                                            </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Quantité </label>
                                                    <input type="number" name="qty" id="quantitym" value="<?=$prod['quantity']?>" readonly class="form-control" placeholder="23" required/>          
                                                </div>
                                                </div>
                                                <div class="col">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Augmenté la Quantité </label>
                                                    <input type="number" name="quantity" id="quantityNew" min="0" class="form-control" value="<?=$prod['quantity']?>" required/>
                                                    <div class="text-error">
                                                        Please provide a valid zip.
                                                    </div>           
                                                </div>
                                                </div>
                                            </div>
                                            
                                        
                                        
                                            <!-- <div class="form-group">
                                            <label for="exampleInputEmail1">PRIX </label>
                                            <input type="number" step="0.00001" class="form-control"  name="price" id="pricem" aria-describedby="emailHelp" value="<?=$prod['product_name']?>" placeholder="234,50" required />
                                            <div class="text-error">
                                                    Please provide a valid zip.
                                            </div>
                                        </div> -->

                                            

                                        <div class="row">
                                            <div class="col">
                                            <div class="form-group">
                                            <label for="exampleInputEmail1">DATE D'AJOUT</label><br/>
                                            <input type="text" readonly class="form-control"  name="date" id="datem" aria-describedby="emailHelp" value="<?=$prod['created_at']?>" required />
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col">
                                            <div class="form-group">
                                            <label for="exampleInputEmail1">DATE DE MODIFICATION</label><br/>
                                            <input type="text" readonly class="form-control"  name="datem" id="updated_at" aria-describedby="emailHelp" value="<?=$prod['updated_at']?>" required />
                                                <div class="text-error">
                                                        Please provide a valid zip.
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleTextarea1">COMMENTAIRE</label>
                                            <textarea class="form-control" id="commentm" rows="4" value="<?=$prod['comment']?>" name="comment"></textarea>
                                        </div>
                                        <input type="hidden" name="type" value="2"/>
                                        <input type="hidden" name="product_id" value="<?=$prod['product_id']?>" id="prod_id"/>
                                        </form>                                        
                                        </div>
                                        <div class="card-footer">
                                            <div class="m-auto">
                                                <button id="update-prod" type="submit" class="btn btn-primary btn-block">MODIFIER</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-5 col-12">
                                    <div class="card">      
                                    <div class="card-header"><div><h3>UNITES</h3></div>
                                       
                                       </div>                              
                                        <div class="card-body">                                       
                                            <table class="p-2 table">
                                                <thead>
                                                    <tr>
                                                        <th>Id</th>                                                       
                                                        <th>Nom</th>
                                                        <th>Prix</th>
                                                        <th >Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="t_body_unit">
                                                    <?php
                                                        foreach ($units as $value) {
                                                            ?>                                                            
                                                            <tr>
                                                                <td><?=$value['unit_id']?></td>
                                                                <td><?=$value['unit_name']?></td>
                                                                <td><?=$value['unit_price']?></td>
                                                                <td class="text-left"> 
                                                                  <a href="#"  data-toggle="modal" data-target="#EditModal" class="edit-unit"
                                                                    data-unit_id = "<?=$value['unit_id']?>"
                                                                    data-unit_name = "<?=$value['unit_name']?>"
                                                                    data-unit_price = "<?=$value['unit_price']?>"
                                                                    data-unit_quantity = "<?=$value['unit_quantity']?>"
                                                                    data-unit_created_at = "<?=$value["created_at"]?>"
                                                                    data-unit_updated_at = "<?=$value["updated_at"]?>"
                                                                  >
                                                                        <i class="fa fa-edit"></i>
                                                                  </a>
                                                                  <a href="#" data-toggle="modal" 
                                                                  data-target="#DeleteModal" class="delete-unit"
                                                                  data-unit_id="<?=$value['unit_id']?>"
                                                                  >
                                                                    <i class="fa fa-trash"></i>
                                                                  </a>
                                                                </td>
                                                            </tr>
                                                    <?php
                                                          }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="card-footer">
                                            <div class="m-auto">
                                            <button  type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#AddModal">
                                                AJOUTER PRODUIT
                                            </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('partials/footer.php');?>
                    
                </div>
            </div>
        <?php include('partials/modal/unit-modal/add-modal.php');?>
        <?php include('partials/modal/unit-modal/modify-modal.php');?>
        <?php include('partials/modal/unit-modal/delete-modal.php');?>
        <?php include('partials/scripts.php');?>
        <!-- <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> -->
        <script src="../controller/Unit/unit.js"></script> 
        <script src="../controller/Stock/product.js"></script>  
        <!-- <script src="//cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script> -->
        <!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> -->
        
        <script>
            (function($){
                //$(document).ready( function () {
                    
               // } );
                //$('.user-item').addClass('active')
                activeMenu(".stock-item");
                //$('.alert').addClass("show")
                setTimeout(() => {
                    $('.alert').alert("close")
                }, 5000);
            })(jQuery)
        </script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
      
    </body>
</html>