<?php 
    session_start();
    if(!isset($_SESSION['tf_status']))
    {
       header('Location: login.php');
    }

    if($_SESSION['tf_status'] == "caissier")
        header('Location: sale.php');
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Home | Toussaint Family</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.min.js"></script>
        <?php include('partials/links.php');?>
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
            <?php include('partials/navbar-top.php'); ?>
            <div class="page-wrap">
            <?php include('partials/menu.php'); ?>
                <div class="main-content">
                    <div class="container-fluid">
                    <?php include('partials/accounting-layout/header-layout.php'); ?>
        
                        <div>
                            <canvas id="myChart"></canvas>
                        </div>

                <!-- <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block">Copyright © 2018 ThemeKit v2.0. All Rights Reserved.</span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Crafted with <i class="fa fa-heart text-danger"></i> by <a href="http://lavalite.org/" class="text-dark" target="_blank">Lavalite</a></span>
                    </div>
                </footer> -->
                <?php include('partials/footer.php');?>
            </div>
        </div>
        
        <?php include('partials/scripts.php');?>
        <script src="../controller/Accounting/accounting.js"></script>
        <script>
            (function($){
                //$('.user-item').addClass('active')
                activeMenu(".dash");
            })(jQuery)
        </script>
        <script>
            $(window).on("load",function(){
                const labels = [
            'Janvier',
            'Fevrier',
            'Mars',
            'Avril',
            'Mai',
            'Juin',
            'Juillet',
            'Aout',
            'Septembre',
            'Octobre',
            'Novembre',
            'Decembre'
            ];
            const d = new Date();

            var dataAmountMonthly = [];

            for(let i = 0; i<labels.length;i++){
                // var dd = new Date();
                // dd.setMonth(i)
                // dd.setDate(1);
                // alert(dd)
             saleAmount(i)
                if(d.getMonth() == i){
                    break;
                }
            }

            function saleAmount(month){
                var monthNumber = month + 1;
                    $.ajax({
                    data: {type:'10',month:monthNumber},
                    url : "../controller/Accounting/AccountingController.php",
                    method: 'post',
                    success: function(response)
                    {
                        console.log("DASH :"+response);
                        response = $.parseJSON(response);
                        //console.log(response.sum_monthly);
                        if(response !="failed"){
                            let dataA = response.sum_monthly == null ? 0 : response.sum_monthly;
                            dataAmountMonthly.push(dataA);
                        }
                                    //console.log(dataAmountMonthly)
            const data = {
            labels: labels,
            datasets: [{
                label: 'Montant de vente ',
                backgroundColor: 'rgb(255, 99, 132)',
                borderColor: 'rgb(255, 99, 132)',
                data: dataAmountMonthly,
            }]
            };

            const config = {
            type: 'line',
            data: data,
            options: {}
            };
            


            var myChart = new Chart(
                document.getElementById('myChart'),
                config
            );

                    }
                });
            }
          

            })
           
        </script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
    </body>
</html>
