// (function($){
    function activeMenu(menuItem){
       // alert("OK")
        $(".nav-item").removeClass("active")
        $(menuItem).addClass('active')
    }
    function removeItem(){
        $(".nav-item").removeClass("active")
    }
// })(jQuery)