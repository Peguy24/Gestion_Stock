function dataTable(element,btn){
    var button = [];
    if(btn)
        button = []
    else
        button = ['copy', 'csv', 'excel', 'pdf', 'print'] 
    $(element).DataTable( {
        dom: 'Bfrtip',
        buttons: button
    } );
}

function destroyTable(element){
    $(element).DataTable( {
        destroy: true,
        searching: false
    } );
}