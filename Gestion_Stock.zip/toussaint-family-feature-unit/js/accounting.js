(function($){

	//variables for sale pane
	var btnAllSalesId = "#all_sales",
	tBodyId='#t_body_sale',
	tableId="#tableSale",
	returned=0;

	//daily
	var btnDailySale ='#daily_sale_btn';
	view_sales_daily(btnDailySale,returned,tBodyId,tableId);

	//Monthly
	var btnSaleMonthly = "#this_month_sale";
	view_sales_monthly(btnSaleMonthly,returned,tBodyId,tableId);

	//Yearly 
	var btnSaleYearly = '#this_year_sale';
	view_sales_yearly(btnSaleYearly,returned,tBodyId,tableId);

	//All	
	view_sales_a(btnAllSalesId,returned,tBodyId,tableId);
	
	//variables for return pane	
	var btnAllReturnsId = "#all_returns",
	tBodyIdR='#t_body_sale_return',
	tableIdR="#tableReturn",
	returnedR=1; 

	//daily
	var btnDailySaleR = '#daily_return_btn';
	view_sales_daily(btnDailySaleR,returnedR,tBodyIdR,tableIdR);

	//Monthly
	var btnSaleMonthlyR = "#this_month_return";
	view_sales_monthly(btnSaleMonthlyR,returnedR,tBodyIdR,tableIdR);

	//Yearly 
	var btnSaleYearlyR = '#this_year_return';
	view_sales_yearly(btnSaleYearlyR,returnedR,tBodyIdR,tableIdR);

	//All return
	view_sales_a(btnAllReturnsId,returnedR,tBodyIdR,tableIdR);


	view_sale_detail();
	//view_prod();
	var elementCountS = '#daily_sale_qty';
	sale_count(elementCountS,returned);

	var elementCountR = '#daily_return_qty';
	sale_count(elementCountR,returnedR);
	//cancel_sale();
	//search();
	// solde_amount();

	// solde_amount_discount();

	var elementS = '#daily_sale_amount';
	solde_amount_daily(elementS,returned);
	var elementR = '#daily_return_amount';
	solde_amount_daily(elementR,returnedR);

	// solde_amount_daily_discount();

	out_of_stock();
	out_of_stock_soon();
	// export_excel_prod_out();
	// export_excel_prod_out_soon();
	
	search();
})(jQuery)

function search(){
	 $("#myInput").on("keyup", function() {
     var value = $(this).val().toLowerCase();
$("#t_body_sales tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	});
});
}


function prod_factory(product_code,product_name,product_model,product_category,product_quantity){
	return{
		product_code:product_code,
		product_name:product_name,
		product_model:product_model,
		product_category:product_category,
		product_quantity:product_quantity
	};
}

function export_excel_prod_out(){
	 $("#export-product-in-rupture").click(function(){
	 	//console.log('ok');
	 	var prods = [];
   		 $("#t_body_prod_rupture tr").each(function(){
   		 	let tr_id = $(this).attr('id');
   		 	let product_name = $('#'+tr_id+' .product_name').text();
   		 	let product_code = $('#'+tr_id+' .product_code').text();
   		 	let product_model = $('#'+tr_id+' .product_model').text();
   		 	let product_category = $('#'+tr_id+' .product_category').text();
   		 	let product_quantity = $('#'+tr_id+' .product_quantity').text();
   		 	prods.push(prod_factory(product_code,product_name,product_model,product_category,product_quantity));
   		 	console.log(product_name);

   		 	//console.log(sale_factory(sale_code,item_count,sale_amount,sale_date));

     	 	//window.alert(sale_code +'=>'+item_count+'=>'+sale_amount+'=>'+sale_date);
   		 });

   		// console.log(prods.length);
   		if(prods.length > 0){
   			setLoader();
	   		$.ajax({
				data: {prod:prods,type:10},
				type: "post",
				url: "http://localhost/stock_management/app/controller/stock/ProductController.php",
				success: function(dataResult){
						//var dataResult = JSON.parse();
						console.log(dataResult);
						if(dataResult == 'success'){
							//$('#addEmployeeModal').modal('hide');
							window.alert('Operation réussie Emplacement "C:"!');
							hideLoader()
							//window.alert('Operation réussie !');
	                        //location.reload();
	                        //window.location.href = 'http://localhost/stock_management/app/controller/sale/excel.php';
						}
						else {
						   window.alert(dataResult);
						   hideLoader();
						}
				}
			});
	   	}else{
	   		window.alert("Il n'y a pas de produit en rupture de stock");
	   	}
  });
}

function export_excel_prod_out_soon(){
	 $("#export-product-rupture").click(function(){
	 	//console.log('ok');
	 	var prods = [];
   		 $("#t_body_prod_rupture_prevent tr").each(function(){
   		 	let tr_id = $(this).attr('id');
   		 	let product_name = $('#'+tr_id+' .product_name').text();
   		 	let product_code = $('#'+tr_id+' .product_code').text();
   		 	let product_model = $('#'+tr_id+' .product_model').text();
   		 	let product_category = $('#'+tr_id+' .product_category').text();
   		 	let product_quantity = $('#'+tr_id+' .product_quantity').text();
   		 	prods.push(prod_factory(product_code,product_name,product_model,product_category,product_quantity));
   		 	console.log( $('#'+tr_id+' .product_name').text());

   		 	//console.log(sale_factory(sale_code,item_count,sale_amount,sale_date));

     	 	//window.alert(sale_code +'=>'+item_count+'=>'+sale_amount+'=>'+sale_date);
   		 });

   		 console.log(prods);
   		if(prods.length > 0){

   			setLoader();
   		$.ajax({
			data: {prod:prods,type:9},
			type: "post",
			url: "http://localhost/stock_management/app/controller/stock/ProductController.php",
			success: function(dataResult){
					//var dataResult = JSON.parse();
					console.log(dataResult);
					if(dataResult == 'success'){
						//$('#addEmployeeModal').modal('hide');
						window.alert('Operation réussie Emplacement "C:"!');
						hideLoader();
                        //location.reload();
                        //window.location.href = 'http://localhost/stock_management/app/controller/sale/excel.php';
					}
					else {
					   window.alert(dataResult);
					   hideLoader();
					}
			}
		});
   	}else{
   		window.alert("Il n'y a pas de produit en rupture de stock");
   	}
  });
}

function view_sales_yearly(btn,returned,tBodyId,tableId){
	$(btn).on('click',function(e) {
		$.ajax({
		data: {type:'3',isReturned:returned},
		url : "../controller/Accounting/AccountingController.php",
		method: 'post',
		success: function(response)
		{
			console.log(response);
			response = $.parseJSON(response);

			if(response.length > 0){
				$(tBodyId).html("");
				response.forEach(function(data,index){
					let tr = tr_factory_sale(data,index);
					$(tBodyId).append(tr);
					//console.log(data);
				});
				//dataTable(tableId)
			}else{
				$(tBodyId).html("<tr><td colspan='8'>VOUS N'AVEZ PAS ENCORE EFFECTUER DE VENTE AUJOURD'HUI !!</td></tr>");
			}
		}
	});
	});
}

function view_sales_monthly(btn,returned,tBodyId,tableId){
	$(btn).on('click',function(e) {
			$.ajax({
			data: {type:'2',isReturned:returned},
			url : "../controller/Accounting/AccountingController.php",
			method: 'post',
			success: function(response)
			{
				console.log(response);
				response = $.parseJSON(response);

				if(response.length > 0){
					$(tBodyId).html("");
					response.forEach(function(data,index){
						let tr = tr_factory_sale(data,index);
						$(tBodyId).append(tr);
						//console.log(data);
					});
					//dataTable(tableId)
				}else{
					$(tBodyId).html("<tr><td colspan='8'>VOUS N'AVEZ PAS ENCORE EFFECTUER DE VENTE AUJOURD'HUI !!</td></tr>");
				}
			}
		});
	});
}

function view_sales_weekly(btn,returned,tBodyId,tableId){
	$(btn).on('click',function(e) {
			$.ajax({
			data: {type:'12',isReturned:returned},
			url : "../controller/Accounting/AccountingController.php",
			method: 'post',
			success: function(response)
			{
				//console.log(response);
				response = $.parseJSON(response);

				if(response.length > 0){
					$(tBodyId).html("");
					response.forEach(function(data,index){
						let tr = tr_factory_sale(data,index);
						$(tBodyId).append(tr);
						//console.log(data);
					});
					//dataTable(tableId)
				}else{
					$(tBodyId).html("<tr><td colspan='8'>VOUS N'AVEZ PAS ENCORE EFFECTUER DE VENTE AUJOURD'HUI !!</td></tr>");
				}
			}
		});
	});
}

function tr_sale_line(data,index){
	let tr = '<tr>';
	tr += '<td >'+data.product_name+'</td>';
	tr += '<td >'+data.price+'</td>';
	tr += '<td >'+data.quantity+'</td>';
	tr += '<td >'+data.total+'</td></tr>';	
	return tr;
}

function view_sale_detail(){
	$(document).on('click','.view',function(e) {
		$('#accounting').hide();
		$('#sale_detail').show();
		var id = $(this).attr("data-sale_id");
		var item_count = $(this).attr("data-item_count");
		var cash = $(this).attr("data-cash");
		var due = $(this).attr("data-due");
		var user = $(this).attr("data-first_name");
		var sale_amount = $(this).attr("data-sale_amount");
		var sale_date = $(this).attr("data-sale_date");
		var sale_code = $(this).attr("data-sale_code");
		var data_sale = {
			item_count:item_count,cash:cash,due:due,sale_amount:sale_amount,sale_date:sale_date,sale_code:sale_code
		};
		$('#user').text(user);
		//console.log(data_sale);

		//console.log(id)
		$.ajax({
				data:{id:id,type:14},
				type:"post",
				url:"http://localhost/stock_management/app/controller/sale/SaleController.php",
				success: function(dataResult){
					//console.log(dataResult)
					var dataResult = $.parseJSON(dataResult);
					
					//window.location.href = 'http://localhost/stock_management/app/view/sale_detail.php';

					let tr = tr_sale_factory(data_sale);
					$('#t_body_sale').append(tr);
					console.log(dataResult.length)
					if(dataResult.length>0){

						dataResult.forEach(function(data1,index){
					let tr = tr_sale_line(data1,index);
					$('#t_body_prod_sale_detail').append(tr);
					console.log(data1);
					console.log(tr)
				});

					}else{
						//alert(dataResult);
					}
				}
			});
	});
//;
	
}

function view_sales_daily(btn,returned,tBodyId,tableId){
	$(document).on('click',btn,function(e) {
		
		var date = new Date();
			var month = date.getMonth()+1;
			var year = date.getFullYear();
			var  day = date.getDate();
			var fromatDate = year+"-"+month+"-"+day;
		//	console.log(fromatDate);
			$.ajax({
				data: {type:'1',date:fromatDate,isReturned:returned},
				url : "../controller/Accounting/AccountingController.php",
				method: 'post',
				success: function(response)
				{
					//console.log("OK" +response)
					response = $.parseJSON(response);
					//console.log("OK" +response.length)
					if(response.length > 0){
						//console.log(response.length>0);
						$(tBodyId).html("")
						response.forEach(function(data,index){
							let tr = tr_factory_sale(data,index);
							$(tBodyId).append(tr);
							//console.log(data);
						});
						//dataTable(tableId)
					}else{
						$(tBodyId).html("<tr><td colspan='8'>VOUS N'AVEZ PAS ENCORE EFFECTUER DE VENTE AUJOURD'HUI !!</td></tr>");
					}
				}
			});
	});
	
}

function out_of_stock_soon(){
	$.ajax({
		data: {type:'8'},
		url : "../controller/Accounting/AccountingController.php",
		method: 'post',
		success: function(response)
		{

			response = $.parseJSON(response);
			//console.log('soon => '+response.length);
			$('#prod_out_of_stock_soon').text(response.length);
			if(response.length > 0){
				response.forEach(function(data,index){
					let tr = tr_factory_prod(data,index,"accounting");
					$('#t_body_prod_soon').append(tr);
					//console.log(data);
				});
				dataTable("#tableProdOutSoon");
			}
		}
	});
}


function tr_prod(data, index){
	let tr = '<tr id = "'+data.product_id+'">';
	tr += '<td class="product_code">'+data.product_code+'</td>';
	tr += '<td class="product_name">'+data.product_name+'</td>';
	tr += '<td class="product_model">'+data.product_model+'</td>';
	tr += '<td class="product_category">'+data.product_category+'</td>';
	tr += '<td class="product_quantity">'+data.product_quantity+'</td></tr>';

	return tr;
}

function out_of_stock(){
	$.ajax({
		data: {type:'9'},
		url : "../controller/Accounting/AccountingController.php",
		method: 'post',
		success: function(response)
		{
			response = $.parseJSON(response);
			//console.log(response.length);
			$('#prod_out_of_stock').text(response.length);
			if(response.length > 0){
				response.forEach(function(data,index){
					let tr = tr_factory_prod(data,index,"accounting");
					$('#t_body_prod_out').append(tr);
					//console.log(data);
				});
				dataTable("#tableProdOut");
			}
		}
	});
}

function sale_count(element,returned){
	var date = new Date();
			var month = date.getMonth()+1;
			var year = date.getFullYear();
			var  day = date.getDate();
			var fromatDate = year+"-"+month+"-"+day;
	$.ajax({
		data: {type:'11',date:fromatDate,isReturned:returned},
		url : "../controller/Accounting/AccountingController.php",
		method: 'post',
		success: function(response)
		{
			// console.log(response);
			// response = $.parseJSON(response);

			// var responseCount = response.sum;
			// var responseSumAmount = Number(response.sum_amount);
			// alert(responseCount)
			//$('#daily_sale_amount').text(responseSumAmount);
			$(element).text(response);
		}
	});
}

function solde_amount_daily(element,returned){
	var date = new Date();
			var month = date.getMonth()+1;
			var year = date.getFullYear();
			var  day = date.getDate();
			var fromatDate = year+"-"+month+"-"+day;
	$.ajax({
		data: {type:'4',date:fromatDate,isReturned:returned},
		url : "../controller/Accounting/AccountingController.php",
		method: 'post',
		success: function(response)
		{
			var response = Number(response);
			$(element).text(Number.parseFloat(response).toFixed(2) + " HTG");
		}
	});
}

	function view_sales_a(btnId,returned,tBodyId,tableId){
	$(btnId).on("click",function(e){
		e.preventDefault();
		$.ajax({
			data: {type:'4',isReturned:returned},
			url : "../controller/Sale/SaleController.php",
			method: 'post',
			success: function(response)
			{
				//console.log(response)
				response = $.parseJSON(response);
				if(response.length>0){
					$(tBodyId).html("")
					//console.log(response);
					response.forEach(function(data,index){
						let tr = tr_factory_sale(data,index);
						$(tBodyId).append(tr);
						//console.log(data);
					})
					//initTable();
					// destroyTable(tableId)
					// dataTable(tableId)
				}else{
					//initTable();
				}
			}
		});
	})
}
