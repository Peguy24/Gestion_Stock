//Function in order reset form modals
function resetFormModal(idForm){
  document.getElementById(idForm).reset();
  $("#"+idForm+" input:required").removeClass("is-invalid");
  $("#"+idForm+" input:required").removeClass("is-valid");
  $("#" + idForm +" input:required").siblings("text-error").hide();
}
//Function in order to check input classes
function checkClasses(inputElement){
  if(!inputElement.checkValidity())
  {
    inputElement.classList.remove("is-valid");
    inputElement.classList.add("is-invalid");
    inputElement.nextElementSibling.innerHTML = inputElement.validationMessage;
    inputElement.nextElementSibling.style.display = "block";
  }else{
    inputElement.classList.remove("is-invalid")
    inputElement.classList.add("is-valid");
    inputElement.nextElementSibling.style.display = "none";
  }
  }
  
  //Function in order to valide input with two events blur and keyup
  function validate(inputElement, submitButtonElement){
  if(!inputElement.getAttribute("readonly")){
    inputElement.addEventListener("blur", function(){
        checkClasses(inputElement);
    })
  }
  inputElement.addEventListener("keyup", function(){
    checkClasses(inputElement);
  });
  submitButtonElement.addEventListener("click", function(){
      checkClasses(inputElement);
  })
  }
  
(function($){
	 //Login form
     var  user_name = document.getElementById("pseudo");
     var password = document.getElementById("password");
     var loginButton = document.getElementById("login");
     //var inputs = document.querySelectorAll("#user-form input:required, #user-form select:required");
     //add-user-form
     var first_name = document.getElementById("first-name");
     var last_name = document.getElementById("last-name");
     var userName = document.getElementById("user-name");
     var status = document.getElementById("status");
     var password = document.getElementById("password");
    // var state_account = document.getElementById("");
     var addUserButton = document.getElementById("add-user");

     //updat-user
     var first_namem = document.getElementById("first-namem");
     var last_namem = document.getElementById("last-namem");
     var userNamem = document.getElementById("user-namem");
     var statusm = document.getElementById("statusm");
     var passwordm = document.getElementById("passwordm");
     var updateUserButton = document.getElementById("update-user");
     //updat-Profil-user
     var first_nameP = document.getElementById("first-nameP");
     var last_nameP = document.getElementById("last-nameP");
     var userNameP = document.getElementById("user-nameP");
    //  var statusm = document.getElementById("statusm");
     var passwordP = document.getElementById("passwordP");
    // var state_account = document.getElementById("");
     var updateProfilUserButton = document.getElementById("update-profile");
     //alert(inputs.length)
  //ADD-prod
  var product_name = document.getElementById("product-name");
  var price = document.getElementById("price");
  var quantity = document.getElementById("quantity");
  var created_at = document.getElementById("date");
  var addProdBtn = document.getElementById("add-prod");

  //Update prod
  var product_namem = document.getElementById("product-namem");
  var pricem = document.getElementById("pricem");
  var quantitym = document.getElementById("quantityNew");
  var updateProdBtn = document.getElementById("update-prod");

  //DELETE prod
  var del_quantity = document.getElementById("del_qty");
  var deleteBtn = document.getElementById("delete-prod");

  //Add prod into checkout on mobile version
  var inputSearchProd = document.getElementById("prod_search");
  var btnAddProd = document.getElementById("add-prod-mobile");

//hide all errors div
$(".text-error").hide();
      


//resetFormModal();
//Call validate function in order to check each user form  input


// 
if(user_name != null && loginButton != null){
    validate(user_name, loginButton)
    validate(password,loginButton)
}
    
// })(jQuery)
if(first_name != null){
    validate(first_name,addUserButton)
    validate(last_name,addUserButton)
    validate(password,addUserButton)
    validate(userName,addUserButton)
    validate(status,addUserButton)
}
if(first_namem != null && updateUserButton != null){
    validate(first_namem,updateUserButton)
    validate(last_namem,updateUserButton)
    validate(passwordm,updateUserButton)
    validate(userNamem,updateUserButton)
    validate(statusm,updateUserButton)
}

if(first_nameP != null){
    validate(first_nameP,updateProfilUserButton)
    validate(last_nameP,updateProfilUserButton)
    validate(passwordP,updateProfilUserButton)
    validate(userNameP,updateProfilUserButton)
}

if(product_name != null){
  validate(product_name,addProdBtn)
  validate(price,addProdBtn)
  validate(quantity,addProdBtn)
  validate(created_at,addProdBtn)
}

if(product_namem != null){
  validate(product_namem,updateProdBtn)
  validate(pricem,updateProdBtn)
  validate(quantitym,updateProdBtn)
}

if(del_quantity != null){
  validate(del_quantity,deleteBtn)
}

// if(btnAddProd != null){
//   validate(inputSearchProd,btnAddProd)
// }
//All inputs and select for add-user-modal
// for(let i = 0; i < inputs.length; i++){
//     validate(inputs[i],addUserButton)
// }

// validate(lieuNEdi)
// validate(lieuNEdi)
// validate(emailProfEdi)
// validate(salaireProfEdi)
})(jQuery)