$(window).on('load', function () {
    $("#cover").fadeOut(1750);
});

function setLoader(){
    $("#cover").fadeIn(1750);
}

function removeLoader(){
    $("#cover").fadeOut(1750);
}